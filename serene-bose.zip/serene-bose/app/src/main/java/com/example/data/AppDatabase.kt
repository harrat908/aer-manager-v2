package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.ClientDao
import com.example.data.dao.ExtraDao
import com.example.data.dao.InterventionDao
import com.example.data.dao.MachineDao
import com.example.data.dao.PartDao
import com.example.data.model.ClientEntity
import com.example.data.model.DiagnosticEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.KnowledgeBaseEntity
import com.example.data.model.MachineEntity
import com.example.data.model.MaintenanceScheduleEntity
import com.example.data.model.PartEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.QuoteEntity
import com.example.data.model.StockMovementEntity
import com.example.data.model.SupplierEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.InterventionPhotoEntity
import com.example.data.model.SupplierOrderEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ClientEntity::class,
        MachineEntity::class,
        InterventionEntity::class,
        DiagnosticEntity::class,
        PartEntity::class,
        StockMovementEntity::class,
        QuoteEntity::class,
        PaymentEntity::class,
        ExpenseEntity::class,
        MaintenanceScheduleEntity::class,
        KnowledgeBaseEntity::class,
        SupplierEntity::class,
        SupplierOrderEntity::class,
        InterventionPhotoEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun machineDao(): MachineDao
    abstract fun interventionDao(): InterventionDao
    abstract fun partDao(): PartDao
    abstract fun extraDao(): ExtraDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE interventions ADD COLUMN prixVentePieces REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE interventions ADD COLUMN mainOeuvreFacturee REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE interventions ADD COLUMN deplacementFacture REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE interventions ADD COLUMN fraisFactures REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE interventions ADD COLUMN margePieces REAL NOT NULL DEFAULT 0.0")
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aer_manager_database"
                )
                    .addMigrations(MIGRATION_2_3)
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            val clientDao = db.clientDao()
            val machineDao = db.machineDao()
            val interventionDao = db.interventionDao()
            val partDao = db.partDao()
            val extraDao = db.extraDao()

            // 1. Initial Clients
            val c1Id = clientDao.insertClient(
                ClientEntity(
                    nom = "Dr. Amina Benali",
                    nomClinique = "Centre Esthétique Médical El Bahdja",
                    telephone = "+213 550 12 34 56",
                    whatsapp = "+213550123456",
                    email = "contact@elbahdja-esthetique.com",
                    adresse = "14 Boulevard Didouche Mourad",
                    ville = "Alger",
                    notes = "Clinique dermatologique renommée. 3 salles laser.",
                    dateCreation = "2025-01-15"
                )
            )

            val c2Id = clientDao.insertClient(
                ClientEntity(
                    nom = "Dr. Karim Mansouri",
                    nomClinique = "Clinique Renaissance Laser & Skin",
                    telephone = "+213 661 98 76 54",
                    whatsapp = "+213661987654",
                    email = "kmansouri@renaissance-laser.dz",
                    adresse = "45 Rue Larbi Ben M'hidi",
                    ville = "Oran",
                    notes = "Équipement haut de gamme. Contrat de maintenance annuel.",
                    dateCreation = "2025-02-10"
                )
            )

            val c3Id = clientDao.insertClient(
                ClientEntity(
                    nom = "Dr. Nadia Chérif",
                    nomClinique = "Cabinet Dermato-Esthétique Chérif",
                    telephone = "+213 770 45 67 89",
                    whatsapp = "+213770456789",
                    email = "nadia.cherif.dermato@gmail.com",
                    adresse = "8 Avenue de l'Indépendance",
                    ville = "Constantine",
                    notes = "Spécialiste détatouage et rajeunissement facial.",
                    dateCreation = "2025-04-20"
                )
            )

            // 2. Initial Machines
            val m1Id = machineDao.insertMachine(
                MachineEntity(
                    clientId = c1Id,
                    marque = "Deka Medical",
                    modele = "SmartXide DOT",
                    type = "CO₂",
                    numeroSerie = "DK-CO2-2024-8841",
                    dateAchat = "2024-03-12",
                    fournisseur = "EuroMed Tech",
                    dateInstallation = "2024-03-20",
                    dureeGarantieMois = 24,
                    dateFinGarantie = "2026-03-20",
                    etat = "En service",
                    localisationSalle = "Salle Laser 1",
                    notes = "Tube RF cohérent. Système de scanner fractionné."
                )
            )

            val m2Id = machineDao.insertMachine(
                MachineEntity(
                    clientId = c1Id,
                    marque = "Edge Systems",
                    modele = "Hydrafacial MD Elite",
                    type = "Hydrafacial",
                    numeroSerie = "HF-ELITE-7732",
                    dateAchat = "2023-09-01",
                    fournisseur = "Aesthetix International",
                    dateInstallation = "2023-09-10",
                    dureeGarantieMois = 12,
                    dateFinGarantie = "2024-09-10",
                    etat = "En panne",
                    localisationSalle = "Salle Soins Visage",
                    notes = "Perte de dépression sous aspiration haute."
                )
            )

            val m3Id = machineDao.insertMachine(
                MachineEntity(
                    clientId = c2Id,
                    marque = "Lumenis",
                    modele = "LightSheer Quattro 808nm",
                    type = "Diode laser",
                    numeroSerie = "LMS-LSQ-99120",
                    dateAchat = "2024-06-15",
                    fournisseur = "MedLaser Global",
                    dateInstallation = "2024-06-25",
                    dureeGarantieMois = 24,
                    dateFinGarantie = "2026-06-25",
                    etat = "En service",
                    localisationSalle = "Bloc Épilation A",
                    notes = "Refroidissement ChillTip vérifié. Débit d'eau nominal."
                )
            )

            val m4Id = machineDao.insertMachine(
                MachineEntity(
                    clientId = c3Id,
                    marque = "Fotona",
                    modele = "StarWalker MaQX Q-Switched",
                    type = "Nd:YAG",
                    numeroSerie = "FTN-STW-5502",
                    dateAchat = "2023-11-20",
                    fournisseur = "LaserTech Europe",
                    dateInstallation = "2023-12-05",
                    dureeGarantieMois = 24,
                    dateFinGarantie = "2025-12-05",
                    etat = "En maintenance",
                    localisationSalle = "Salle Traitements Spécifiques",
                    notes = "Lampe flash approche des 1.000.000 tirs. Remplacement préconisé."
                )
            )

            // 3. Initial Interventions
            val int1Id = interventionDao.insertIntervention(
                InterventionEntity(
                    numeroIntervention = "INT-2026-042",
                    clientId = c1Id,
                    machineId = m2Id,
                    technicien = "Jules AER",
                    date = "2026-09-28",
                    statut = "En cours",
                    priorite = "Urgent",
                    problemeSignale = "Aspiration faible sur embout vortex, pompe tourne sans montée en pression.",
                    diagnostic = "Électrovanne d'aspiration 24V DC bloquée en position semi-ouverte par résidus de sérum.",
                    travailEffectue = "Démontage circuit fluide, purge ultrasons et test solénoïde.",
                    recommandations = "Remplacement filtre cartouche 5 microns et rinçage systématique fin de journée.",
                    prixVentePieces = 15000.0,
                    mainOeuvreFacturee = 25000.0,
                    deplacementFacture = 5000.0,
                    fraisFactures = 0.0,
                    prixFacture = 45000.0,
                    coutPieces = 8500.0,
                    coutDeplacement = 2500.0,
                    autresFrais = 0.0,
                    coutTotal = 11000.0,
                    benefice = 34000.0,
                    margePieces = 6500.0,
                    coutMainOeuvre = 25000.0
                )
            )

            interventionDao.insertDiagnostic(
                DiagnosticEntity(
                    interventionId = int1Id,
                    symptome = "Erreur dépression < 15 kPa lors du cycle exfoliation",
                    causeProbable = "Électrovanne fluide colmatée",
                    testsEffectues = "Mesure tension bobine (24.1V OK), mesure débit capteur vide (-8 kPa au lieu de -25 kPa)",
                    mesures = "Tension bobine: 24.1V, Dépression: -8 kPa",
                    resultat = "Électrovanne grippée mécaniquement",
                    solution = "Nettoyage ou remplacement électrovanne 24V SMC + nouveau filtre en ligne"
                )
            )

            interventionDao.insertIntervention(
                InterventionEntity(
                    numeroIntervention = "INT-2026-039",
                    clientId = c2Id,
                    machineId = m3Id,
                    technicien = "Jules AER",
                    date = "2026-09-20",
                    statut = "Terminé",
                    priorite = "Normale",
                    problemeSignale = "Contrôle préventif des 500k tirs et étalonnage énergie optique.",
                    diagnostic = "Pertes d'énergie < 3%, lentille collimateur impeccable.",
                    travailEffectue = "Vidange circuit eau désionisée, remplacement filtre particules, recalibrage photodiode.",
                    recommandations = "Utiliser uniquement de l'eau bi-distillée conductivité < 2 µS/cm.",
                    prixVentePieces = 25000.0,
                    mainOeuvreFacturee = 45000.0,
                    deplacementFacture = 15000.0,
                    fraisFactures = 0.0,
                    prixFacture = 85000.0,
                    coutPieces = 12000.0,
                    coutDeplacement = 8000.0,
                    autresFrais = 2000.0,
                    coutTotal = 22000.0,
                    benefice = 63000.0,
                    margePieces = 13000.0,
                    coutMainOeuvre = 45000.0
                )
            )

            // 4. Initial Parts (Stock)
            partDao.insertPart(
                PartEntity(
                    reference = "ELEC-SOL-24V",
                    nom = "Électrovanne 24V DC Fluide Hydrafacial",
                    categorie = "Hydraulique",
                    stock = 2,
                    stockMinimum = 3,
                    prixAchat = 8500.0,
                    prixVente = 16500.0,
                    fournisseur = "Shenzhen MediParts",
                    emplacement = "Tiroir B-04",
                    notes = "Compatible Edge Systems & Dermasound."
                )
            )

            partDao.insertPart(
                PartEntity(
                    reference = "FLT-WTR-05M",
                    nom = "Filtre à eau désionisée 0.5 micron Laser Diode",
                    categorie = "Consommables",
                    stock = 1,
                    stockMinimum = 4,
                    prixAchat = 3200.0,
                    prixVente = 7500.0,
                    fournisseur = "FilterPure France",
                    emplacement = "Étagère A-01",
                    notes = "Seuil critique atteint. Recommander rapidement."
                )
            )

            partDao.insertPart(
                PartEntity(
                    reference = "OPT-FL-NDYAG",
                    nom = "Lampe Flash Xénon 7x120mm Nd:YAG",
                    categorie = "Optique",
                    stock = 3,
                    stockMinimum = 2,
                    prixAchat = 28000.0,
                    prixVente = 55000.0,
                    fournisseur = "First Light Lamps UK",
                    emplacement = "Coffret Sécurisé Optique",
                    notes = "Durée nominale 1 million de tirs."
                )
            )

            partDao.insertPart(
                PartEntity(
                    reference = "SEN-TEMP-PT100",
                    nom = "Sonde de température PT100 Diode Laser",
                    categorie = "Électronique",
                    stock = 5,
                    stockMinimum = 2,
                    prixAchat = 2400.0,
                    prixVente = 6000.0,
                    fournisseur = "Shenzhen MediParts",
                    emplacement = "Tiroir C-02",
                    notes = "Précision standard 0.1°C pour refroidissement peltier."
                )
            )

            // 5. Knowledge Base (Base de Connaissances technique)
            extraDao.insertKnowledgeBase(
                KnowledgeBaseEntity(
                    machineType = "Hydrafacial",
                    codeErreur = "ERR-VAC-02",
                    symptome = "Aspiration faible ou instable, pompe tourne en continu.",
                    causeProbable = "Filtre collecteur encrassé ou électrovanne de décharge bloquée ouverte.",
                    tests = "1. Isoler la pompe et tester manomètre direct. 2. Vérifier clapet anti-retour et étanchéité raccord rapide.",
                    solution = "Nettoyer ou remplacer l'électrovanne SMC 24V. Changer filtre en amont.",
                    piecesRecommandees = "ELEC-SOL-24V, Joint torique silicone 6mm"
                )
            )

            extraDao.insertKnowledgeBase(
                KnowledgeBaseEntity(
                    machineType = "Diode laser",
                    codeErreur = "E04 - WATER TEMP HIGH",
                    symptome = "Arrêt tir laser après 2 minutes de tir continu. Alarme sonore.",
                    causeProbable = "Débit liquide insuffisant ou encrassement radiateur/pelletier.",
                    tests = "Mesurer débit débitmètre rotor (doit être > 1.8 L/min). Vérifier vitesse ventilateur échangeur.",
                    solution = "Détartrage circuit avec acide citrique 5%, remplacer filtre eau et faire appoint d'eau bi-distillée.",
                    piecesRecommandees = "FLT-WTR-05M, Débitmètre à impulsion"
                )
            )

            extraDao.insertKnowledgeBase(
                KnowledgeBaseEntity(
                    machineType = "CO₂",
                    codeErreur = "LASER POWER LOW",
                    symptome = "Pénétration tissu insuffisante, affichage énergie instable.",
                    causeProbable = "Désalignement miroir 45° bras articulé ou dépôt fumée sur lentille focale handpiece.",
                    tests = "Test papier thermique à la sortie du tube puis en bout de bras articulé pour vérifier la coaxialité.",
                    solution = "Nettoyer optiques à l'alcool isopropylique 99% avec lingettes optiques. Si décentré, régler vis micrométriques miroir M2.",
                    piecesRecommandees = "Miroir molybdène 25mm, Lentille ZnSe focal 50mm"
                )
            )

            // 6. Maintenance Schedule
            extraDao.insertMaintenanceSchedule(
                MaintenanceScheduleEntity(
                    machineId = m1Id,
                    typeMaintenance = "Contrôle optique & Purge gaz CO₂",
                    intervalleMois = 6,
                    derniereMaintenance = "2026-04-15",
                    prochaineMaintenance = "2026-10-15",
                    notes = "Vérifier centrage spot et étalonnage énergie."
                )
            )

            extraDao.insertMaintenanceSchedule(
                MaintenanceScheduleEntity(
                    machineId = m3Id,
                    typeMaintenance = "Vidange eau & Remplacement filtre 808nm",
                    intervalleMois = 3,
                    derniereMaintenance = "2026-07-01",
                    prochaineMaintenance = "2026-10-01",
                    notes = "Prévu semaine prochaine."
                )
            )

            // 7. Suppliers
            val sup1Id = extraDao.insertSupplier(
                SupplierEntity(
                    nom = "Shenzhen MediParts Co., Ltd",
                    pays = "Chine",
                    contact = "Kevin Zhang",
                    whatsapp = "+86 138 0013 8000",
                    wechat = "kevin_mediparts_sz",
                    alibaba = "https://mediparts.en.alibaba.com",
                    email = "sales@mediparts-sz.com",
                    notes = "Fournisseur fiable pour diodes 808nm, solénoïdes et pompes à vide."
                )
            )

            extraDao.insertSupplierOrder(
                SupplierOrderEntity(
                    supplierId = sup1Id,
                    produit = "Barres Diode Laser 808nm 800W + Filtres déionisation",
                    quantite = 5,
                    prix = 1450.0,
                    transport = "DHL Express",
                    modePaiement = "Alibaba Trade Assurance",
                    statut = "Expédié",
                    date = "2026-09-20"
                )
            )

            val sup2Id = extraDao.insertSupplier(
                SupplierEntity(
                    nom = "EuroMed Tech Optical",
                    pays = "France / Allemagne",
                    contact = "Marc Dupont",
                    whatsapp = "+33 6 12 34 56 78",
                    email = "m.dupont@euromed-optics.com",
                    notes = "Lentilles ZnSe, miroirs CO2, lampes flashs certifiées CE médical."
                )
            )

            extraDao.insertSupplierOrder(
                SupplierOrderEntity(
                    supplierId = sup2Id,
                    produit = "Lentilles focalisation ZnSe 20mm + Miroirs Silicium",
                    quantite = 10,
                    prix = 850.0,
                    transport = "FedEx Priority",
                    modePaiement = "Virement Bancaire (T/T)",
                    statut = "Reçu",
                    date = "2026-09-12"
                )
            )

            // 8. Financials: initial quote, payment, and expense
            extraDao.insertQuote(
                QuoteEntity(
                    numeroDevis = "DEV-2026-018",
                    clientId = c1Id,
                    machineId = m2Id,
                    date = "2026-09-25",
                    dateValidite = "2026-10-25",
                    statut = "Accepté",
                    prestations = 25000.0,
                    pieces = 16500.0,
                    deplacement = 3500.0,
                    remise = 0.0,
                    totalTtc = 45000.0,
                    notes = "Restauration circuit aspiration et changement électrovanne."
                )
            )

            extraDao.insertPayment(
                PaymentEntity(
                    quoteId = 1L,
                    clientId = c1Id,
                    montant = 45000.0,
                    date = "2026-09-28",
                    modePaiement = "BaridiMob",
                    notes = "Virement instantané reçu."
                )
            )

            extraDao.insertExpense(
                ExpenseEntity(
                    interventionId = int1Id,
                    categorie = "Carburant",
                    montant = 3500.0,
                    date = "2026-09-28",
                    description = "Déplacement clinique El Bahdja A/R"
                )
            )
        }
    }
}
