package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ExpenseEntity
import com.example.data.model.InterventionPhotoEntity
import com.example.data.model.KnowledgeBaseEntity
import com.example.data.model.MaintenanceScheduleEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.QuoteEntity
import com.example.data.model.SupplierEntity
import com.example.data.model.SupplierOrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExtraDao {
    // Quotes
    @Query("SELECT * FROM quotes ORDER BY id DESC")
    fun getAllQuotes(): Flow<List<QuoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuote(quote: QuoteEntity): Long

    @Update
    suspend fun updateQuote(quote: QuoteEntity)

    // Payments
    @Query("SELECT * FROM payments ORDER BY id DESC")
    fun getAllPayments(): Flow<List<PaymentEntity>>

    @Query("SELECT SUM(montant) FROM payments")
    fun getTotalCollected(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity): Long

    // Expenses
    @Query("SELECT * FROM expenses ORDER BY id DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT SUM(montant) FROM expenses")
    fun getTotalExpenses(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    // Maintenance Schedules
    @Query("SELECT * FROM maintenance_schedules WHERE actif = 1 ORDER BY prochaineMaintenance ASC")
    fun getActiveMaintenanceSchedules(): Flow<List<MaintenanceScheduleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenanceSchedule(schedule: MaintenanceScheduleEntity): Long

    // Knowledge Base
    @Query("SELECT * FROM knowledge_base ORDER BY id DESC")
    fun getAllKnowledgeBase(): Flow<List<KnowledgeBaseEntity>>

    @Query("SELECT * FROM knowledge_base WHERE machineType LIKE '%' || :query || '%' OR symptome LIKE '%' || :query || '%' OR codeErreur LIKE '%' || :query || '%' OR causeProbable LIKE '%' || :query || '%'")
    fun searchKnowledgeBase(query: String): Flow<List<KnowledgeBaseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKnowledgeBase(entry: KnowledgeBaseEntity): Long

    // Suppliers
    @Query("SELECT * FROM suppliers ORDER BY nom ASC")
    fun getAllSuppliers(): Flow<List<SupplierEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: SupplierEntity): Long

    @Update
    suspend fun updateSupplier(supplier: SupplierEntity)

    @Delete
    suspend fun deleteSupplier(supplier: SupplierEntity)

    // Supplier Orders
    @Query("SELECT * FROM supplier_orders WHERE supplierId = :supplierId ORDER BY id DESC")
    fun getOrdersForSupplier(supplierId: Long): Flow<List<SupplierOrderEntity>>

    @Query("SELECT * FROM supplier_orders ORDER BY id DESC")
    fun getAllSupplierOrders(): Flow<List<SupplierOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplierOrder(order: SupplierOrderEntity): Long

    @Update
    suspend fun updateSupplierOrder(order: SupplierOrderEntity)

    @Delete
    suspend fun deleteSupplierOrder(order: SupplierOrderEntity)

    // Intervention Photos
    @Query("SELECT * FROM intervention_photos WHERE interventionId = :interventionId ORDER BY id DESC")
    fun getPhotosForIntervention(interventionId: Long): Flow<List<InterventionPhotoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInterventionPhoto(photo: InterventionPhotoEntity): Long

    @Delete
    suspend fun deleteInterventionPhoto(photo: InterventionPhotoEntity)
}
