package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DiagnosticEntity
import com.example.data.model.InterventionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InterventionDao {
    @Query("SELECT * FROM interventions ORDER BY id DESC")
    fun getAllInterventions(): Flow<List<InterventionEntity>>

    @Query("SELECT * FROM interventions WHERE id = :id")
    fun getInterventionById(id: Long): Flow<InterventionEntity?>

    @Query("SELECT * FROM interventions WHERE machineId = :machineId ORDER BY id DESC")
    fun getInterventionsByMachineId(machineId: Long): Flow<List<InterventionEntity>>

    @Query("SELECT * FROM interventions WHERE clientId = :clientId ORDER BY id DESC")
    fun getInterventionsByClientId(clientId: Long): Flow<List<InterventionEntity>>

    @Query("SELECT * FROM interventions WHERE statut IN ('Nouveau', 'Planifié', 'En cours', 'En attente pièce') ORDER BY CASE priorite WHEN 'Urgent' THEN 1 WHEN 'Haute' THEN 2 WHEN 'Normale' THEN 3 ELSE 4 END")
    fun getActiveInterventions(): Flow<List<InterventionEntity>>

    @Query("SELECT * FROM interventions WHERE priorite = 'Urgent' AND statut != 'Terminé' AND statut != 'Annulé'")
    fun getUrgentInterventions(): Flow<List<InterventionEntity>>

    @Query("SELECT COUNT(*) FROM interventions WHERE statut IN ('En cours', 'Planifié', 'Nouveau')")
    fun getPendingCount(): Flow<Int>

    @Query("SELECT SUM(prixFacture) FROM interventions WHERE statut = 'Terminé'")
    fun getTotalRevenue(): Flow<Double?>

    @Query("SELECT SUM(coutTotal) FROM interventions WHERE statut = 'Terminé'")
    fun getTotalCost(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIntervention(intervention: InterventionEntity): Long

    @Update
    suspend fun updateIntervention(intervention: InterventionEntity)

    @Delete
    suspend fun deleteIntervention(intervention: InterventionEntity)

    // Diagnostics
    @Query("SELECT * FROM diagnostics WHERE interventionId = :interventionId")
    fun getDiagnosticsForIntervention(interventionId: Long): Flow<List<DiagnosticEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDiagnostic(diagnostic: DiagnosticEntity): Long
}
