package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.MachineEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MachineDao {
    @Query("SELECT * FROM machines ORDER BY marque ASC, modele ASC")
    fun getAllMachines(): Flow<List<MachineEntity>>

    @Query("SELECT * FROM machines WHERE id = :id")
    fun getMachineById(id: Long): Flow<MachineEntity?>

    @Query("SELECT * FROM machines WHERE id = :id")
    suspend fun getMachineByIdOnce(id: Long): MachineEntity?

    @Query("SELECT * FROM machines WHERE clientId = :clientId ORDER BY modele ASC")
    fun getMachinesByClientId(clientId: Long): Flow<List<MachineEntity>>

    @Query("SELECT * FROM machines WHERE type = :type ORDER BY marque ASC")
    fun getMachinesByType(type: String): Flow<List<MachineEntity>>

    @Query("SELECT * FROM machines WHERE marque LIKE '%' || :query || '%' OR modele LIKE '%' || :query || '%' OR numeroSerie LIKE '%' || :query || '%'")
    fun searchMachines(query: String): Flow<List<MachineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMachine(machine: MachineEntity): Long

    @Update
    suspend fun updateMachine(machine: MachineEntity)

    @Delete
    suspend fun deleteMachine(machine: MachineEntity)

    @Query("SELECT COUNT(*) FROM machines")
    fun getMachineCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM machines WHERE etat = 'En panne'")
    fun getBrokenMachinesCount(): Flow<Int>
}
