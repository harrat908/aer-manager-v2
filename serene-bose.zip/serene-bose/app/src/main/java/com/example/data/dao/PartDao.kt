package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PartEntity
import com.example.data.model.StockMovementEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PartDao {
    @Query("SELECT * FROM parts ORDER BY categorie ASC, nom ASC")
    fun getAllParts(): Flow<List<PartEntity>>

    @Query("SELECT * FROM parts WHERE id = :id")
    fun getPartById(id: Long): Flow<PartEntity?>

    @Query("SELECT * FROM parts WHERE stock <= stockMinimum ORDER BY stock ASC")
    fun getLowStockParts(): Flow<List<PartEntity>>

    @Query("SELECT COUNT(*) FROM parts WHERE stock <= stockMinimum")
    fun getLowStockCount(): Flow<Int>

    @Query("SELECT * FROM parts WHERE nom LIKE '%' || :query || '%' OR reference LIKE '%' || :query || '%'")
    fun searchParts(query: String): Flow<List<PartEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPart(part: PartEntity): Long

    @Update
    suspend fun updatePart(part: PartEntity)

    @Delete
    suspend fun deletePart(part: PartEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockMovement(movement: StockMovementEntity): Long

    @Query("SELECT * FROM stock_movements WHERE partId = :partId ORDER BY id DESC")
    fun getMovementsForPart(partId: Long): Flow<List<StockMovementEntity>>
}
