package com.example.data.firebase

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.BuildConfig
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject

sealed class AuthUiState {
    data object Idle : AuthUiState()
    data object Loading : AuthUiState()
    data class Authenticated(val user: FirebaseUser) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("aer_firebase_prefs", Context.MODE_PRIVATE)

    private var authListener: FirebaseAuth.AuthStateListener? = null

    private val auth: FirebaseAuth?
        get() = try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                FirebaseAuth.getInstance()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w("AuthManager", "FirebaseAuth instance: ${e.message}")
            null
        }

    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        tryEnsureInitialized()
        setupListener()
    }

    fun isFirebaseInitialized(): Boolean {
        return try {
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    private fun tryEnsureInitialized() {
        if (isFirebaseInitialized()) return
        val savedJson = prefs.getString("google_services_json", null)
        if (!savedJson.isNullOrBlank()) {
            tryInitFromJson(savedJson)
        }
        if (!isFirebaseInitialized()) {
            try {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:665347642811:android:554b9c55ae0b41bc22609e")
                    .setApiKey("AIzaSyB8bVV80S9GX9-8kJF5PRiXyvChFBhV-nM")
                    .setProjectId("aer-manager")
                    .setStorageBucket("aer-manager.firebasestorage.app")
                    .build()
                FirebaseApp.initializeApp(context, options)
            } catch (e: Exception) {
                Log.w("AuthManager", "Default FirebaseApp init: ${e.message}")
            }
        }
    }

    fun initializeWithGoogleServicesJson(jsonContent: String): Result<Boolean> {
        val res = tryInitFromJson(jsonContent)
        if (res.isSuccess) {
            prefs.edit().putString("google_services_json", jsonContent).apply()
            setupListener()
        }
        return res
    }

    private fun tryInitFromJson(jsonContent: String): Result<Boolean> {
        return try {
            val root = JSONObject(jsonContent)
            val projectInfo = root.getJSONObject("project_info")
            val projectId = projectInfo.getString("project_id")
            val storageBucket = projectInfo.optString("storage_bucket")
            val clientArr = root.getJSONArray("client")
            val clientObj = clientArr.getJSONObject(0)
            val clientInfo = clientObj.getJSONObject("client_info")
            val appId = clientInfo.getString("mobilesdk_app_id")
            val apiKeyArr = clientObj.getJSONArray("api_key")
            val apiKey = apiKeyArr.getJSONObject(0).getString("current_key")

            val options = FirebaseOptions.Builder()
                .setApplicationId(appId)
                .setApiKey(apiKey)
                .setProjectId(projectId)
                .apply {
                    if (storageBucket.isNotBlank()) setStorageBucket(storageBucket)
                }
                .build()

            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context, options)
            }
            Result.success(true)
        } catch (e: Exception) {
            Log.e("AuthManager", "Error initializing Firebase from JSON", e)
            Result.failure(Exception("Fichier JSON invalide ou incomplet : ${e.localizedMessage ?: e.message}"))
        }
    }

    private fun setupListener() {
        try {
            val a = auth ?: return
            authListener?.let { a.removeAuthStateListener(it) }
            val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
                val user = firebaseAuth.currentUser
                _currentUser.value = user
                _uiState.value = if (user != null) AuthUiState.Authenticated(user) else AuthUiState.Idle
            }
            a.addAuthStateListener(listener)
            authListener = listener
            _currentUser.value = a.currentUser
            if (a.currentUser != null) {
                _uiState.value = AuthUiState.Authenticated(a.currentUser!!)
            }
        } catch (e: Exception) {
            Log.w("AuthManager", "setupListener error: ${e.message}")
        }
    }

    fun getWebClientId(): String {
        return try {
            val raw = BuildConfig.GOOGLE_WEB_CLIENT_ID.trim()
            if (raw.contains(".apps.googleusercontent.com")) raw else ""
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun signInWithGoogle(context: Context): Result<FirebaseUser> = withContext(Dispatchers.IO) {
        if (!isFirebaseInitialized()) {
            return@withContext Result.failure(
                Exception("Firebase n'est pas encore initialisé avec un fichier google-services.json.")
            )
        }

        val serverClientId = getWebClientId()
        if (serverClientId.isBlank()) {
            val errMsg = "Le Web Client ID Google n'est pas configuré ou est invalide.\n\n" +
                    "Dans Firebase Console > Authentication > Sign-in method > Google, copiez l'ID client Web (format : 665347642811-...apps.googleusercontent.com) et renseignez-le dans les Secrets (GOOGLE_WEB_CLIENT_ID).\n\n" +
                    "👉 En attendant, utilisez la connexion par E-mail ou la Connexion Rapide Invité ci-dessous."
            _uiState.value = AuthUiState.Error(errMsg)
            return@withContext Result.failure(Exception(errMsg))
        }

        _uiState.value = AuthUiState.Loading

        try {
            val credentialManager = CredentialManager.create(context)

            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(serverClientId)
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result: GetCredentialResponse = credentialManager.getCredential(
                context = context,
                request = request
            )

            val credential = result.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken

                val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                val a = auth ?: throw Exception("FirebaseAuth non disponible.")
                val authResult = a.signInWithCredential(firebaseCredential).await()
                val user = authResult.user ?: throw Exception("Utilisateur introuvable après connexion Google.")

                _currentUser.value = user
                _uiState.value = AuthUiState.Authenticated(user)
                Result.success(user)
            } else {
                throw Exception("Format de credential Google non reconnu.")
            }
        } catch (e: GetCredentialCancellationException) {
            _uiState.value = AuthUiState.Idle
            Result.failure(Exception("Connexion Google annulée par l'utilisateur."))
        } catch (e: NoCredentialException) {
            val errMsg = "Aucun compte Google disponible sur cet appareil / émulateur.\n\n" +
                    "💡 Utilisez la Connexion par E-mail ou la Connexion Rapide (Mode Invité) pour synchroniser vos données immédiatement."
            _uiState.value = AuthUiState.Error(errMsg)
            Result.failure(Exception(errMsg))
        } catch (e: GetCredentialException) {
            Log.e("AuthManager", "GetCredentialException: ${e.message}", e)
            val errMsg = "Échec Google Credential: ${e.message}\nUtilisez la connexion E-mail ou Invité ci-dessous."
            _uiState.value = AuthUiState.Error(errMsg)
            Result.failure(Exception(errMsg))
        } catch (e: Exception) {
            Log.e("AuthManager", "signInWithGoogle exception: ${e.message}", e)
            _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Erreur de connexion Google.")
            Result.failure(e)
        }
    }

    suspend fun signInAnonymously(): Result<FirebaseUser> = withContext(Dispatchers.IO) {
        if (!isFirebaseInitialized()) {
            return@withContext Result.failure(Exception("Firebase n'est pas encore initialisé."))
        }

        _uiState.value = AuthUiState.Loading
        try {
            val a = auth ?: throw Exception("FirebaseAuth non disponible.")
            val res = a.signInAnonymously().await()
            val user = res.user ?: throw Exception("Connexion invité échouée.")
            _currentUser.value = user
            _uiState.value = AuthUiState.Authenticated(user)
            Result.success(user)
        } catch (e: Exception) {
            Log.e("AuthManager", "signInAnonymously error", e)
            _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Échec de connexion rapide.")
            Result.failure(e)
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): Result<FirebaseUser> = withContext(Dispatchers.IO) {
        if (!isFirebaseInitialized()) {
            return@withContext Result.failure(
                Exception("Firebase n'est pas encore initialisé avec google-services.json.")
            )
        }

        _uiState.value = AuthUiState.Loading
        try {
            val a = auth ?: throw Exception("FirebaseAuth non disponible.")
            val res = a.signInWithEmailAndPassword(email.trim(), pass).await()
            val user = res.user ?: throw Exception("Utilisateur introuvable.")
            _currentUser.value = user
            _uiState.value = AuthUiState.Authenticated(user)
            Result.success(user)
        } catch (e: Exception) {
            _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Échec d'authentification.")
            Result.failure(e)
        }
    }

    suspend fun signUpWithEmail(email: String, pass: String): Result<FirebaseUser> = withContext(Dispatchers.IO) {
        if (!isFirebaseInitialized()) {
            return@withContext Result.failure(
                Exception("Firebase n'est pas encore initialisé avec google-services.json.")
            )
        }

        _uiState.value = AuthUiState.Loading
        try {
            val a = auth ?: throw Exception("FirebaseAuth non disponible.")
            val res = a.createUserWithEmailAndPassword(email.trim(), pass).await()
            val user = res.user ?: throw Exception("Création de compte échouée.")
            _currentUser.value = user
            _uiState.value = AuthUiState.Authenticated(user)
            Result.success(user)
        } catch (e: Exception) {
            _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Échec de création de compte.")
            Result.failure(e)
        }
    }

    fun signOut() {
        try {
            auth?.signOut()
            _currentUser.value = null
            _uiState.value = AuthUiState.Idle
        } catch (e: Exception) {
            Log.e("AuthManager", "Sign out error", e)
        }
    }
}
