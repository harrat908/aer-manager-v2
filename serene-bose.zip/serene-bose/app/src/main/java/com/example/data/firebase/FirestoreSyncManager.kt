package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.data.model.ClientEntity
import com.example.data.model.DiagnosticEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.MachineEntity
import com.example.data.repository.AerRepository
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

data class SyncResult(
    val success: Boolean,
    val message: String,
    val clientsSynced: Int = 0,
    val machinesSynced: Int = 0,
    val interventionsSynced: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

class FirestoreSyncManager(private val context: Context) {

    private val firestore: FirebaseFirestore? by lazy {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                FirebaseFirestore.getInstance()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w("FirestoreSyncManager", "Firestore init: ${e.message}")
            null
        }
    }

    val isConfigured: Boolean
        get() = firestore != null

    suspend fun syncAll(userId: String, repository: AerRepository): SyncResult = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext SyncResult(
            success = false,
            message = "Firestore non initialisé (fichier google-services.json requis sur Firebase)"
        )

        try {
            val userDoc = db.collection("users").document(userId)

            // 1. Sync Clients
            val localClients = repository.getAllClients().first()
            var clientsSynced = 0
            for (c in localClients) {
                val data = mapOf(
                    "id" to c.id,
                    "nom" to c.nom,
                    "nomClinique" to c.nomClinique,
                    "telephone" to c.telephone,
                    "whatsapp" to c.whatsapp,
                    "email" to c.email,
                    "adresse" to c.adresse,
                    "ville" to c.ville,
                    "notes" to c.notes,
                    "updatedAt" to System.currentTimeMillis()
                )
                userDoc.collection("clients").document(c.id.toString())
                    .set(data, SetOptions.merge())
                    .await()
                clientsSynced++
            }

            // Also check for remote clients to import into local Room
            val remoteClientsSnap = userDoc.collection("clients").get().await()
            for (doc in remoteClientsSnap.documents) {
                val id = doc.getLong("id") ?: continue
                if (localClients.none { it.id == id }) {
                    val client = ClientEntity(
                        id = id,
                        nom = doc.getString("nom") ?: "",
                        nomClinique = doc.getString("nomClinique") ?: "",
                        telephone = doc.getString("telephone") ?: "",
                        whatsapp = doc.getString("whatsapp") ?: "",
                        email = doc.getString("email") ?: "",
                        adresse = doc.getString("adresse") ?: "",
                        ville = doc.getString("ville") ?: "",
                        notes = doc.getString("notes") ?: ""
                    )
                    repository.insertClient(client)
                    clientsSynced++
                }
            }

            // 2. Sync Machines
            val localMachines = repository.getAllMachines().first()
            var machinesSynced = 0
            for (m in localMachines) {
                val data = mapOf(
                    "id" to m.id,
                    "clientId" to m.clientId,
                    "marque" to m.marque,
                    "modele" to m.modele,
                    "type" to m.type,
                    "numeroSerie" to m.numeroSerie,
                    "dateAchat" to m.dateAchat,
                    "fournisseur" to m.fournisseur,
                    "dateInstallation" to m.dateInstallation,
                    "dureeGarantieMois" to m.dureeGarantieMois,
                    "dateFinGarantie" to m.dateFinGarantie,
                    "etat" to m.etat,
                    "localisationSalle" to m.localisationSalle,
                    "notes" to m.notes,
                    "updatedAt" to System.currentTimeMillis()
                )
                userDoc.collection("machines").document(m.id.toString())
                    .set(data, SetOptions.merge())
                    .await()
                machinesSynced++
            }

            // Also check for remote machines to import into local Room
            val remoteMachinesSnap = userDoc.collection("machines").get().await()
            for (doc in remoteMachinesSnap.documents) {
                val id = doc.getLong("id") ?: continue
                if (localMachines.none { it.id == id }) {
                    val machine = MachineEntity(
                        id = id,
                        clientId = doc.getLong("clientId") ?: 1L,
                        marque = doc.getString("marque") ?: "",
                        modele = doc.getString("modele") ?: "",
                        type = doc.getString("type") ?: "Autre",
                        numeroSerie = doc.getString("numeroSerie") ?: "",
                        dateAchat = doc.getString("dateAchat") ?: "",
                        fournisseur = doc.getString("fournisseur") ?: "",
                        dateInstallation = doc.getString("dateInstallation") ?: "",
                        dureeGarantieMois = doc.getLong("dureeGarantieMois")?.toInt() ?: 12,
                        dateFinGarantie = doc.getString("dateFinGarantie") ?: "",
                        etat = doc.getString("etat") ?: "En service",
                        localisationSalle = doc.getString("localisationSalle") ?: "",
                        notes = doc.getString("notes") ?: ""
                    )
                    repository.insertMachine(machine)
                    machinesSynced++
                }
            }

            // 3. Sync Interventions
            val localInterventions = repository.getAllInterventions().first()
            var interventionsSynced = 0
            for (i in localInterventions) {
                val data = mapOf(
                    "id" to i.id,
                    "numeroIntervention" to i.numeroIntervention,
                    "clientId" to i.clientId,
                    "machineId" to i.machineId,
                    "date" to i.date,
                    "technicien" to i.technicien,
                    "statut" to i.statut,
                    "priorite" to i.priorite,
                    "problemeSignale" to i.problemeSignale,
                    "diagnostic" to i.diagnostic,
                    "travailEffectue" to i.travailEffectue,
                    "recommandations" to i.recommandations,
                    "prixVentePieces" to i.prixVentePieces,
                    "mainOeuvreFacturee" to i.mainOeuvreFacturee,
                    "deplacementFacture" to i.deplacementFacture,
                    "fraisFactures" to i.fraisFactures,
                    "prixFacture" to i.prixFacture,
                    "coutPieces" to i.coutPieces,
                    "coutDeplacement" to i.coutDeplacement,
                    "autresFrais" to i.autresFrais,
                    "coutTotal" to i.coutTotal,
                    "benefice" to i.benefice,
                    "margePieces" to i.margePieces,
                    "coutMainOeuvre" to i.coutMainOeuvre,
                    "updatedAt" to System.currentTimeMillis()
                )
                userDoc.collection("interventions").document(i.id.toString())
                    .set(data, SetOptions.merge())
                    .await()
                interventionsSynced++
            }

            // Also check for remote interventions to import into local Room
            val remoteInterventionsSnap = userDoc.collection("interventions").get().await()
            for (doc in remoteInterventionsSnap.documents) {
                val id = doc.getLong("id") ?: continue
                if (localInterventions.none { it.id == id }) {
                    val intervention = InterventionEntity(
                        id = id,
                        numeroIntervention = doc.getString("numeroIntervention") ?: "",
                        clientId = doc.getLong("clientId") ?: 1L,
                        machineId = doc.getLong("machineId") ?: 1L,
                        date = doc.getString("date") ?: "",
                        technicien = doc.getString("technicien") ?: "Jules AER",
                        statut = doc.getString("statut") ?: "Planifié",
                        priorite = doc.getString("priorite") ?: "Normale",
                        problemeSignale = doc.getString("problemeSignale") ?: "",
                        diagnostic = doc.getString("diagnostic") ?: "",
                        travailEffectue = doc.getString("travailEffectue") ?: "",
                        recommandations = doc.getString("recommandations") ?: "",
                        prixVentePieces = doc.getDouble("prixVentePieces") ?: 0.0,
                        mainOeuvreFacturee = doc.getDouble("mainOeuvreFacturee") ?: (doc.getDouble("coutMainOeuvre") ?: 0.0),
                        deplacementFacture = doc.getDouble("deplacementFacture") ?: 0.0,
                        fraisFactures = doc.getDouble("fraisFactures") ?: 0.0,
                        prixFacture = doc.getDouble("prixFacture") ?: 0.0,
                        coutPieces = doc.getDouble("coutPieces") ?: 0.0,
                        coutDeplacement = doc.getDouble("coutDeplacement") ?: 0.0,
                        autresFrais = doc.getDouble("autresFrais") ?: 0.0,
                        coutTotal = doc.getDouble("coutTotal") ?: 0.0,
                        benefice = doc.getDouble("benefice") ?: 0.0,
                        margePieces = doc.getDouble("margePieces") ?: 0.0,
                        coutMainOeuvre = doc.getDouble("coutMainOeuvre") ?: 0.0
                    )
                    repository.insertIntervention(intervention)
                    interventionsSynced++
                }
            }

            SyncResult(
                success = true,
                message = "Synchronisation Cloud Firestore réussie !",
                clientsSynced = clientsSynced,
                machinesSynced = machinesSynced,
                interventionsSynced = interventionsSynced
            )
        } catch (e: Exception) {
            Log.e("FirestoreSyncManager", "Sync error", e)
            SyncResult(
                success = false,
                message = "Erreur de synchronisation Cloud: ${e.localizedMessage ?: e.message}"
            )
        }
    }
}
