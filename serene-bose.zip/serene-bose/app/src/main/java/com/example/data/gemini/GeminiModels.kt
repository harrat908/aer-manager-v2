package com.example.data.gemini

import java.util.UUID

data class GroundedPlace(
    val title: String,
    val uri: String? = null,
    val address: String? = null,
    val description: String? = null
)

sealed class AssistantAction {
    abstract val id: String
    abstract val isExecuted: Boolean
    abstract val executionResult: String?

    data class AddClient(
        override val id: String = UUID.randomUUID().toString(),
        val nom: String,
        val nomClinique: String = "",
        val telephone: String = "",
        val email: String = "",
        val ville: String = "",
        val adresse: String = "",
        val notes: String = "",
        override val isExecuted: Boolean = false,
        override val executionResult: String? = null
    ) : AssistantAction()

    data class AddMachine(
        override val id: String = UUID.randomUUID().toString(),
        val clientName: String = "",
        val marque: String,
        val modele: String,
        val type: String = "Autre",
        val numeroSerie: String = "",
        val localisationSalle: String = "",
        val notes: String = "",
        override val isExecuted: Boolean = false,
        override val executionResult: String? = null
    ) : AssistantAction()

    data class AddIntervention(
        override val id: String = UUID.randomUUID().toString(),
        val clientName: String = "",
        val machineName: String = "",
        val problemeSignale: String,
        val priorite: String = "Normale",
        val statut: String = "Planifié",
        override val isExecuted: Boolean = false,
        override val executionResult: String? = null
    ) : AssistantAction()
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String, // "user" or "model"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val modelName: String = "gemini-3.5-flash",
    val places: List<GroundedPlace> = emptyList(),
    val action: AssistantAction? = null,
    val isError: Boolean = false
)

enum class GeminiModelChoice(
    val modelId: String,
    val displayName: String,
    val badge: String,
    val description: String
) {
    FLASH_3_5(
        modelId = "gemini-3.5-flash",
        displayName = "Gemini 3.5 Flash",
        badge = "Général & Actions",
        description = "Recommandé pour les actions, diagnostics et la recherche Google Maps"
    ),
    PRO_3_1(
        modelId = "gemini-3.1-pro-preview",
        displayName = "Gemini 3.1 Pro",
        badge = "Raisonnement Expert",
        description = "Pour les pannes complexes, l'électronique de puissance et l'optique laser"
    ),
    LITE_3_1(
        modelId = "gemini-3.1-flash-lite-preview",
        displayName = "Gemini 3.1 Flash Lite",
        badge = "Ultra Rapide",
        description = "Pour les réponses instantanées, calculs et saisies rapides"
    )
}
