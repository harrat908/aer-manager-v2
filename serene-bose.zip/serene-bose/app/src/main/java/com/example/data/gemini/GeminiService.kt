package com.example.data.gemini

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val systemPrompt = """
        Tu es l'ingénieur biomédical et expert support technique SAV d'AER Manager.
        Tu es spécialisé dans la maintenance préventive et curative, le diagnostic de pannes et l'étalonnage des équipements médicaux et esthétiques :
        - Lasers CO₂ fractionnés et chirurgicaux (tubes RF / verre, optiques, miroirs galvanométriques).
        - Diode Laser 808nm / 755nm / 1064nm (modules bars, refroidissement Peltier / TEC, débit d'eau déminéralisée).
        - Nd:YAG Q-Switched & Pico (cavité laser, cristal Nd:YAG, lampe flash, détatouage et Hollywood peel).
        - IPL & DPL (lampes xénon, filtres optiques, capteurs de flux).
        - HIFU (transducteurs piézo-électriques, cartouches, moteurs pas-à-pas).
        - Radiofréquence bipolaire/fractionnée à micro-aiguilles et Cryolipolyse (pompes à vide, membranes, capteurs de température).
        - Hydrafacial, Cavitation et électrostimulation.

        LIGNES DIRECTRICES DE TES RÉPONSES :
        1. Donne des conseils précis, structurés (Symptômes constatés, Causes matérielles probables, Tests métrologiques avec multimètre / oscilloscope / joulemètre, Actions correctives, Consignes de sécurité laser classe 4).
        2. Si l'utilisateur demande des adresses, cliniques, médecins, magasins d'électronique ou revendeurs de matériel médical, utilise les données Maps fournies pour donner des adresses claires et précises.
        3. Réponds toujours en français professionnel, courtois et technique.

        CAPACITÉS D'ACTIONS DIRECTES DANS L'APPLICATION :
        Tu as le pouvoir d'ajouter automatiquement dans la base de données de l'application :
        - Un nouveau Client (médecin, clinique, centre d'esthétique)
        - Une nouvelle Machine (équipement biomédical, laser, HIFU, etc.)
        - Une nouvelle Intervention (maintenance préventive ou dépannage)

        Lorsque l'utilisateur te demande d'ajouter, enregistrer, insérer ou planifier un client, une machine ou une intervention, réponds avec un message d'explication poli, PUIS génère à la fin de ton message un bloc d'action structuré strict selon l'un de ces formats :

        Pour un client :
        [ACTION:ADD_CLIENT]
        {"nom": "Dr ...", "nomClinique": "Clinique ...", "telephone": "05...", "email": "...@...", "ville": "...", "adresse": "...", "notes": "..."}
        [/ACTION]

        Pour une machine :
        [ACTION:ADD_MACHINE]
        {"clientName": "Dr ...", "marque": "Alma Laser / Candela / etc.", "modele": "...", "type": "CO₂|Diode laser|Nd:YAG|IPL|HIFU|Hydrafacial|Cryolipolyse|RF|Cavitation|Autre", "numeroSerie": "...", "localisationSalle": "...", "notes": "..."}
        [/ACTION]

        Pour une intervention :
        [ACTION:ADD_INTERVENTION]
        {"clientName": "Dr ...", "machineName": "...", "problemeSignale": "...", "priorite": "Normale|Haute|Urgent", "statut": "Planifié"}
        [/ACTION]

        Ne génère ce bloc que si l'utilisateur sollicite explicitement un ajout, une création ou un enregistrement.
    """.trimIndent()

    suspend fun sendMessage(
        history: List<ChatMessage>,
        userMessage: String,
        modelChoice: GeminiModelChoice = GeminiModelChoice.FLASH_3_5,
        enableMapsGrounding: Boolean = false
    ): ChatMessage = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY.ifBlank { "" }
        } catch (_: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Check if user requested an action even without API key
            val offlineAction = extractOfflineAction(userMessage)
            return@withContext ChatMessage(
                role = "model",
                content = if (offlineAction != null) {
                    "J'ai préparé l'action demandée directement à partir de votre saisie. Cliquez sur le bouton ci-dessous pour l'enregistrer dans votre base de données locale :"
                } else {
                    "⚠️ Clé API Gemini non configurée.\n\nVeuillez renseigner votre clé API dans le panneau Secrets de Google AI Studio (`GEMINI_API_KEY`) ou dans le fichier `.env` pour activer l'assistant biomédical complet."
                },
                action = offlineAction,
                isError = offlineAction == null
            )
        }

        val primaryModel = if (enableMapsGrounding) "gemini-3.5-flash" else modelChoice.modelId

        // 1. First Attempt with requested configuration
        val firstResult = executeApiCall(
            modelName = primaryModel,
            userMessage = userMessage,
            history = history,
            enableMapsGrounding = enableMapsGrounding,
            apiKey = apiKey
        )

        if (firstResult.isSuccess) {
            return@withContext firstResult.getOrThrow()
        }

        val firstException = firstResult.exceptionOrNull()
        val isRateLimit = firstException?.message?.contains("429") == true ||
                firstException?.message?.contains("RESOURCE_EXHAUSTED") == true

        // 2. If Rate Limit 429 and Maps Grounding was enabled, retry without Maps
        if (isRateLimit && enableMapsGrounding) {
            Log.w("GeminiService", "Maps Grounding quota exceeded (429). Retrying without Maps tool...")
            val fallbackNoMaps = executeApiCall(
                modelName = "gemini-3.5-flash",
                userMessage = userMessage,
                history = history,
                enableMapsGrounding = false,
                apiKey = apiKey
            )
            if (fallbackNoMaps.isSuccess) {
                val orig = fallbackNoMaps.getOrThrow()
                return@withContext orig.copy(
                    content = "*(Note : Quota Google Maps temporairement atteint sur votre compte. Réponse fournie directement par l'IA biomédicale)*\n\n${orig.content}"
                )
            }
        }

        // 3. Fallback to Gemini 3.1 Flash Lite (higher limits)
        if (isRateLimit && primaryModel != "gemini-3.1-flash-lite-preview") {
            Log.w("GeminiService", "Quota exceeded on $primaryModel (429). Trying fallback to gemini-3.1-flash-lite-preview...")
            val fallbackLite = executeApiCall(
                modelName = "gemini-3.1-flash-lite-preview",
                userMessage = userMessage,
                history = history,
                enableMapsGrounding = false,
                apiKey = apiKey
            )
            if (fallbackLite.isSuccess) {
                val orig = fallbackLite.getOrThrow()
                return@withContext orig.copy(
                    content = "*(Note : Basculement automatique sur Gemini 3.1 Flash Lite)*\n\n${orig.content}",
                    modelName = "gemini-3.1-flash-lite-preview"
                )
            }
        }

        // 4. Offline diagnostic and action fallback
        val offlineAction = extractOfflineAction(userMessage)
        if (offlineAction != null) {
            return@withContext ChatMessage(
                role = "model",
                content = "J'ai extrait les informations pour votre enregistrement. Vérifiez les détails ci-dessous et confirmez l'enregistrement dans votre base de données :",
                action = offlineAction,
                modelName = "offline-action-engine",
                isError = false
            )
        }

        if (isRateLimit) {
            val localDiag = getLocalBiomedicalDiagnostic(userMessage)
            return@withContext ChatMessage(
                role = "model",
                content = """
                    ⚠️ **Limite de quota Gemini API atteinte (Erreur 429)**
                    
                    Votre clé gratuite Google AI Studio a temporairement atteint sa limite de requêtes.
                    
                    💡 **Conseils pratiques :**
                    1. Patientez 30 à 60 secondes avant de renvoyer votre question.
                    2. Sélectionnez le modèle **🚀 Flash Lite (Rapide)** dans la barre ci-dessus.
                    
                    ---
                    🔬 **Assistance Technique Immédiate (Base Biomédicale AER Locale) :**
                    $localDiag
                """.trimIndent(),
                modelName = "offline-fallback",
                isError = false
            )
        }

        ChatMessage(
            role = "model",
            content = "Erreur Gemini API ($primaryModel) : ${firstException?.message ?: "Erreur inconnue"}",
            isError = true
        )
    }

    private fun executeApiCall(
        modelName: String,
        userMessage: String,
        history: List<ChatMessage>,
        enableMapsGrounding: Boolean,
        apiKey: String
    ): Result<ChatMessage> {
        return try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val rootJson = JSONObject()

            // System Instruction
            val sysInstructionObj = JSONObject()
            val sysPartsArr = JSONArray().put(JSONObject().put("text", systemPrompt))
            sysInstructionObj.put("parts", sysPartsArr)
            rootJson.put("systemInstruction", sysInstructionObj)

            // Contents (Multi-turn conversation history)
            val contentsArr = JSONArray()
            val recentHistory = history.filter { !it.isError }.takeLast(8)
            for (msg in recentHistory) {
                val contentObj = JSONObject()
                contentObj.put("role", if (msg.role == "user") "user" else "model")
                val partsArr = JSONArray().put(JSONObject().put("text", msg.content))
                contentObj.put("parts", partsArr)
                contentsArr.put(contentObj)
            }

            // Current user message
            val currentObj = JSONObject()
            currentObj.put("role", "user")
            currentObj.put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
            contentsArr.put(currentObj)
            rootJson.put("contents", contentsArr)

            // Generation config
            val genConfig = JSONObject()
            genConfig.put("temperature", 0.7)
            genConfig.put("topP", 0.95)
            rootJson.put("generationConfig", genConfig)

            // Tools: Google Maps Grounding
            if (enableMapsGrounding) {
                val toolsArr = JSONArray()
                val toolObj = JSONObject()
                toolObj.put("googleMaps", JSONObject())
                toolsArr.put(toolObj)
                rootJson.put("tools", toolsArr)
            }

            val body = rootJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e("GeminiService", "API error: ${response.code} $responseBody")
                val errMsg = try {
                    val errJson = JSONObject(responseBody).optJSONObject("error")
                    errJson?.optString("message") ?: "Erreur HTTP ${response.code}"
                } catch (_: Exception) {
                    "Erreur HTTP ${response.code}"
                }
                return Result.failure(Exception("HTTP ${response.code}: $errMsg"))
            }

            val resJson = JSONObject(responseBody)
            val candidates = resJson.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            val replyTextBuilder = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.optJSONObject(i)
                    val t = p?.optString("text", "") ?: ""
                    replyTextBuilder.append(t)
                }
            }

            // Extract Grounding info (Places, Maps metadata)
            val places = mutableListOf<GroundedPlace>()
            val groundingMetadata = firstCandidate?.optJSONObject("groundingMetadata")
            if (groundingMetadata != null) {
                val groundingChunks = groundingMetadata.optJSONArray("groundingChunks")
                if (groundingChunks != null) {
                    for (i in 0 until groundingChunks.length()) {
                        val chunk = groundingChunks.optJSONObject(i)
                        val web = chunk?.optJSONObject("web")
                        val maps = chunk?.optJSONObject("maps") ?: chunk?.optJSONObject("place")
                        if (maps != null) {
                            val title = maps.optString("title", "").ifBlank { maps.optString("name", "Lieu Maps") }
                            val uriStr = maps.optString("uri", "").ifBlank { maps.optString("placeUri", "") }.ifBlank { null }
                            val addressStr = maps.optString("address", "").ifBlank { null }
                            val descStr = maps.optString("description", "").ifBlank { null }
                            places.add(
                                GroundedPlace(
                                    title = title,
                                    uri = uriStr,
                                    address = addressStr,
                                    description = descStr
                                )
                            )
                        } else if (web != null) {
                            val title = web.optString("title", "")
                            val uri = web.optString("uri", "")
                            if (title.isNotBlank()) {
                                places.add(GroundedPlace(title = title, uri = uri))
                            }
                        }
                    }
                }
            }

            val rawReply = replyTextBuilder.toString().ifBlank { "Aucune réponse textuelle reçue." }
            val (cleanReply, parsedAction) = parseAssistantAction(rawReply)

            Result.success(
                ChatMessage(
                    role = "model",
                    content = cleanReply,
                    modelName = modelName,
                    places = places,
                    action = parsedAction
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseAssistantAction(rawText: String): Pair<String, AssistantAction?> {
        // 1. Client Action
        val clientRegex = Regex("""\[ACTION:ADD_CLIENT\]\s*(\{.*?\})\s*\[/ACTION\]""", RegexOption.DOT_MATCHES_ALL)
        val clientMatch = clientRegex.find(rawText)
        if (clientMatch != null) {
            try {
                val obj = JSONObject(clientMatch.groupValues[1])
                val action = AssistantAction.AddClient(
                    nom = obj.optString("nom", "Nouveau Client"),
                    nomClinique = obj.optString("nomClinique", ""),
                    telephone = obj.optString("telephone", ""),
                    email = obj.optString("email", ""),
                    ville = obj.optString("ville", ""),
                    adresse = obj.optString("adresse", ""),
                    notes = obj.optString("notes", "")
                )
                val clean = rawText.replace(clientMatch.value, "").trim()
                return Pair(clean, action)
            } catch (e: Exception) {
                Log.w("GeminiService", "Client parse error: ${e.message}")
            }
        }

        // 2. Machine Action
        val machineRegex = Regex("""\[ACTION:ADD_MACHINE\]\s*(\{.*?\})\s*\[/ACTION\]""", RegexOption.DOT_MATCHES_ALL)
        val machineMatch = machineRegex.find(rawText)
        if (machineMatch != null) {
            try {
                val obj = JSONObject(machineMatch.groupValues[1])
                val action = AssistantAction.AddMachine(
                    clientName = obj.optString("clientName", ""),
                    marque = obj.optString("marque", "Générique"),
                    modele = obj.optString("modele", "Équipement"),
                    type = obj.optString("type", "Autre"),
                    numeroSerie = obj.optString("numeroSerie", ""),
                    localisationSalle = obj.optString("localisationSalle", ""),
                    notes = obj.optString("notes", "")
                )
                val clean = rawText.replace(machineMatch.value, "").trim()
                return Pair(clean, action)
            } catch (e: Exception) {
                Log.w("GeminiService", "Machine parse error: ${e.message}")
            }
        }

        // 3. Intervention Action
        val intRegex = Regex("""\[ACTION:ADD_INTERVENTION\]\s*(\{.*?\})\s*\[/ACTION\]""", RegexOption.DOT_MATCHES_ALL)
        val intMatch = intRegex.find(rawText)
        if (intMatch != null) {
            try {
                val obj = JSONObject(intMatch.groupValues[1])
                val action = AssistantAction.AddIntervention(
                    clientName = obj.optString("clientName", ""),
                    machineName = obj.optString("machineName", ""),
                    problemeSignale = obj.optString("problemeSignale", "Maintenance biomédicale"),
                    priorite = obj.optString("priorite", "Normale"),
                    statut = obj.optString("statut", "Planifié")
                )
                val clean = rawText.replace(intMatch.value, "").trim()
                return Pair(clean, action)
            } catch (e: Exception) {
                Log.w("GeminiService", "Intervention parse error: ${e.message}")
            }
        }

        return Pair(rawText, null)
    }

    private fun extractOfflineAction(userPrompt: String): AssistantAction? {
        val lower = userPrompt.lowercase()
        val isAdd = lower.contains("ajoute") || lower.contains("ajouter") || lower.contains("nouveau") ||
                lower.contains("nouvelle") || lower.contains("créer") || lower.contains("enregistre")

        if (!isAdd) return null

        return when {
            lower.contains("client") || lower.contains("docteur") || lower.contains("dr") || lower.contains("clinique") -> {
                // Extract name
                var nom = "Dr Nouveau Client"
                val drMatch = Regex("""dr\.?\s+([A-Za-zÀ-ÿ]+(?:\s+[A-Za-zÀ-ÿ]+)?)""", RegexOption.IGNORE_CASE).find(userPrompt)
                if (drMatch != null) {
                    nom = "Dr " + drMatch.groupValues[1].trim()
                }

                // Extract phone
                val phoneMatch = Regex("""(?:0|\+213)[5-7]\d{8}|0\d{9}""").find(userPrompt)
                val phone = phoneMatch?.value ?: ""

                // Extract city
                val city = when {
                    lower.contains("alger") -> "Alger"
                    lower.contains("oran") -> "Oran"
                    lower.contains("constantine") -> "Constantine"
                    lower.contains("blida") -> "Blida"
                    lower.contains("setif") || lower.contains("sétif") -> "Sétif"
                    lower.contains("annaba") -> "Annaba"
                    else -> "Alger"
                }

                AssistantAction.AddClient(
                    nom = nom,
                    nomClinique = if (lower.contains("clinique")) "Clinique Esthétique" else "",
                    telephone = phone,
                    ville = city,
                    notes = "Saisie assistée : $userPrompt"
                )
            }
            lower.contains("machine") || lower.contains("laser") || lower.contains("hifu") || lower.contains("diode") -> {
                val type = when {
                    lower.contains("co2") || lower.contains("co₂") -> "CO₂"
                    lower.contains("diode") || lower.contains("808") -> "Diode laser"
                    lower.contains("yag") || lower.contains("pico") -> "Nd:YAG"
                    lower.contains("hifu") -> "HIFU"
                    lower.contains("ipl") -> "IPL"
                    else -> "Autre"
                }
                AssistantAction.AddMachine(
                    clientName = if (lower.contains("dr")) "Dr Récent" else "",
                    marque = if (lower.contains("alma")) "Alma Laser" else if (lower.contains("candela")) "Candela" else "Laser Médical",
                    modele = if (lower.contains("pixel")) "Pixel CO2" else "Pro $type",
                    type = type,
                    numeroSerie = "SN-" + (System.currentTimeMillis() % 100000),
                    notes = "Saisie assistée : $userPrompt"
                )
            }
            lower.contains("intervention") || lower.contains("panne") || lower.contains("dépannage") || lower.contains("maintenance") -> {
                val priorite = if (lower.contains("urgent")) "Urgent" else if (lower.contains("haute")) "Haute" else "Normale"
                AssistantAction.AddIntervention(
                    clientName = "",
                    machineName = "",
                    problemeSignale = userPrompt.replace(Regex("""(?i)ajoute|crée|nouvelle|intervention"""), "").trim().ifBlank { "Maintenance curative" },
                    priorite = priorite,
                    statut = "Planifié"
                )
            }
            else -> null
        }
    }

    private fun getLocalBiomedicalDiagnostic(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("diode") || lower.contains("808") || lower.contains("tec") || lower.contains("peltier") || lower.contains("température") -> {
                """
                **Protocole Dépannage Diode Laser 808nm (Alarme Température / Refroidissement TEC) :**
                1. **Contrôle Hydraulique** : Vérifier le niveau d'eau déminéralisée et le débit (> 1.5 L/min). Purger les bulles d'air.
                2. **Module Peltier (TEC)** : Mesurer la tension aux bornes du module TEC dans la pièce à main (valeur nominale : 12V DC). Si 0V, vérifier le relais/MOSFET sur la carte driver.
                3. **Sonde de température** : Vérifier la valeur de la thermistance CTN 10kΩ à température ambiante (~10kΩ à 25°C). Si 0Ω ou infini, la sonde est en court-circuit ou coupée.
                4. **Ventilateurs & Radiateur** : Nettoyer la poussière sur le radiateur échangeur thermique.
                """.trimIndent()
            }
            lower.contains("co2") || lower.contains("co₂") || lower.contains("galvo") || lower.contains("miroir") -> {
                """
                **Protocole Dépannage Laser CO₂ (Défaut de Tir / Puissance / Alignement) :**
                1. **Alimentation Haute Tension** : Vérifier la présence du 48V DC en entrée du tube RF (ou le signal de commande PWM TTL sur le port CTRL).
                2. **Pointeur Rouge 650nm** : Vérifier si le faisceau pilote rouge est visible. S'il n'apparaît pas, vérifier l'alignement du combineur de faisceau.
                3. **Optiques Galvanométriques** : Nettoyer délicatement les miroirs X/Y de la tête scanner avec un coton-tige imbibé d'alcool isopropylique à 99%.
                4. **Sécurité Interlock** : Vérifier la continuité électrique de la boucle d'interlock et du switch de pédale de tir.
                """.trimIndent()
            }
            lower.contains("yag") || lower.contains("q-switched") || lower.contains("tatouage") || lower.contains("pico") -> {
                """
                **Protocole Dépannage Laser Nd:YAG Q-Switched :**
                1. **Lampe Flash au Xénon** : Vérifier la tension de pré-ionisation (Simmer ~800V - 1000V). Si la lampe ne s'amorce pas, remplacer la carte simmer ou la lampe.
                2. **Miroirs de Cavité** : Vérifier l'alignement des miroirs HR (Total) et OC (Sortie) à l'aide d'un laser he-ne ou diode d'alignement.
                3. **Cristal Nd:YAG** : Inspecter les faces du barreau Nd:YAG (absence d'impacts ou de dépôts de poussière brûlée).
                4. **Capteur d'Énergie** : Mesurer l'énergie de sortie avec un joulemètre étalonné.
                """.trimIndent()
            }
            lower.contains("e02") || lower.contains("e01") || lower.contains("debit") || lower.contains("eau") || lower.contains("flow") -> {
                """
                **Défaut Circuit d'Eau / Capteur de Débit (E01 / E02) :**
                1. **Capteur de Débit** : Déconnecter le capteur de débit à palette ou à effet Hall et vérifier la rotation de la turbine.
                2. **Pompe à Eau (12V/24V)** : Vérifier que la pompe tourne et vibre sans bruit anormal de cavitation.
                3. **Filtre & Raccords** : Dévisser le filtre en ligne et rincer la crépine métallique. Vérifier que les connecteurs rapides CPC s'ouvrent correctement.
                4. **Purger l'air** : Faire tourner la pompe bouchon de réservoir ouvert pour chasser l'air bloqué dans les conduits.
                """.trimIndent()
            }
            else -> {
                """
                **Guide de Diagnostic Rapide Biomédical :**
                1. **Alimentation Générale** : Vérifier la tension secteur (230V ±10%) et la continuité du disjoncteur différentiel.
                2. **Cartes Électroniques** : Vérifier visuellement l'état des condensateurs de filtrage et les voyants LED d'état des alimentations secondaires (5V, 12V, 24V).
                3. **Boucle de Sécurité** : Vérifier l'arrêt d'urgence mécanique (coup de poing), la clé de contact et l'interlock de porte.
                4. **Connectique** : Vérifier le serrage des borniers de puissance et l'état des câbles blindés de commande.
                """.trimIndent()
            }
        }
    }
}
