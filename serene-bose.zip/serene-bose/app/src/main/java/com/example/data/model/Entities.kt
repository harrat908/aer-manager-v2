package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "clients")
data class ClientEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nom: String,
    val nomClinique: String,
    val telephone: String,
    val whatsapp: String,
    val email: String,
    val adresse: String,
    val ville: String,
    val notes: String = "",
    val dateCreation: String = ""
)

@Entity(
    tableName = "machines",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class MachineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val clientId: Long,
    val marque: String,
    val modele: String,
    val type: String, // CO₂, Diode laser, Nd:YAG, IPL, HIFU, Hydrafacial, Cryolipolyse, RF, Cavitation, Physiothérapie, Autre
    val numeroSerie: String,
    val dateAchat: String,
    val fournisseur: String,
    val dateInstallation: String,
    val dureeGarantieMois: Int = 12,
    val dateFinGarantie: String,
    val etat: String = "En service", // En service, En panne, En maintenance, Réformé
    val localisationSalle: String = "",
    val notes: String = ""
)

@Entity(
    tableName = "interventions",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MachineEntity::class,
            parentColumns = ["id"],
            childColumns = ["machineId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId"), Index("machineId")]
)
data class InterventionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val numeroIntervention: String, // e.g. INT-2026-001
    val clientId: Long,
    val machineId: Long,
    val technicien: String = "Jules AER",
    val date: String,
    val statut: String = "Planifié", // Nouveau, Planifié, En cours, En attente pièce, Terminé, Annulé
    val priorite: String = "Normale", // Urgent, Haute, Normale, Faible
    val problemeSignale: String,
    val diagnostic: String = "",
    val travailEffectue: String = "",
    val recommandations: String = "",

    // REVENUS FACTURÉS AU CLIENT
    val prixVentePieces: Double = 0.0,      // Prix facturé au client pour les pièces
    val mainOeuvreFacturee: Double = 0.0,   // Main-d'œuvre facturée au client (Revenu direct)
    val deplacementFacture: Double = 0.0,   // Déplacement facturé au client (Revenu)
    val fraisFactures: Double = 0.0,        // Frais supplémentaires facturés au client (Revenu)
    val prixFacture: Double = 0.0,          // Total facturé client (CA)

    // CHARGES RÉELLES DÉBOURSÉES (INTERNES)
    val coutPieces: Double = 0.0,           // Prix d'achat réel des pièces (Charge)
    val coutDeplacement: Double = 0.0,      // Coût réel de déplacement / carburant (Charge)
    val autresFrais: Double = 0.0,          // Coûts réels supplémentaires déboursés (Charge)
    val coutTotal: Double = 0.0,            // Total des charges réelles = coutPieces + coutDeplacement + autresFrais

    // INDICATEURS FINANCIERS
    val benefice: Double = 0.0,             // Bénéfice réel = prixFacture - coutTotal
    val margePieces: Double = 0.0,          // Marge commerciale pièces = prixVentePieces - coutPieces

    // Ancien champ conservé avec valeur par défaut pour rétro-compatibilité
    val coutMainOeuvre: Double = 0.0
) {
    val effectivePrixVentePieces: Double
        get() = if (prixVentePieces > 0.0) prixVentePieces else if (coutPieces > 0.0 && prixFacture >= coutPieces) coutPieces else 0.0

    val effectiveMainOeuvreFacturee: Double
        get() = if (mainOeuvreFacturee > 0.0) mainOeuvreFacturee else coutMainOeuvre

    val effectiveDeplacementFacture: Double
        get() = if (deplacementFacture > 0.0) deplacementFacture else 0.0

    val effectiveFraisFactures: Double
        get() = if (fraisFactures > 0.0) fraisFactures else 0.0

    val effectiveRevenue: Double
        get() = if (prixFacture > 0.0) {
            prixFacture
        } else {
            effectivePrixVentePieces + effectiveMainOeuvreFacturee + effectiveDeplacementFacture + effectiveFraisFactures
        }

    val effectiveChargesReelles: Double
        get() = coutPieces + coutDeplacement + autresFrais

    val effectiveBenefice: Double
        get() = effectiveRevenue - effectiveChargesReelles

    val effectiveMargePieces: Double
        get() = if (prixVentePieces > 0.0 || coutPieces > 0.0) {
            prixVentePieces - coutPieces
        } else margePieces
}

@Entity(
    tableName = "diagnostics",
    foreignKeys = [
        ForeignKey(
            entity = InterventionEntity::class,
            parentColumns = ["id"],
            childColumns = ["interventionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("interventionId")]
)
data class DiagnosticEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val interventionId: Long,
    val symptome: String,
    val causeProbable: String,
    val testsEffectues: String,
    val mesures: String,
    val resultat: String,
    val solution: String
)

@Entity(tableName = "parts")
data class PartEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val reference: String,
    val nom: String,
    val categorie: String, // Lasers, Optique, Électronique, Hydraulique, Consommables
    val stock: Int,
    val stockMinimum: Int,
    val prixAchat: Double,
    val prixVente: Double,
    val fournisseur: String,
    val emplacement: String,
    val notes: String = ""
) {
    val partMargin: Double
        get() = prixVente - prixAchat
}

@Entity(
    tableName = "stock_movements",
    foreignKeys = [
        ForeignKey(
            entity = PartEntity::class,
            parentColumns = ["id"],
            childColumns = ["partId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("partId")]
)
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val partId: Long,
    val interventionId: Long? = null,
    val quantite: Int,
    val date: String,
    val type: String, // SORTIE_INTERVENTION, ENTREE_COMMANDE, AJUSTEMENT
    val motif: String = ""
)

@Entity(
    tableName = "quotes",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class QuoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val numeroDevis: String,
    val clientId: Long,
    val machineId: Long? = null,
    val date: String,
    val dateValidite: String,
    val statut: String = "Brouillon", // Brouillon, Envoyé, Accepté, Refusé, Expiré
    val prestations: Double = 0.0,
    val pieces: Double = 0.0,
    val deplacement: Double = 0.0,
    val remise: Double = 0.0,
    val totalTtc: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val quoteId: Long? = null,
    val clientId: Long,
    val montant: Double,
    val date: String,
    val modePaiement: String, // Espèces, Virement, CCP, BaridiMob, Autre
    val notes: String = ""
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val interventionId: Long? = null,
    val categorie: String, // Transport, Taxi, Carburant, Repas, Hébergement, Autre
    val montant: Double,
    val date: String,
    val description: String = ""
)

@Entity(
    tableName = "maintenance_schedules",
    foreignKeys = [
        ForeignKey(
            entity = MachineEntity::class,
            parentColumns = ["id"],
            childColumns = ["machineId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("machineId")]
)
data class MaintenanceScheduleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val machineId: Long,
    val typeMaintenance: String,
    val intervalleMois: Int,
    val derniereMaintenance: String,
    val prochaineMaintenance: String,
    val notes: String = "",
    val actif: Boolean = true
)

@Entity(tableName = "knowledge_base")
data class KnowledgeBaseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val machineType: String,
    val codeErreur: String,
    val symptome: String,
    val causeProbable: String,
    val tests: String,
    val solution: String,
    val piecesRecommandees: String = ""
)

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nom: String,
    val pays: String,
    val contact: String,
    val whatsapp: String,
    val wechat: String = "",
    val alibaba: String = "",
    val email: String,
    val notes: String = ""
)

@Entity(
    tableName = "supplier_orders",
    foreignKeys = [
        ForeignKey(
            entity = SupplierEntity::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("supplierId")]
)
data class SupplierOrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val supplierId: Long,
    val produit: String,
    val quantite: Int,
    val prix: Double,
    val transport: String = "DHL Express", // DHL, Fedex, Air cargo, Maritime
    val modePaiement: String = "Virement Bancaire (T/T)", // Virement, Western Union, TT, PayPal, Alibaba Trade Assurance
    val statut: String = "En cours", // Commandé, Expédié, En douane, Reçu, Annulé
    val date: String
)

@Entity(
    tableName = "intervention_photos",
    foreignKeys = [
        ForeignKey(
            entity = InterventionEntity::class,
            parentColumns = ["id"],
            childColumns = ["interventionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("interventionId")]
)
data class InterventionPhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val interventionId: Long,
    val photoUri: String,
    val categorie: String, // AVANT, APRÈS, CARTE ÉLECTRONIQUE, PLAQUE SIGNALÉTIQUE, MESURES, AUTRE
    val description: String = "",
    val datePrise: String = ""
)

