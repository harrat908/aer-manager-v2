package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

data class TechnicianProfile(
    val nom: String = "Jules AER",
    val titre: String = "Ingénieur Biomédical & SAV Lasers",
    val telephone: String = "+213 550 00 00 00",
    val email: String = "sav@aer-equipment.dz",
    val entreprise: String = "AER • Aesthetic Equipment Repair",
    val adresse: String = "Alger, Algérie"
)

class TechnicianProfileManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("aer_technician_prefs", Context.MODE_PRIVATE)

    fun getProfile(): TechnicianProfile {
        return TechnicianProfile(
            nom = prefs.getString("tech_nom", "Jules AER")?.ifBlank { "Jules AER" } ?: "Jules AER",
            titre = prefs.getString("tech_titre", "Ingénieur Biomédical & SAV Lasers")?.ifBlank { "Ingénieur Biomédical & SAV Lasers" } ?: "Ingénieur Biomédical & SAV Lasers",
            telephone = prefs.getString("tech_telephone", "+213 550 00 00 00")?.ifBlank { "+213 550 00 00 00" } ?: "+213 550 00 00 00",
            email = prefs.getString("tech_email", "sav@aer-equipment.dz")?.ifBlank { "sav@aer-equipment.dz" } ?: "sav@aer-equipment.dz",
            entreprise = prefs.getString("tech_entreprise", "AER • Aesthetic Equipment Repair")?.ifBlank { "AER • Aesthetic Equipment Repair" } ?: "AER • Aesthetic Equipment Repair",
            adresse = prefs.getString("tech_adresse", "Alger, Algérie")?.ifBlank { "Alger, Algérie" } ?: "Alger, Algérie"
        )
    }

    fun saveProfile(profile: TechnicianProfile) {
        prefs.edit()
            .putString("tech_nom", profile.nom.trim())
            .putString("tech_titre", profile.titre.trim())
            .putString("tech_telephone", profile.telephone.trim())
            .putString("tech_email", profile.email.trim())
            .putString("tech_entreprise", profile.entreprise.trim())
            .putString("tech_adresse", profile.adresse.trim())
            .apply()
    }
}
