package com.example.data.repository

import com.example.data.AppDatabase
import com.example.data.model.ClientEntity
import com.example.data.model.DiagnosticEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.InterventionPhotoEntity
import com.example.data.model.KnowledgeBaseEntity
import com.example.data.model.MachineEntity
import com.example.data.model.MaintenanceScheduleEntity
import com.example.data.model.PartEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.QuoteEntity
import com.example.data.model.SupplierEntity
import com.example.data.model.SupplierOrderEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class AerRepository(private val db: AppDatabase) {
    private val clientDao = db.clientDao()
    private val machineDao = db.machineDao()
    private val interventionDao = db.interventionDao()
    private val partDao = db.partDao()
    private val extraDao = db.extraDao()

    // --- Clients ---
    fun getAllClients(): Flow<List<ClientEntity>> = clientDao.getAllClients()
    fun getClientById(id: Long): Flow<ClientEntity?> = clientDao.getClientById(id)
    suspend fun getClientByIdOnce(id: Long): ClientEntity? = clientDao.getClientByIdOnce(id)
    fun searchClients(query: String): Flow<List<ClientEntity>> = clientDao.searchClients(query)
    suspend fun insertClient(client: ClientEntity): Long = clientDao.insertClient(client)
    suspend fun updateClient(client: ClientEntity) = clientDao.updateClient(client)
    suspend fun deleteClient(client: ClientEntity) = clientDao.deleteClient(client)

    // --- Machines ---
    fun getAllMachines(): Flow<List<MachineEntity>> = machineDao.getAllMachines()
    fun getMachineById(id: Long): Flow<MachineEntity?> = machineDao.getMachineById(id)
    suspend fun getMachineByIdOnce(id: Long): MachineEntity? = machineDao.getMachineByIdOnce(id)
    fun getMachinesByClientId(clientId: Long): Flow<List<MachineEntity>> = machineDao.getMachinesByClientId(clientId)
    fun getMachinesByType(type: String): Flow<List<MachineEntity>> = machineDao.getMachinesByType(type)
    fun searchMachines(query: String): Flow<List<MachineEntity>> = machineDao.searchMachines(query)
    suspend fun insertMachine(machine: MachineEntity): Long = machineDao.insertMachine(machine)
    suspend fun updateMachine(machine: MachineEntity) = machineDao.updateMachine(machine)
    suspend fun deleteMachine(machine: MachineEntity) = machineDao.deleteMachine(machine)

    // --- Interventions ---
    fun getAllInterventions(): Flow<List<InterventionEntity>> = interventionDao.getAllInterventions()
    fun getInterventionById(id: Long): Flow<InterventionEntity?> = interventionDao.getInterventionById(id)
    fun getInterventionsByMachineId(machineId: Long): Flow<List<InterventionEntity>> = interventionDao.getInterventionsByMachineId(machineId)
    fun getInterventionsByClientId(clientId: Long): Flow<List<InterventionEntity>> = interventionDao.getInterventionsByClientId(clientId)
    fun getActiveInterventions(): Flow<List<InterventionEntity>> = interventionDao.getActiveInterventions()
    fun getUrgentInterventions(): Flow<List<InterventionEntity>> = interventionDao.getUrgentInterventions()
    suspend fun insertIntervention(intervention: InterventionEntity): Long = interventionDao.insertIntervention(intervention)
    suspend fun updateIntervention(intervention: InterventionEntity) = interventionDao.updateIntervention(intervention)
    suspend fun deleteIntervention(intervention: InterventionEntity) = interventionDao.deleteIntervention(intervention)

    fun getDiagnosticsForIntervention(interventionId: Long): Flow<List<DiagnosticEntity>> =
        interventionDao.getDiagnosticsForIntervention(interventionId)
    suspend fun insertDiagnostic(diagnostic: DiagnosticEntity): Long =
        interventionDao.insertDiagnostic(diagnostic)

    // --- Stock & Parts ---
    fun getAllParts(): Flow<List<PartEntity>> = partDao.getAllParts()
    fun getLowStockParts(): Flow<List<PartEntity>> = partDao.getLowStockParts()
    fun searchParts(query: String): Flow<List<PartEntity>> = partDao.searchParts(query)
    suspend fun insertPart(part: PartEntity): Long = partDao.insertPart(part)
    suspend fun updatePart(part: PartEntity) = partDao.updatePart(part)
    suspend fun deletePart(part: PartEntity) = partDao.deletePart(part)

    // --- Extra: Quotes, Payments, Expenses, Maintenance, KB, Suppliers ---
    fun getAllQuotes(): Flow<List<QuoteEntity>> = extraDao.getAllQuotes()
    suspend fun insertQuote(quote: QuoteEntity): Long = extraDao.insertQuote(quote)

    fun getAllPayments(): Flow<List<PaymentEntity>> = extraDao.getAllPayments()
    suspend fun insertPayment(payment: PaymentEntity): Long = extraDao.insertPayment(payment)

    fun getAllExpenses(): Flow<List<ExpenseEntity>> = extraDao.getAllExpenses()
    suspend fun insertExpense(expense: ExpenseEntity): Long = extraDao.insertExpense(expense)

    fun getActiveMaintenance(): Flow<List<MaintenanceScheduleEntity>> = extraDao.getActiveMaintenanceSchedules()
    suspend fun insertMaintenance(schedule: MaintenanceScheduleEntity): Long = extraDao.insertMaintenanceSchedule(schedule)

    fun getKnowledgeBase(query: String = ""): Flow<List<KnowledgeBaseEntity>> =
        if (query.isBlank()) extraDao.getAllKnowledgeBase() else extraDao.searchKnowledgeBase(query)
    suspend fun insertKnowledgeBase(entry: KnowledgeBaseEntity): Long = extraDao.insertKnowledgeBase(entry)

    fun getAllSuppliers(): Flow<List<SupplierEntity>> = extraDao.getAllSuppliers()
    suspend fun insertSupplier(supplier: SupplierEntity): Long = extraDao.insertSupplier(supplier)
    suspend fun updateSupplier(supplier: SupplierEntity) = extraDao.updateSupplier(supplier)
    suspend fun deleteSupplier(supplier: SupplierEntity) = extraDao.deleteSupplier(supplier)

    fun getOrdersForSupplier(supplierId: Long): Flow<List<SupplierOrderEntity>> = extraDao.getOrdersForSupplier(supplierId)
    fun getAllSupplierOrders(): Flow<List<SupplierOrderEntity>> = extraDao.getAllSupplierOrders()
    suspend fun insertSupplierOrder(order: SupplierOrderEntity): Long = extraDao.insertSupplierOrder(order)
    suspend fun updateSupplierOrder(order: SupplierOrderEntity) = extraDao.updateSupplierOrder(order)
    suspend fun deleteSupplierOrder(order: SupplierOrderEntity) = extraDao.deleteSupplierOrder(order)

    // --- Intervention Photos ---
    fun getPhotosForIntervention(interventionId: Long): Flow<List<InterventionPhotoEntity>> =
        extraDao.getPhotosForIntervention(interventionId)
    suspend fun insertInterventionPhoto(photo: InterventionPhotoEntity): Long =
        extraDao.insertInterventionPhoto(photo)
    suspend fun deleteInterventionPhoto(photo: InterventionPhotoEntity) =
        extraDao.deleteInterventionPhoto(photo)

    // --- Dashboard Combined Metrics ---
    private val operationsFlow = combine(
        interventionDao.getActiveInterventions(),
        interventionDao.getUrgentInterventions(),
        machineDao.getBrokenMachinesCount(),
        partDao.getLowStockCount()
    ) { activeInt, urgentInt, brokenCount, lowStock ->
        OpsMetrics(activeInt.size, urgentInt.size, brokenCount, lowStock)
    }

    private val financeFlow = combine(
        extraDao.getTotalCollected(),
        extraDao.getTotalExpenses(),
        clientDao.getClientCount(),
        machineDao.getMachineCount()
    ) { totalCollected, totalExpenses, clientCount, machineCount ->
        FinanceMetrics(totalCollected ?: 0.0, totalExpenses ?: 0.0, clientCount, machineCount)
    }

    val dashboardMetrics: Flow<DashboardSummary> = combine(operationsFlow, financeFlow) { ops, fin ->
        DashboardSummary(
            activeInterventionsCount = ops.active,
            urgentInterventionsCount = ops.urgent,
            brokenMachinesCount = ops.broken,
            lowStockPartsCount = ops.lowStock,
            monthlyRevenue = fin.revenue,
            monthlyExpenses = fin.expenses,
            estimatedProfit = fin.revenue - fin.expenses,
            totalClients = fin.clients,
            totalMachines = fin.machines
        )
    }
}

private data class OpsMetrics(val active: Int, val urgent: Int, val broken: Int, val lowStock: Int)
private data class FinanceMetrics(val revenue: Double, val expenses: Double, val clients: Int, val machines: Int)

data class DashboardSummary(
    val activeInterventionsCount: Int = 0,
    val urgentInterventionsCount: Int = 0,
    val brokenMachinesCount: Int = 0,
    val lowStockPartsCount: Int = 0,
    val monthlyRevenue: Double = 0.0,
    val monthlyExpenses: Double = 0.0,
    val estimatedProfit: Double = 0.0,
    val totalClients: Int = 0,
    val totalMachines: Int = 0
)
