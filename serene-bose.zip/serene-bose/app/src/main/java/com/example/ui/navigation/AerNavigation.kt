package com.example.ui.navigation

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.firebase.AuthManager
import com.example.data.firebase.FirestoreSyncManager
import com.example.data.repository.AerRepository
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.chatbot.ChatViewModel
import com.example.ui.screens.chatbot.ChatbotScreen
import com.example.ui.screens.clients.AddEditClientScreen
import com.example.ui.screens.clients.ClientDetailScreen
import com.example.ui.screens.clients.ClientsScreen
import com.example.ui.screens.clients.ClientsViewModel
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.dashboard.DashboardViewModel
import com.example.ui.screens.interventions.AddInterventionScreen
import com.example.ui.screens.interventions.InterventionDetailScreen
import com.example.ui.screens.interventions.InterventionsScreen
import com.example.ui.screens.interventions.InterventionsViewModel
import com.example.ui.screens.knowledge.KnowledgeBaseScreen
import com.example.ui.screens.machines.AddEditMachineScreen
import com.example.ui.screens.machines.MachineDetailScreen
import com.example.ui.screens.machines.MachinesScreen
import com.example.ui.screens.machines.MachinesViewModel
import com.example.ui.screens.maintenance.MaintenanceScreen
import com.example.ui.screens.quotes.QuotesScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.stock.StockScreen
import com.example.ui.screens.stock.StockViewModel
import com.example.ui.screens.suppliers.SuppliersScreen

sealed class BottomNavItem(val route: String, val title: String, val icon: ImageVector) {
    data object Dashboard : BottomNavItem(Screen.Dashboard.route, "Tableau", Icons.Default.Dashboard)
    data object Interventions : BottomNavItem(Screen.Interventions.route, "Interventions", Icons.Default.Handyman)
    data object Clients : BottomNavItem(Screen.Clients.route, "Clients", Icons.Default.Business)
    data object Machines : BottomNavItem(Screen.Machines.route, "Machines", Icons.Default.Devices)
    data object Chatbot : BottomNavItem(Screen.Chatbot.route, "Assistant IA", Icons.Default.AutoAwesome)
}

@Composable
fun AerAppNavigation(repository: AerRepository) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val context = LocalContext.current

    val authManager = remember { AuthManager(context) }
    val syncManager = remember { FirestoreSyncManager(context) }

    val bottomNavItems = listOf(
        BottomNavItem.Dashboard,
        BottomNavItem.Interventions,
        BottomNavItem.Clients,
        BottomNavItem.Machines,
        BottomNavItem.Chatbot
    )

    // Check if bottom bar should be shown (on root screens)
    val showBottomBar = bottomNavItems.any { it.route == currentRoute }

    // Shared ViewModels via factories
    val dashboardViewModel: DashboardViewModel = viewModel(factory = DashboardViewModel.Factory(repository))
    val clientsViewModel: ClientsViewModel = viewModel(factory = ClientsViewModel.Factory(repository))
    val machinesViewModel: MachinesViewModel = viewModel(factory = MachinesViewModel.Factory(repository))
    val interventionsViewModel: InterventionsViewModel = viewModel(factory = InterventionsViewModel.Factory(repository))
    val stockViewModel: StockViewModel = viewModel(factory = StockViewModel.Factory(repository))
    val chatViewModel: ChatViewModel = viewModel(factory = ChatViewModel.Factory(repository = repository))

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    bottomNavItems.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.title) },
                            label = { Text(item.title) },
                            modifier = Modifier.testTag("nav_item_${item.route}")
                        )
                    }
                }
            }
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. Dashboard
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    viewModel = dashboardViewModel,
                    onNavigateToAddClient = { navController.navigate(Screen.AddEditClient.createRoute()) },
                    onNavigateToAddMachine = { navController.navigate(Screen.AddEditMachine.createRoute()) },
                    onNavigateToAddIntervention = { navController.navigate(Screen.AddIntervention.createRoute()) },
                    onNavigateToQuotes = { navController.navigate(Screen.Quotes.route) },
                    onNavigateToStock = { navController.navigate(Screen.Stock.route) },
                    onNavigateToMaintenance = { navController.navigate(Screen.Maintenance.route) },
                    onNavigateToKnowledgeBase = { navController.navigate(Screen.KnowledgeBase.route) },
                    onNavigateToInterventions = { navController.navigate(Screen.Interventions.route) },
                    onNavigateToInterventionDetail = { id -> navController.navigate(Screen.InterventionDetail.createRoute(id)) },
                    onNavigateToClients = { navController.navigate(Screen.Clients.route) },
                    onNavigateToMachines = { navController.navigate(Screen.Machines.route) },
                    onNavigateToSuppliers = { navController.navigate(Screen.Suppliers.route) },
                    onNavigateToChatbot = { navController.navigate(Screen.Chatbot.route) },
                    onNavigateToAuth = { navController.navigate(Screen.Auth.route) },
                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            // 2. Clients
            composable(Screen.Clients.route) {
                ClientsScreen(
                    viewModel = clientsViewModel,
                    onClientClick = { clientId -> navController.navigate(Screen.ClientDetail.createRoute(clientId)) },
                    onAddClientClick = { navController.navigate(Screen.AddEditClient.createRoute()) },
                    onEditClientClick = { clientId -> navController.navigate(Screen.AddEditClient.createRoute(clientId)) },
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            composable(
                route = Screen.ClientDetail.route,
                arguments = listOf(navArgument("clientId") { type = NavType.LongType })
            ) { backStack ->
                val clientId = backStack.arguments?.getLong("clientId") ?: 0L
                ClientDetailScreen(
                    clientId = clientId,
                    viewModel = clientsViewModel,
                    onBack = { navController.popBackStack() },
                    onEditClient = { id -> navController.navigate(Screen.AddEditClient.createRoute(id)) },
                    onAddMachine = { id -> navController.navigate(Screen.AddEditMachine.createRoute(clientId = id)) },
                    onMachineClick = { machineId -> navController.navigate(Screen.MachineDetail.createRoute(machineId)) },
                    onAddIntervention = { id -> navController.navigate(Screen.AddIntervention.createRoute(clientId = id)) },
                    onInterventionClick = { intId -> navController.navigate(Screen.InterventionDetail.createRoute(intId)) }
                )
            }

            composable(
                route = Screen.AddEditClient.route,
                arguments = listOf(navArgument("clientId") {
                    type = NavType.LongType
                    defaultValue = -1L
                })
            ) { backStack ->
                val clientId = backStack.arguments?.getLong("clientId")?.takeIf { it > 0 }
                AddEditClientScreen(
                    clientId = clientId,
                    viewModel = clientsViewModel,
                    onBack = { navController.popBackStack() },
                    onSaved = { savedId ->
                        navController.popBackStack()
                        navController.navigate(Screen.ClientDetail.createRoute(savedId))
                    }
                )
            }

            // 3. Machines
            composable(Screen.Machines.route) {
                MachinesScreen(
                    viewModel = machinesViewModel,
                    onMachineClick = { machineId -> navController.navigate(Screen.MachineDetail.createRoute(machineId)) },
                    onAddMachineClick = { navController.navigate(Screen.AddEditMachine.createRoute()) },
                    onEditMachineClick = { id -> navController.navigate(Screen.AddEditMachine.createRoute(machineId = id)) },
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            composable(
                route = Screen.MachineDetail.route,
                arguments = listOf(navArgument("machineId") { type = NavType.LongType })
            ) { backStack ->
                val machineId = backStack.arguments?.getLong("machineId") ?: 0L
                MachineDetailScreen(
                    machineId = machineId,
                    viewModel = machinesViewModel,
                    onBack = { navController.popBackStack() },
                    onEditMachine = { id -> navController.navigate(Screen.AddEditMachine.createRoute(machineId = id)) },
                    onClientClick = { clientId -> navController.navigate(Screen.ClientDetail.createRoute(clientId)) },
                    onAddIntervention = { clientId, mId -> navController.navigate(Screen.AddIntervention.createRoute(clientId, mId)) },
                    onInterventionClick = { intId -> navController.navigate(Screen.InterventionDetail.createRoute(intId)) }
                )
            }

            composable(
                route = Screen.AddEditMachine.route,
                arguments = listOf(
                    navArgument("clientId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    },
                    navArgument("machineId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    }
                )
            ) { backStack ->
                val clientId = backStack.arguments?.getLong("clientId")?.takeIf { it > 0 }
                val machineId = backStack.arguments?.getLong("machineId")?.takeIf { it > 0 }
                AddEditMachineScreen(
                    initialClientId = clientId,
                    machineId = machineId,
                    viewModel = machinesViewModel,
                    onBack = { navController.popBackStack() },
                    onSaved = { savedId ->
                        navController.popBackStack()
                        navController.navigate(Screen.MachineDetail.createRoute(savedId))
                    }
                )
            }

            // 4. Interventions
            composable(Screen.Interventions.route) {
                InterventionsScreen(
                    viewModel = interventionsViewModel,
                    onInterventionClick = { id -> navController.navigate(Screen.InterventionDetail.createRoute(id)) },
                    onAddInterventionClick = { navController.navigate(Screen.AddIntervention.createRoute()) },
                    onEditInterventionClick = { id -> navController.navigate(Screen.AddIntervention.createRoute(interventionId = id)) },
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            composable(
                route = Screen.InterventionDetail.route,
                arguments = listOf(navArgument("interventionId") { type = NavType.LongType })
            ) { backStack ->
                val interventionId = backStack.arguments?.getLong("interventionId") ?: 0L
                InterventionDetailScreen(
                    interventionId = interventionId,
                    viewModel = interventionsViewModel,
                    onBack = { navController.popBackStack() },
                    onClientClick = { clientId -> navController.navigate(Screen.ClientDetail.createRoute(clientId)) },
                    onMachineClick = { machineId -> navController.navigate(Screen.MachineDetail.createRoute(machineId)) },
                    onEditIntervention = { id -> navController.navigate(Screen.AddIntervention.createRoute(interventionId = id)) }
                )
            }

            composable(
                route = Screen.AddIntervention.route,
                arguments = listOf(
                    navArgument("clientId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    },
                    navArgument("machineId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    },
                    navArgument("interventionId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    }
                )
            ) { backStack ->
                val clientId = backStack.arguments?.getLong("clientId")?.takeIf { it > 0 }
                val machineId = backStack.arguments?.getLong("machineId")?.takeIf { it > 0 }
                val interventionId = backStack.arguments?.getLong("interventionId")?.takeIf { it > 0 }
                AddInterventionScreen(
                    initialClientId = clientId,
                    initialMachineId = machineId,
                    interventionId = interventionId,
                    viewModel = interventionsViewModel,
                    onBack = { navController.popBackStack() },
                    onSaved = { savedId ->
                        navController.popBackStack()
                        navController.navigate(Screen.InterventionDetail.createRoute(savedId))
                    }
                )
            }

            // 5. Stock
            composable(Screen.Stock.route) {
                StockScreen(
                    viewModel = stockViewModel,
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            // 6. Quotes
            composable(Screen.Quotes.route) {
                QuotesScreen(
                    repository = repository,
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            // 7. Maintenance
            composable(Screen.Maintenance.route) {
                MaintenanceScreen(
                    repository = repository,
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            // 8. Knowledge Base
            composable(Screen.KnowledgeBase.route) {
                KnowledgeBaseScreen(
                    repository = repository,
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            // 9. Settings
            composable(Screen.Settings.route) {
                SettingsScreen(
                    repository = repository,
                    onNavigateToAuth = { navController.navigate(Screen.Auth.route) },
                    onNavigateToChatbot = { navController.navigate(Screen.Chatbot.route) },
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            // 10. Suppliers & Orders
            composable(Screen.Suppliers.route) {
                SuppliersScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }

            // 11. Assistant IA Biomédical (Gemini & Maps Grounding)
            composable(Screen.Chatbot.route) {
                ChatbotScreen(
                    viewModel = chatViewModel,
                    onBack = { navController.popBackStack() },
                    bottomBarPadding = innerPadding.calculateBottomPadding(),
                    modifier = Modifier.fillMaxSize()
                )
            }

            // 12. Compte Firebase & Firestore Cloud Sync
            composable(Screen.Auth.route) {
                AuthScreen(
                    authManager = authManager,
                    syncManager = syncManager,
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
                )
            }
        }
    }
}
