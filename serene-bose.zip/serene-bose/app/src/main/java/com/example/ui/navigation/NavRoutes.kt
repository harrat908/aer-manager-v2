package com.example.ui.navigation

sealed class Screen(val route: String) {
    data object Dashboard : Screen("dashboard")
    data object Clients : Screen("clients")
    data object ClientDetail : Screen("client_detail/{clientId}") {
        fun createRoute(clientId: Long) = "client_detail/$clientId"
    }
    data object AddEditClient : Screen("add_edit_client?clientId={clientId}") {
        fun createRoute(clientId: Long? = null) = if (clientId != null) "add_edit_client?clientId=$clientId" else "add_edit_client"
    }
    data object Machines : Screen("machines")
    data object MachineDetail : Screen("machine_detail/{machineId}") {
        fun createRoute(machineId: Long) = "machine_detail/$machineId"
    }
    data object AddEditMachine : Screen("add_edit_machine?clientId={clientId}&machineId={machineId}") {
        fun createRoute(clientId: Long? = null, machineId: Long? = null): String {
            val q = mutableListOf<String>()
            if (clientId != null) q.add("clientId=$clientId")
            if (machineId != null) q.add("machineId=$machineId")
            return if (q.isNotEmpty()) "add_edit_machine?" + q.joinToString("&") else "add_edit_machine"
        }
    }
    data object Interventions : Screen("interventions")
    data object InterventionDetail : Screen("intervention_detail/{interventionId}") {
        fun createRoute(interventionId: Long) = "intervention_detail/$interventionId"
    }
    data object AddIntervention : Screen("add_intervention?clientId={clientId}&machineId={machineId}&interventionId={interventionId}") {
        fun createRoute(clientId: Long? = null, machineId: Long? = null, interventionId: Long? = null): String {
            val q = mutableListOf<String>()
            if (clientId != null) q.add("clientId=$clientId")
            if (machineId != null) q.add("machineId=$machineId")
            if (interventionId != null) q.add("interventionId=$interventionId")
            return if (q.isNotEmpty()) "add_intervention?" + q.joinToString("&") else "add_intervention"
        }
    }
    data object Stock : Screen("stock")
    data object Quotes : Screen("quotes")
    data object Maintenance : Screen("maintenance")
    data object KnowledgeBase : Screen("knowledge_base")
    data object Suppliers : Screen("suppliers")
    data object Settings : Screen("settings")
    data object Chatbot : Screen("chatbot")
    data object Auth : Screen("auth")
}
