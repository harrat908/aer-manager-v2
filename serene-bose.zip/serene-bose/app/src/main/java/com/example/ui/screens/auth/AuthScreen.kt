package com.example.ui.screens.auth

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.AuthManager
import com.example.data.firebase.AuthUiState
import com.example.data.firebase.FirestoreSyncManager
import com.example.data.firebase.SyncResult
import com.example.data.repository.AerRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    authManager: AuthManager,
    syncManager: FirestoreSyncManager,
    repository: AerRepository,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val currentUser by authManager.currentUser.collectAsStateWithLifecycle()
    val authUiState by authManager.uiState.collectAsStateWithLifecycle()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSigningUp by remember { mutableStateOf(false) }

    var syncResult by remember { mutableStateOf<SyncResult?>(null) }
    var isSyncing by remember { mutableStateOf(false) }

    var isFirebaseConfigured by remember { mutableStateOf(authManager.isFirebaseInitialized()) }
    var showJsonSetupDialog by remember { mutableStateOf(!authManager.isFirebaseInitialized()) }
    var jsonInputText by remember { mutableStateOf("") }

    val packageName = "com.aistudio.aermanager.xpkzrw"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (currentUser != null) "Compte & Synchronisation" else "Connexion Firebase") },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showJsonSetupDialog = !showJsonSetupDialog },
                        modifier = Modifier.testTag("toggle_firebase_config")
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Configuration Firebase",
                            tint = if (isFirebaseConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 80.dp,
                start = 16.dp,
                end = 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Firebase Initialization Assistant Card (if not initialized or if user expanded it)
            if (!isFirebaseConfigured || showJsonSetupDialog) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isFirebaseConfigured) MaterialTheme.colorScheme.surfaceVariant
                            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isFirebaseConfigured) Icons.Default.CheckCircle else Icons.Default.WarningAmber,
                                    contentDescription = null,
                                    tint = if (isFirebaseConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (isFirebaseConfigured) "Firebase Configuré avec Succès" else "Configuration Firebase requise",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (isFirebaseConfigured) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        text = if (isFirebaseConfigured) "Projet Firebase actif pour Google Sign-In & Firestore"
                                        else "Associez votre projet Firebase gratuit en 2 minutes",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Step 1: Package Name badge
                            Text(
                                text = "1. Votre Package Name Android :",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.labelMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp),
                                border = CardDefaults.outlinedCardBorder(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = packageName,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("Package Name", packageName))
                                            Toast.makeText(context, "Package Name copié !", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.ContentCopy,
                                            contentDescription = "Copier",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Step 2: Open Firebase Console
                            Text(
                                text = "2. Téléchargez votre google-services.json :",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.labelMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Créez un projet sur console.firebase.google.com, ajoutez l'application Android avec le package ci-dessus et téléchargez google-services.json.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            FilledTonalButton(
                                onClick = {
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://console.firebase.google.com"))
                                        context.startActivity(intent)
                                    } catch (_: Exception) {
                                        Toast.makeText(context, "Ouvrez https://console.firebase.google.com", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Ouvrir Firebase Console")
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Step 3: Paste JSON Content
                            Text(
                                text = "3. Collez le contenu de google-services.json ci-dessous :",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.labelMedium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = jsonInputText,
                                onValueChange = { jsonInputText = it },
                                placeholder = { Text("Collez tout le texte du fichier google-services.json ici...", fontSize = 12.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp),
                                maxLines = 8,
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    if (jsonInputText.isNotBlank()) {
                                        val res = authManager.initializeWithGoogleServicesJson(jsonInputText)
                                        if (res.isSuccess) {
                                            isFirebaseConfigured = true
                                            showJsonSetupDialog = false
                                            Toast.makeText(context, "Firebase initialisé avec succès !", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, res.exceptionOrNull()?.message ?: "Erreur JSON", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                enabled = jsonInputText.isNotBlank(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Valider & Activer Firebase")
                            }
                        }
                    }
                }
            }

            if (currentUser != null) {
                // Connected User Profile
                val user = currentUser!!
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(16.dp),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = user.displayName?.ifBlank { "Utilisateur AER" } ?: "Technicien Biomédical",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = user.email ?: "Compte Firebase Connecté",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "Authentifié Google / Firebase",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Cloud Firestore Sync Section
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.secondaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.CloudSync,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Persistance Cloud Firestore",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Sauvegardez et synchronisez vos clients, machines et interventions",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            if (syncResult != null) {
                                val res = syncResult!!
                                Surface(
                                    color = if (res.success) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                    else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = res.message,
                                            fontWeight = FontWeight.SemiBold,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (res.success) MaterialTheme.colorScheme.onPrimaryContainer
                                            else MaterialTheme.colorScheme.onErrorContainer
                                        )
                                        if (res.success) {
                                            Text(
                                                text = "Clients: ${res.clientsSynced} | Machines: ${res.machinesSynced} | Interventions: ${res.interventionsSynced}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                            }

                            Button(
                                onClick = {
                                    isSyncing = true
                                    scope.launch {
                                        syncResult = syncManager.syncAll(user.uid, repository)
                                        isSyncing = false
                                        if (syncResult?.success == true) {
                                            Toast.makeText(context, "Données synchronisées avec Firestore !", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                enabled = !isSyncing,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("firestore_sync_button")
                            ) {
                                if (isSyncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Synchronisation en cours...")
                                } else {
                                    Icon(Icons.Default.Sync, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Synchroniser avec Firestore")
                                }
                            }
                        }
                    }
                }

                // Logout Button
                item {
                    OutlinedButton(
                        onClick = { authManager.signOut() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_signout_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Se déconnecter")
                    }
                }
            } else {
                // Not Signed In: Login / Registration
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Security,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Connexion Sécurisée",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "Connectez-vous avec Google ou par e-mail pour synchroniser vos interventions et données biomédicales sur le Cloud Firestore.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            // 1-Click Instant Sign-In (Anonymous / Technician Guest)
                            Button(
                                onClick = {
                                    scope.launch {
                                        val res = authManager.signInAnonymously()
                                        if (res.isFailure) {
                                            Toast.makeText(context, res.exceptionOrNull()?.message ?: "Erreur de connexion", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "Session Technicien activée avec succès !", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("guest_signin_button")
                            ) {
                                Icon(Icons.Default.CloudSync, contentDescription = null)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Connexion Immédiate 1-Clic (Technicien)", fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Google Sign-In Button (Credential Manager)
                            FilledTonalButton(
                                onClick = {
                                    if (!isFirebaseConfigured) {
                                        showJsonSetupDialog = true
                                        Toast.makeText(context, "Veuillez d'abord renseigner votre google-services.json dans l'encadré ci-dessus.", Toast.LENGTH_LONG).show()
                                    } else {
                                        scope.launch {
                                            val res = authManager.signInWithGoogle(context)
                                            if (res.isFailure) {
                                                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Erreur de connexion Google", Toast.LENGTH_LONG).show()
                                            } else {
                                                Toast.makeText(context, "Bienvenue ${res.getOrNull()?.displayName ?: ""} !", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("google_signin_button")
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Continuer avec Google", fontWeight = FontWeight.SemiBold)
                            }

                            if (authManager.getWebClientId().isBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "💡 Astuce : Si aucun compte Google n'est configuré sur votre appareil, utilisez la Connexion Immédiate 1-Clic ci-dessus ou l'E-mail ci-dessous.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Surface(modifier = Modifier.weight(1f).height(1.dp), color = MaterialTheme.colorScheme.outlineVariant) {}
                                Text(
                                    text = " OU AVEC E-MAIL & MOT DE PASSE ",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                Surface(modifier = Modifier.weight(1f).height(1.dp), color = MaterialTheme.colorScheme.outlineVariant) {}
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Email & Password Fields
                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it },
                                label = { Text("Adresse E-mail") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("Mot de passe") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            if (authUiState is AuthUiState.Error) {
                                Text(
                                    text = (authUiState as AuthUiState.Error).message,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                            }

                            Button(
                                onClick = {
                                    if (!isFirebaseConfigured) {
                                        showJsonSetupDialog = true
                                        Toast.makeText(context, "Veuillez d'abord initialiser Firebase avec google-services.json", Toast.LENGTH_LONG).show()
                                    } else if (email.isNotBlank() && password.isNotBlank()) {
                                        scope.launch {
                                            val res = if (isSigningUp) {
                                                authManager.signUpWithEmail(email, password)
                                            } else {
                                                authManager.signInWithEmail(email, password)
                                            }
                                            if (res.isFailure) {
                                                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Erreur", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                },
                                enabled = email.isNotBlank() && password.isNotBlank() && authUiState !is AuthUiState.Loading,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (authUiState is AuthUiState.Loading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text(if (isSigningUp) "Créer un compte" else "Se connecter")
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { isSigningUp = !isSigningUp },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (isSigningUp) "Déjà un compte ? Se connecter" else "Pas de compte ? S'inscrire")
                            }
                        }
                    }
                }

                // Offline Notice
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Mode 100% Hors-Ligne conservé : Même sans compte Firebase, toutes vos données (clients, parcs machines, rapports d'intervention) restent enregistrées et consultables sur votre téléphone.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
