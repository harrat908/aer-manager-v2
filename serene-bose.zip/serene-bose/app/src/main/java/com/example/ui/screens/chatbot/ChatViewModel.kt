package com.example.ui.screens.chatbot

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.gemini.AssistantAction
import com.example.data.gemini.ChatMessage
import com.example.data.gemini.GeminiModelChoice
import com.example.data.gemini.GeminiService
import com.example.data.gemini.GroundedPlace
import com.example.data.model.ClientEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.MachineEntity
import com.example.data.repository.AerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatViewModel(
    private val geminiService: GeminiService = GeminiService(),
    private val repository: AerRepository? = null
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                role = "model",
                content = "Bonjour ! Je suis l'assistant IA biomédical & SAV d'AER Manager.\n\n⚡ **Nouvelles fonctionnalités :**\nVous pouvez désormais me demander directement :\n- « *Ajoute le Dr Benali, Clinique El Chiffa à Alger, 0550123456* »\n- « *Ajoute un Laser CO2 Alma Pixel pour le Dr Benali* »\n- « *Crée une intervention urgente pour le Dr Benali : tir laser faible* »\n\nJe préparerai la fiche et l'enregistrerai directement dans votre base de données locale et cloud !",
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _selectedModel = MutableStateFlow(GeminiModelChoice.FLASH_3_5)
    val selectedModel: StateFlow<GeminiModelChoice> = _selectedModel.asStateFlow()

    private val _isMapsGroundingEnabled = MutableStateFlow(false)
    val isMapsGroundingEnabled: StateFlow<Boolean> = _isMapsGroundingEnabled.asStateFlow()

    fun selectModel(choice: GeminiModelChoice) {
        _selectedModel.value = choice
    }

    fun toggleMapsGrounding(enabled: Boolean) {
        _isMapsGroundingEnabled.value = enabled
        if (enabled) {
            _selectedModel.value = GeminiModelChoice.FLASH_3_5
        }
    }

    fun sendMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank() || _isLoading.value) return

        val userMsg = ChatMessage(
            role = "user",
            content = trimmed
        )
        _messages.value = _messages.value + userMsg
        _isLoading.value = true

        viewModelScope.launch {
            try {
                val currentHistory = _messages.value.dropLast(1)
                val reply = geminiService.sendMessage(
                    history = currentHistory,
                    userMessage = trimmed,
                    modelChoice = _selectedModel.value,
                    enableMapsGrounding = _isMapsGroundingEnabled.value
                )
                _messages.value = _messages.value + reply
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(
                    role = "model",
                    content = "Erreur inattendue : ${e.localizedMessage ?: e.message}",
                    isError = true
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun executeAssistantAction(messageId: String, action: AssistantAction) {
        viewModelScope.launch {
            try {
                val rep = repository
                if (rep == null) {
                    Log.w("ChatViewModel", "Repository null, cannot save action")
                    return@launch
                }

                val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                var successMsg = ""

                when (action) {
                    is AssistantAction.AddClient -> {
                        val client = ClientEntity(
                            nom = action.nom,
                            nomClinique = action.nomClinique,
                            telephone = action.telephone,
                            whatsapp = action.telephone,
                            email = action.email,
                            adresse = action.adresse,
                            ville = action.ville.ifBlank { "Alger" },
                            notes = action.notes.ifBlank { "Ajouté par l'assistant IA" },
                            dateCreation = today
                        )
                        val newId = rep.insertClient(client)
                        successMsg = "Client « ${action.nom} » enregistré avec succès dans votre base (ID: #$newId) !"
                    }

                    is AssistantAction.AddMachine -> {
                        val clients = rep.getAllClients().firstOrNull() ?: emptyList()
                        val targetClient = if (action.clientName.isNotBlank()) {
                            clients.firstOrNull {
                                it.nom.contains(action.clientName, ignoreCase = true) ||
                                        it.nomClinique.contains(action.clientName, ignoreCase = true)
                            } ?: clients.firstOrNull()
                        } else {
                            clients.firstOrNull()
                        }

                        val clientId = targetClient?.id ?: run {
                            rep.insertClient(
                                ClientEntity(
                                    nom = action.clientName.ifBlank { "Client Automatique IA" },
                                    nomClinique = "",
                                    telephone = "",
                                    whatsapp = "",
                                    email = "",
                                    adresse = "",
                                    ville = "Alger",
                                    notes = "Client créé automatiquement pour la machine ${action.marque}"
                                )
                            )
                        }

                        val machine = MachineEntity(
                            clientId = clientId,
                            marque = action.marque,
                            modele = action.modele,
                            type = action.type,
                            numeroSerie = action.numeroSerie.ifBlank { "SN-${System.currentTimeMillis() % 100000}" },
                            dateAchat = today,
                            fournisseur = "Fournisseur Agréé",
                            dateInstallation = today,
                            dureeGarantieMois = 12,
                            dateFinGarantie = today,
                            etat = "En service",
                            localisationSalle = action.localisationSalle,
                            notes = action.notes.ifBlank { "Machine enregistrée via Assistant IA" }
                        )
                        val newMachineId = rep.insertMachine(machine)
                        successMsg = "Machine « ${action.marque} ${action.modele} » ajoutée pour ${targetClient?.nom ?: "le client"} (ID: #$newMachineId) !"
                    }

                    is AssistantAction.AddIntervention -> {
                        val clients = rep.getAllClients().firstOrNull() ?: emptyList()
                        val targetClient = if (action.clientName.isNotBlank()) {
                            clients.firstOrNull {
                                it.nom.contains(action.clientName, ignoreCase = true) ||
                                it.nomClinique.contains(action.clientName, ignoreCase = true)
                            } ?: clients.firstOrNull()
                        } else {
                            clients.firstOrNull()
                        }

                        // Ensure client exists in database to satisfy ForeignKey constraint
                        val validClientId = targetClient?.id ?: run {
                            rep.insertClient(
                                ClientEntity(
                                    nom = action.clientName.ifBlank { "Dr Nouveau Client" },
                                    nomClinique = "Cabinet Médical",
                                    telephone = "",
                                    whatsapp = "",
                                    email = "",
                                    adresse = "Alger",
                                    ville = "Alger",
                                    notes = "Client créé automatiquement pour l'intervention IA",
                                    dateCreation = today
                                )
                            )
                        }

                        val machines = rep.getAllMachines().firstOrNull() ?: emptyList()
                        val targetMachine = if (action.machineName.isNotBlank()) {
                            machines.firstOrNull {
                                it.modele.contains(action.machineName, ignoreCase = true) ||
                                it.marque.contains(action.machineName, ignoreCase = true)
                            } ?: machines.firstOrNull { it.clientId == validClientId }
                        } else {
                            machines.firstOrNull { it.clientId == validClientId } ?: machines.firstOrNull()
                        }

                        // Ensure machine exists in database to satisfy ForeignKey constraint
                        val validMachineId = targetMachine?.id ?: run {
                            rep.insertMachine(
                                MachineEntity(
                                    clientId = validClientId,
                                    marque = if (action.machineName.isNotBlank()) action.machineName else "Équipement Médical",
                                    modele = "Modèle Principal",
                                    type = "Autre",
                                    numeroSerie = "SN-${System.currentTimeMillis() % 100000}",
                                    dateAchat = today,
                                    fournisseur = "Fournisseur Agréé",
                                    dateInstallation = today,
                                    dureeGarantieMois = 12,
                                    dateFinGarantie = today,
                                    notes = "Machine générée automatiquement pour lier l'intervention IA"
                                )
                            )
                        }

                        val year = SimpleDateFormat("yyyy", Locale.getDefault()).format(Date())
                        val num = "INT-$year-${(System.currentTimeMillis() % 9000 + 1000)}"

                        val intervention = InterventionEntity(
                            numeroIntervention = num,
                            clientId = validClientId,
                            machineId = validMachineId,
                            technicien = "Jules AER",
                            date = today,
                            statut = action.statut,
                            priorite = action.priorite,
                            problemeSignale = action.problemeSignale,
                            diagnostic = "Intervention planifiée par l'assistant IA",
                            travailEffectue = "",
                            recommandations = ""
                        )
                        val newIntId = rep.insertIntervention(intervention)
                        successMsg = "Intervention « $num » planifiée avec succès (Priorité: ${action.priorite}, ID: #$newIntId) !"
                    }
                }

                // Update the state so the action in the chat bubble reflects completion
                _messages.value = _messages.value.map { msg ->
                    if (msg.id == messageId && msg.action != null) {
                        val updated = when (val a = msg.action) {
                            is AssistantAction.AddClient -> a.copy(isExecuted = true, executionResult = successMsg)
                            is AssistantAction.AddMachine -> a.copy(isExecuted = true, executionResult = successMsg)
                            is AssistantAction.AddIntervention -> a.copy(isExecuted = true, executionResult = successMsg)
                            null -> null
                        }
                        msg.copy(action = updated)
                    } else {
                        msg
                    }
                }
            } catch (e: Exception) {
                Log.e("ChatViewModel", "executeAssistantAction failed", e)
                val errMsg = "Échec : ${e.localizedMessage ?: e.message}"
                _messages.value = _messages.value.map { msg ->
                    if (msg.id == messageId && msg.action != null) {
                        val updated = when (val a = msg.action) {
                            is AssistantAction.AddClient -> a.copy(isExecuted = false, executionResult = errMsg)
                            is AssistantAction.AddMachine -> a.copy(isExecuted = false, executionResult = errMsg)
                            is AssistantAction.AddIntervention -> a.copy(isExecuted = false, executionResult = errMsg)
                            null -> null
                        }
                        msg.copy(action = updated)
                    } else {
                        msg
                    }
                }
            }
        }
    }

    fun saveGroundedPlaceAsClient(place: GroundedPlace, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val rep = repository ?: run {
                    onComplete(false, "Base de données non disponible")
                    return@launch
                }
                val title = place.title.trim()
                val nomClinique = if (title.contains("Clinique", ignoreCase = true) ||
                    title.contains("Centre", ignoreCase = true) ||
                    title.contains("Cabinet", ignoreCase = true)
                ) {
                    title
                } else {
                    "Clinique / Cabinet $title"
                }
                val nomDocteur = if (title.contains("Dr", ignoreCase = true)) {
                    title
                } else {
                    "Responsable $title"
                }
                val rawAddress = place.address ?: ""
                val city = when {
                    rawAddress.contains("Alger", ignoreCase = true) || title.contains("Alger", ignoreCase = true) -> "Alger"
                    rawAddress.contains("Oran", ignoreCase = true) -> "Oran"
                    rawAddress.contains("Constantine", ignoreCase = true) -> "Constantine"
                    rawAddress.contains("Blida", ignoreCase = true) -> "Blida"
                    rawAddress.contains("Sétif", ignoreCase = true) || rawAddress.contains("Setif", ignoreCase = true) -> "Sétif"
                    rawAddress.contains("Annaba", ignoreCase = true) -> "Annaba"
                    rawAddress.contains("Tlemcen", ignoreCase = true) -> "Tlemcen"
                    else -> if (rawAddress.isNotBlank()) rawAddress.split(",").lastOrNull()?.trim() ?: "Alger" else "Alger"
                }

                val mapsNote = buildString {
                    append("Importé directement depuis Google Maps.")
                    if (!place.uri.isNullOrBlank()) {
                        append("\nLien Maps : ${place.uri}")
                    }
                    if (!place.description.isNullOrBlank()) {
                        append("\nInfos : ${place.description}")
                    }
                }

                val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                val client = ClientEntity(
                    nom = nomDocteur,
                    nomClinique = nomClinique,
                    telephone = "",
                    whatsapp = "",
                    email = "",
                    adresse = rawAddress.ifBlank { "Coordonnées Google Maps" },
                    ville = city,
                    notes = mapsNote,
                    dateCreation = today
                )
                val newId = rep.insertClient(client)
                onComplete(true, "Client « $nomClinique » enregistré dans votre base (ID: #$newId) !")
            } catch (e: Exception) {
                onComplete(false, "Erreur lors de l'enregistrement : ${e.localizedMessage ?: e.message}")
            }
        }
    }

    fun clearConversation() {
        _messages.value = listOf(
            ChatMessage(
                role = "model",
                content = "Nouvelle conversation démarrée. Vous pouvez me demander un diagnostic technique ou me donner des ordres de saisie (ex: « Ajoute un client Dr ... », « Ajoute une machine ... », « Crée une intervention ... »)."
            )
        )
    }

    class Factory(
        private val geminiService: GeminiService = GeminiService(),
        private val repository: AerRepository? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ChatViewModel(geminiService, repository) as T
        }
    }
}
