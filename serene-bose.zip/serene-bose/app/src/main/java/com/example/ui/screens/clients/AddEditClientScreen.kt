package com.example.ui.screens.clients

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ClientEntity
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditClientScreen(
    clientId: Long?,
    viewModel: ClientsViewModel,
    onBack: UnitCallback,
    onSaved: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val existingClient by remember(clientId) {
        if (clientId != null && clientId > 0) viewModel.getClient(clientId)
        else MutableStateFlow(null)
    }.collectAsStateWithLifecycle()

    var nom by remember { mutableStateOf("") }
    var nomClinique by remember { mutableStateOf("") }
    var telephone by remember { mutableStateOf("") }
    var whatsapp by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var adresse by remember { mutableStateOf("") }
    var ville by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var dateCreation by remember { mutableStateOf("") }

    var showMapsImporter by remember { mutableStateOf(false) }
    var mapsInputText by remember { mutableStateOf("") }

    LaunchedEffect(existingClient) {
        existingClient?.let {
            nom = it.nom
            nomClinique = it.nomClinique
            telephone = it.telephone
            whatsapp = it.whatsapp
            email = it.email
            adresse = it.adresse
            ville = it.ville
            notes = it.notes
            dateCreation = it.dateCreation
        }
    }

    val isEditing = clientId != null && clientId > 0

    val pickContactLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val contactUri = result.data?.data ?: return@rememberLauncherForActivityResult
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            try {
                context.contentResolver.query(contactUri, projection, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                        val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        if (nameIdx != -1) {
                            val contactName = cursor.getString(nameIdx)
                            if (!contactName.isNullOrBlank()) {
                                nom = contactName
                                if (nomClinique.isBlank()) {
                                    nomClinique = "Cabinet $contactName"
                                }
                            }
                        }
                        if (numberIdx != -1) {
                            val rawNumber = cursor.getString(numberIdx)
                            if (!rawNumber.isNullOrBlank()) {
                                val cleanNumber = rawNumber.replace(" ", "").replace("-", "").trim()
                                telephone = cleanNumber
                                if (whatsapp.isBlank()) {
                                    whatsapp = cleanNumber
                                }
                            }
                        }
                        Toast.makeText(context, "Contact importé avec succès !", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Impossible de lire le contact", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val launchContactPicker = {
        try {
            val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            pickContactLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Application contacts indisponible", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Modifier Client" else "Nouveau Client") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(
                        onClick = launchContactPicker,
                        modifier = Modifier.testTag("import_contact_button")
                    ) {
                        Icon(
                            Icons.Default.ContactPhone,
                            contentDescription = "Choisir depuis mes contacts",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { showMapsImporter = !showMapsImporter },
                        modifier = Modifier.testTag("toggle_maps_import")
                    ) {
                        Icon(
                            Icons.Default.PinDrop,
                            contentDescription = "Importer depuis Google Maps",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Google Maps Import Assistant Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.PinDrop,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Saisie Express Google Maps 📍",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = if (showMapsImporter) "Masquer ▲" else "Afficher ▼",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .padding(4.dp)
                                .testTag("btn_toggle_maps_panel")
                        )
                    }

                    if (showMapsImporter) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Collez le texte partagé ou l'adresse copiée depuis Google Maps :",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = mapsInputText,
                            onValueChange = { mapsInputText = it },
                            placeholder = { Text("Ex: Clinique El Chiffa, 12 Rue Didouche Mourad, Alger - 0550123456", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    val text = mapsInputText.trim()
                                    if (text.isNotBlank()) {
                                        // Auto-extract clinic/doctor
                                        val lines = text.split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }
                                        if (lines.isNotEmpty()) {
                                            val first = lines[0]
                                            if (first.contains("Dr", ignoreCase = true)) {
                                                nom = first
                                                if (nomClinique.isBlank()) nomClinique = "Cabinet $first"
                                            } else {
                                                nomClinique = first
                                                if (nom.isBlank()) nom = "Responsable $first"
                                            }
                                        }

                                        // Extract phone
                                        val phoneMatch = Regex("""(?:0|\+213)[5-7]\d{8}|0\d{9}""").find(text)
                                        if (phoneMatch != null) {
                                            telephone = phoneMatch.value
                                            whatsapp = phoneMatch.value
                                        }

                                        // Extract city
                                        val lower = text.lowercase()
                                        ville = when {
                                            lower.contains("alger") -> "Alger"
                                            lower.contains("oran") -> "Oran"
                                            lower.contains("constantine") -> "Constantine"
                                            lower.contains("blida") -> "Blida"
                                            lower.contains("sétif") || lower.contains("setif") -> "Sétif"
                                            lower.contains("annaba") -> "Annaba"
                                            lower.contains("tlemcen") -> "Tlemcen"
                                            else -> "Alger"
                                        }

                                        // Set address
                                        adresse = text

                                        // Save URL if present
                                        val urlMatch = Regex("""https?://\S+""").find(text)
                                        if (urlMatch != null) {
                                            notes = (notes + "\nLien Google Maps : ${urlMatch.value}").trim()
                                        }

                                        Toast.makeText(context, "Champs pré-remplis avec succès !", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                enabled = mapsInputText.isNotBlank(),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Remplir les champs", fontSize = 11.sp)
                            }

                            FilledTonalButton(
                                onClick = {
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=clinique+esthetique+dermatologie"))
                                        context.startActivity(intent)
                                    } catch (_: Exception) {
                                        Toast.makeText(context, "Application Google Maps introuvable", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Ouvrir Maps", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Contact Import Assistant Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                ),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.ContactPhone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Répertoire Téléphonique 📱",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Sélectionner un médecin ou une clinique depuis vos contacts",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    FilledTonalButton(
                        onClick = launchContactPicker,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_pick_contact")
                    ) {
                        Text("Choisir", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text(
                text = "Informations Générales",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = nomClinique,
                onValueChange = { nomClinique = it },
                label = { Text("Nom du Centre / Clinique *") },
                placeholder = { Text("ex: Centre Laser Esthétique") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("client_clinic_input"),
                singleLine = true
            )

            OutlinedTextField(
                value = nom,
                onValueChange = { nom = it },
                label = { Text("Nom du Contact / Médecin *") },
                placeholder = { Text("ex: Dr. Benali") },
                trailingIcon = {
                    IconButton(onClick = launchContactPicker) {
                        Icon(
                            Icons.Default.Contacts,
                            contentDescription = "Choisir depuis les contacts",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("client_name_input"),
                singleLine = true
            )

            Text(
                text = "Coordonnées & Contact",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = telephone,
                onValueChange = {
                    telephone = it
                    if (whatsapp.isBlank()) whatsapp = it
                },
                label = { Text("Téléphone Principal *") },
                placeholder = { Text("ex: +213 550 12 34 56") },
                trailingIcon = {
                    IconButton(onClick = launchContactPicker) {
                        Icon(
                            Icons.Default.ContactPhone,
                            contentDescription = "Choisir depuis les contacts",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = whatsapp,
                onValueChange = { whatsapp = it },
                label = { Text("Numéro WhatsApp") },
                placeholder = { Text("ex: +213 550 12 34 56") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Adresse E-mail") },
                placeholder = { Text("ex: contact@clinique.dz") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Text(
                text = "Localisation & Adresse",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = ville,
                onValueChange = { ville = it },
                label = { Text("Ville / Wilaya *") },
                placeholder = { Text("ex: Alger, Oran, Constantine...") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = adresse,
                onValueChange = { adresse = it },
                label = { Text("Adresse Complète (ou Coordonnées Maps)") },
                placeholder = { Text("ex: 12 Rue Didouche Mourad, Alger") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )

            Text(
                text = "Notes & Historique",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes Techniques / Lien Maps") },
                placeholder = { Text("Accès, horaires, étage, lien GPS...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                maxLines = 4
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (nom.isNotBlank() && telephone.isNotBlank()) {
                        val client = ClientEntity(
                            id = clientId ?: 0L,
                            nom = nom.trim(),
                            nomClinique = nomClinique.trim().ifBlank { nom.trim() },
                            telephone = telephone.trim(),
                            whatsapp = whatsapp.trim().ifBlank { telephone.trim() },
                            email = email.trim(),
                            adresse = adresse.trim(),
                            ville = ville.trim().ifBlank { "Alger" },
                            notes = notes.trim(),
                            dateCreation = dateCreation.ifBlank {
                                SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                            }
                        )
                        viewModel.saveClient(client) { savedId ->
                            onSaved(savedId)
                        }
                    }
                },
                enabled = nom.isNotBlank() && telephone.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_client_button")
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isEditing) "Mettre à jour" else "Enregistrer le Client", fontWeight = FontWeight.Bold)
            }
        }
    }
}

typealias UnitCallback = () -> Unit
