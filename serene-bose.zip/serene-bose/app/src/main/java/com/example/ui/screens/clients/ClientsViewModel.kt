package com.example.ui.screens.clients

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ClientEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.MachineEntity
import com.example.data.repository.AerRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

@OptIn(ExperimentalCoroutinesApi::class)
class ClientsViewModel(private val repository: AerRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    val clients: StateFlow<List<ClientEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.getAllClients()
            } else {
                repository.searchClients(query)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val clientFlows = ConcurrentHashMap<Long, StateFlow<ClientEntity?>>()
    private val clientMachinesFlows = ConcurrentHashMap<Long, StateFlow<List<MachineEntity>>>()
    private val clientInterventionsFlows = ConcurrentHashMap<Long, StateFlow<List<InterventionEntity>>>()

    fun getClient(clientId: Long): StateFlow<ClientEntity?> {
        return clientFlows.getOrPut(clientId) {
            repository.getClientById(clientId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = null
                )
        }
    }

    fun getMachinesForClient(clientId: Long): StateFlow<List<MachineEntity>> {
        return clientMachinesFlows.getOrPut(clientId) {
            repository.getMachinesByClientId(clientId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = emptyList()
                )
        }
    }

    fun getInterventionsForClient(clientId: Long): StateFlow<List<InterventionEntity>> {
        return clientInterventionsFlows.getOrPut(clientId) {
            repository.getInterventionsByClientId(clientId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = emptyList()
                )
        }
    }

    fun saveClient(client: ClientEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val id = if (client.id == 0L) {
                repository.insertClient(client)
            } else {
                repository.updateClient(client)
                client.id
            }
            onComplete(id)
        }
    }

    fun deleteClient(client: ClientEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.deleteClient(client)
            onComplete()
        }
    }

    class Factory(private val repository: AerRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ClientsViewModel(repository) as T
        }
    }
}
