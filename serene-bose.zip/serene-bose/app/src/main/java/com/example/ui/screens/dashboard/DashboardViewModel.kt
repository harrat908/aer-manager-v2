package com.example.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ClientEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.MachineEntity
import com.example.data.model.MaintenanceScheduleEntity
import com.example.data.model.PartEntity
import com.example.data.repository.AerRepository
import com.example.data.repository.DashboardSummary
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class FinancialReport(
    val totalRevenue: Double = 0.0,            // CA total facturé aux clients
    val totalPartsSale: Double = 0.0,          // Total vente pièces
    val totalLaborRevenue: Double = 0.0,       // Total main-d'œuvre facturée (revenu de travail)
    val totalTravelBilled: Double = 0.0,       // Total déplacements facturés
    val totalOtherBilled: Double = 0.0,        // Total frais annexes facturés

    val totalPartsCost: Double = 0.0,          // Prix d'achat réel des pièces (charges)
    val totalTravelCost: Double = 0.0,         // Coût réel de déplacement déboursé (charges)
    val totalOtherCost: Double = 0.0,          // Frais réels supplémentaires déboursés (charges)
    val totalCost: Double = 0.0,               // Charges réelles totales = partsCost + travelCost + otherCost

    val netProfit: Double = 0.0,               // Bénéfice net réel = totalRevenue - totalCost
    val partsMargin: Double = 0.0,             // Marge commerciale pièces = totalPartsSale - totalPartsCost
    val profitMarginPercent: Double = 0.0,     // Taux de marge (%) = (netProfit / totalRevenue) * 100
    val averageProfitPerJob: Double = 0.0,     // Bénéfice moyen par intervention
    val completedCount: Int = 0,
    val totalCount: Int = 0,
    val totalLaborCost: Double = 0.0           // Conservé à 0.0 pour compatibilité
)

data class FailureCategoryStat(
    val categoryName: String,
    val count: Int,
    val percentage: Float,
    val iconEmoji: String,
    val commonSymptom: String,
    val recommendedAction: String
)

data class MachineFailureStat(
    val machineType: String,
    val failureCount: Int,
    val percentage: Float
)

class DashboardViewModel(private val repository: AerRepository) : ViewModel() {

    val metrics: StateFlow<DashboardSummary> = repository.dashboardMetrics
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DashboardSummary()
        )

    val urgentInterventions: StateFlow<List<InterventionEntity>> = repository.getUrgentInterventions()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeInterventions: StateFlow<List<InterventionEntity>> = repository.getActiveInterventions()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allInterventions: StateFlow<List<InterventionEntity>> = repository.getAllInterventions()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val lowStockParts: StateFlow<List<PartEntity>> = repository.getLowStockParts()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val maintenanceSchedules: StateFlow<List<MaintenanceScheduleEntity>> = repository.getActiveMaintenance()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val clients: StateFlow<List<ClientEntity>> = repository.getAllClients()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val machines: StateFlow<List<MachineEntity>> = repository.getAllMachines()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val financialReport: StateFlow<FinancialReport> = allInterventions.map { list ->
        val totalRevenue = list.sumOf { it.effectiveRevenue }
        val totalPartsSale = list.sumOf { it.effectivePrixVentePieces }
        val totalLaborRevenue = list.sumOf { it.effectiveMainOeuvreFacturee }
        val totalTravelBilled = list.sumOf { it.effectiveDeplacementFacture }
        val totalOtherBilled = list.sumOf { it.effectiveFraisFactures }

        // Charges réelles déboursées (achats pièces + déplacements réels + frais réels)
        val totalPartsCost = list.sumOf { it.coutPieces }
        val totalTravelCost = list.sumOf { it.coutDeplacement }
        val totalOtherCost = list.sumOf { it.autresFrais }
        val totalCost = totalPartsCost + totalTravelCost + totalOtherCost

        // Bénéfice net réel = CA total facturé - Charges réelles déboursées
        val netProfit = totalRevenue - totalCost

        // Marge commerciale pièces = ventes pièces - achats réels pièces
        val partsMargin = list.sumOf { it.effectiveMargePieces }

        val margin = if (totalRevenue > 0) (netProfit / totalRevenue) * 100 else 0.0
        val completed = list.count { it.statut == "Terminé" }
        val avgProfit = if (list.isNotEmpty()) netProfit / list.size else 0.0

        FinancialReport(
            totalRevenue = totalRevenue,
            totalPartsSale = totalPartsSale,
            totalLaborRevenue = totalLaborRevenue,
            totalTravelBilled = totalTravelBilled,
            totalOtherBilled = totalOtherBilled,
            totalPartsCost = totalPartsCost,
            totalTravelCost = totalTravelCost,
            totalOtherCost = totalOtherCost,
            totalCost = totalCost,
            netProfit = netProfit,
            partsMargin = partsMargin,
            profitMarginPercent = margin,
            averageProfitPerJob = avgProfit,
            completedCount = completed,
            totalCount = list.size,
            totalLaborCost = 0.0
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FinancialReport()
    )

    val failureCategories: StateFlow<List<FailureCategoryStat>> = allInterventions.map { list ->
        if (list.isEmpty()) emptyList()
        else {
            var coolingCount = 0
            var powerCount = 0
            var opticsCount = 0
            var calibrationCount = 0
            var electronicsCount = 0
            var generalCount = 0

            list.forEach { item ->
                val text = (item.problemeSignale + " " + item.diagnostic).lowercase()
                when {
                    text.contains("debit") || text.contains("eau") || text.contains("water") || text.contains("flow") ||
                    text.contains("temp") || text.contains("chiller") || text.contains("refroidiss") || text.contains("peltier") -> coolingCount++

                    text.contains("haute tension") || text.contains("ht") || text.contains("alimentat") || text.contains("power") ||
                    text.contains("simmer") || text.contains("court-circuit") || text.contains("fusible") || text.contains("condensateur") -> powerCount++

                    text.contains("miroir") || text.contains("optique") || text.contains("piece a main") || text.contains("handpiece") ||
                    text.contains("fibre") || text.contains("lentille") || text.contains("alignement") || text.contains("cristal") || text.contains("flash") -> opticsCount++

                    text.contains("energie") || text.contains("joule") || text.contains("calibr") || text.contains("etalonn") ||
                    text.contains("faible") || text.contains("puissance") -> calibrationCount++

                    text.contains("carte") || text.contains("ecran") || text.contains("tactile") || text.contains("erreur") ||
                    text.contains("systeme") || text.contains("urgence") || text.contains("code") -> electronicsCount++

                    else -> generalCount++
                }
            }

            val total = list.size.toFloat()
            listOf(
                FailureCategoryStat(
                    categoryName = "Circuit Hydraulique & Refroidissement",
                    count = coolingCount,
                    percentage = (coolingCount / total) * 100,
                    iconEmoji = "💧",
                    commonSymptom = "Erreur Débit d'eau, surchauffe TEC Peltier, colmatage filtre",
                    recommendedAction = "Vidange eau déionisée, remplacement filtre 5µm et contrôle pompe 24V"
                ),
                FailureCategoryStat(
                    categoryName = "Alimentation Haute Tension & IGBT",
                    count = powerCount,
                    percentage = (powerCount / total) * 100,
                    iconEmoji = "⚡",
                    commonSymptom = "Défaut Simmer, claquage condensateurs, fusible HT sauté",
                    recommendedAction = "Mesure tension résiduelle, vérification carte driver et pont de diodes"
                ),
                FailureCategoryStat(
                    categoryName = "Système Optique & Pièce à Main",
                    count = opticsCount,
                    percentage = (opticsCount / total) * 100,
                    iconEmoji = "🔬",
                    commonSymptom = "Désalignement miroirs CO2, lentille focale brûlée, fibre cassée",
                    recommendedAction = "Alignement faisceau pilote rouge 650nm et nettoyage optique à l'alcool isopropylique"
                ),
                FailureCategoryStat(
                    categoryName = "Calibration Énergie & Lampe Flash",
                    count = calibrationCount,
                    percentage = (calibrationCount / total) * 100,
                    iconEmoji = "🎯",
                    commonSymptom = "Perte de Joules/cm², tir laser affaibli, fin de vie lampe Nd:YAG",
                    recommendedAction = "Étalonnage au joulemètre certifié et changement lampe flash au-delà de 500k tirs"
                ),
                FailureCategoryStat(
                    categoryName = "Cartes Électroniques & Interface Tactile",
                    count = electronicsCount,
                    percentage = (electronicsCount / total) * 100,
                    iconEmoji = "📟",
                    commonSymptom = "Écran tactile bloqué, arrêt d'urgence actif, défaut carte mère",
                    recommendedAction = "Contrôle câblage nappe LVDS, alimentation 12V/5V et réarmement interlock"
                )
            ).filter { it.count > 0 }.sortedByDescending { it.count }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val machineFailureStats: StateFlow<List<MachineFailureStat>> = combine(allInterventions, machines) { ints, machs ->
        if (ints.isEmpty()) emptyList()
        else {
            val machineTypeMap = machs.associate { it.id to it.type }
            val countsByType = mutableMapOf<String, Int>()
            ints.forEach { item ->
                val type = machineTypeMap[item.machineId] ?: "Autre Équipement"
                countsByType[type] = (countsByType[type] ?: 0) + 1
            }
            val totalInts = ints.size.toFloat()
            countsByType.map { (type, count) ->
                MachineFailureStat(
                    machineType = type,
                    failureCount = count,
                    percentage = (count / totalInts) * 100
                )
            }.sortedByDescending { it.failureCount }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    class Factory(private val repository: AerRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(repository) as T
        }
    }
}
