package com.example.ui.screens.interventions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DiagnosticEntity
import com.example.data.model.InterventionEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddInterventionScreen(
    initialClientId: Long?,
    initialMachineId: Long?,
    interventionId: Long? = null,
    viewModel: InterventionsViewModel,
    onBack: () -> Unit,
    onSaved: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val allClients by viewModel.allClients.collectAsStateWithLifecycle()
    val allMachines by viewModel.allMachines.collectAsStateWithLifecycle()

    val existingIntervention by remember(interventionId) {
        if (interventionId != null && interventionId > 0) viewModel.getIntervention(interventionId)
        else kotlinx.coroutines.flow.MutableStateFlow(null)
    }.collectAsStateWithLifecycle()

    val isEditing = interventionId != null && interventionId > 0

    var selectedClientId by remember { mutableLongStateOf(initialClientId ?: 0L) }
    var selectedMachineId by remember { mutableLongStateOf(initialMachineId ?: 0L) }

    val context = LocalContext.current
    val technicianProfile = remember { com.example.data.preferences.TechnicianProfileManager(context).getProfile() }
    val todayDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val autoNumber = remember { "INT-${SimpleDateFormat("yyyy", Locale.getDefault()).format(Date())}-${(100..999).random()}" }

    var numeroIntervention by remember { mutableStateOf(autoNumber) }
    var date by remember { mutableStateOf(todayDate) }
    var technicien by remember { mutableStateOf(technicianProfile.nom) }
    var statut by remember { mutableStateOf("Planifié") }
    var priorite by remember { mutableStateOf("Normale") }
    var problemeSignale by remember { mutableStateOf("") }
    var travailEffectue by remember { mutableStateOf("") }
    var recommandations by remember { mutableStateOf("") }

    // Diagnostic structuré
    var symptome by remember { mutableStateOf("") }
    var causeProbable by remember { mutableStateOf("") }
    var testsEffectues by remember { mutableStateOf("") }
    var mesures by remember { mutableStateOf("") }
    var resultat by remember { mutableStateOf("") }
    var solution by remember { mutableStateOf("") }

    // Facturation Client (Revenus)
    var prixVentePiecesStr by remember { mutableStateOf(if (isEditing) "" else "0") }
    var mainOeuvreFactureeStr by remember { mutableStateOf(if (isEditing) "" else "15000") }
    var deplacementFactureStr by remember { mutableStateOf(if (isEditing) "" else "3000") }
    var fraisFacturesStr by remember { mutableStateOf(if (isEditing) "" else "0") }
    var prixFactureStr by remember { mutableStateOf(if (isEditing) "" else "18000") }

    // Charges Réelles Déboursées (Données Internes AER)
    var coutPiecesStr by remember { mutableStateOf(if (isEditing) "" else "0") }
    var coutDeplacementStr by remember { mutableStateOf(if (isEditing) "" else "1000") }
    var autresFraisStr by remember { mutableStateOf(if (isEditing) "" else "0") }

    LaunchedEffect(existingIntervention) {
        existingIntervention?.let {
            selectedClientId = it.clientId
            selectedMachineId = it.machineId
            numeroIntervention = it.numeroIntervention
            date = it.date
            technicien = it.technicien
            statut = it.statut
            priorite = it.priorite
            problemeSignale = it.problemeSignale
            travailEffectue = it.travailEffectue
            recommandations = it.recommandations

            // Revenus
            prixVentePiecesStr = if (it.prixVentePieces > 0) it.prixVentePieces.toLong().toString() else if (it.coutPieces > 0 && it.prixFacture >= it.coutPieces) it.coutPieces.toLong().toString() else ""
            mainOeuvreFactureeStr = if (it.mainOeuvreFacturee > 0) it.mainOeuvreFacturee.toLong().toString() else if (it.coutMainOeuvre > 0) it.coutMainOeuvre.toLong().toString() else ""
            deplacementFactureStr = if (it.deplacementFacture > 0) it.deplacementFacture.toLong().toString() else ""
            fraisFacturesStr = if (it.fraisFactures > 0) it.fraisFactures.toLong().toString() else ""
            prixFactureStr = it.prixFacture.toLong().toString()

            // Charges
            coutPiecesStr = it.coutPieces.toLong().toString()
            coutDeplacementStr = it.coutDeplacement.toLong().toString()
            autresFraisStr = it.autresFrais.toLong().toString()
        }
    }

    val prixVentePieces = prixVentePiecesStr.toDoubleOrNull() ?: 0.0
    val mainOeuvreFacturee = mainOeuvreFactureeStr.toDoubleOrNull() ?: 0.0
    val deplacementFacture = deplacementFactureStr.toDoubleOrNull() ?: 0.0
    val fraisFactures = fraisFacturesStr.toDoubleOrNull() ?: 0.0
    val computedRevenue = prixVentePieces + mainOeuvreFacturee + deplacementFacture + fraisFactures
    val prixFacture = prixFactureStr.toDoubleOrNull() ?: computedRevenue

    val coutPieces = coutPiecesStr.toDoubleOrNull() ?: 0.0 // Prix d'achat réel pièces
    val coutDeplacement = coutDeplacementStr.toDoubleOrNull() ?: 0.0 // Dépense réelle déplacement
    val autresFrais = autresFraisStr.toDoubleOrNull() ?: 0.0 // Dépenses réelles supplémentaires
    val chargesReelles = coutPieces + coutDeplacement + autresFrais

    val benefice = prixFacture - chargesReelles
    val margePieces = prixVentePieces - coutPieces

    // Dropdowns
    var clientExpanded by remember { mutableStateOf(false) }
    var machineExpanded by remember { mutableStateOf(false) }
    var statutExpanded by remember { mutableStateOf(false) }
    var prioriteExpanded by remember { mutableStateOf(false) }

    val availableMachines = if (selectedClientId > 0) {
        allMachines.filter { it.clientId == selectedClientId }
    } else allMachines

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Modifier l'Intervention" else "Nouvelle Intervention") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Client & Équipement",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Client Picker
            ExposedDropdownMenuBox(
                expanded = clientExpanded,
                onExpandedChange = { clientExpanded = !clientExpanded }
            ) {
                val clientName = allClients.find { it.id == selectedClientId }?.nomClinique ?: "Sélectionner le client / clinique *"
                OutlinedTextField(
                    value = clientName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Client *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = clientExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                )
                ExposedDropdownMenu(
                    expanded = clientExpanded,
                    onDismissRequest = { clientExpanded = false }
                ) {
                    allClients.forEach { c ->
                        DropdownMenuItem(
                            text = { Text("${c.nomClinique} (${c.nom})") },
                            onClick = {
                                selectedClientId = c.id
                                // Auto-select machine if client has only one
                                val clientMacs = allMachines.filter { it.clientId == c.id }
                                if (clientMacs.size == 1) {
                                    selectedMachineId = clientMacs.first().id
                                }
                                clientExpanded = false
                            }
                        )
                    }
                }
            }

            // Machine Picker
            ExposedDropdownMenuBox(
                expanded = machineExpanded,
                onExpandedChange = { machineExpanded = !machineExpanded }
            ) {
                val machineName = availableMachines.find { it.id == selectedMachineId }?.let {
                    "[${it.type}] ${it.marque} ${it.modele} (S/N: ${it.numeroSerie})"
                } ?: "Sélectionner la machine *"
                OutlinedTextField(
                    value = machineName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Machine concernée *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = machineExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                )
                ExposedDropdownMenu(
                    expanded = machineExpanded,
                    onDismissRequest = { machineExpanded = false }
                ) {
                    availableMachines.forEach { m ->
                        DropdownMenuItem(
                            text = { Text("[${m.type}] ${m.marque} ${m.modele} - S/N: ${m.numeroSerie}") },
                            onClick = {
                                selectedMachineId = m.id
                                selectedClientId = m.clientId
                                machineExpanded = false
                            }
                        )
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = numeroIntervention,
                    onValueChange = { numeroIntervention = it },
                    label = { Text("N° Intervention") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            // Priorité & Statut
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ExposedDropdownMenuBox(
                    expanded = prioriteExpanded,
                    onExpandedChange = { prioriteExpanded = !prioriteExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = priorite,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Priorité") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = prioriteExpanded) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable),
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(expanded = prioriteExpanded, onDismissRequest = { prioriteExpanded = false }) {
                        listOf("Urgent", "Haute", "Normale", "Faible").forEach { p ->
                            DropdownMenuItem(text = { Text(p) }, onClick = { priorite = p; prioriteExpanded = false })
                        }
                    }
                }

                ExposedDropdownMenuBox(
                    expanded = statutExpanded,
                    onExpandedChange = { statutExpanded = !statutExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = statut,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Statut") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statutExpanded) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable),
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(expanded = statutExpanded, onDismissRequest = { statutExpanded = false }) {
                        listOf("Nouveau", "Planifié", "En cours", "En attente pièce", "Terminé").forEach { s ->
                            DropdownMenuItem(text = { Text(s) }, onClick = { statut = s; statutExpanded = false })
                        }
                    }
                }
            }

            OutlinedTextField(
                value = problemeSignale,
                onValueChange = { problemeSignale = it },
                label = { Text("Problème Signalé par le Client *") },
                placeholder = { Text("ex: Aspiration faible, alarme température eau E04...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("intervention_problem_input"),
                minLines = 2
            )

            // Diagnostic Structuré
            Text(
                text = "Diagnostic Technique Structuré",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = symptome,
                        onValueChange = { symptome = it },
                        label = { Text("Symptôme technique constaté") },
                        placeholder = { Text("ex: Dépression < 10 kPa") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = causeProbable,
                        onValueChange = { causeProbable = it },
                        label = { Text("Cause probable") },
                        placeholder = { Text("ex: Électrovanne 24V colmatée") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = testsEffectues,
                        onValueChange = { testsEffectues = it },
                        label = { Text("Tests effectués") },
                        placeholder = { Text("ex: Mesure tension bobine et débit") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = mesures,
                        onValueChange = { mesures = it },
                        label = { Text("Mesures (V, A, kPa, J/cm²...)") },
                        placeholder = { Text("ex: 24.1V DC, -8 kPa") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = resultat,
                        onValueChange = { resultat = it },
                        label = { Text("Résultat des tests") },
                        placeholder = { Text("ex: Bobine OK, clapet bloqué") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = solution,
                        onValueChange = { solution = it },
                        label = { Text("Solution appliquée") },
                        placeholder = { Text("ex: Démontage & ultrasons ou remplacement") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            OutlinedTextField(
                value = travailEffectue,
                onValueChange = { travailEffectue = it },
                label = { Text("Travaux Réalisés") },
                placeholder = { Text("Détails des manipulations effectuées...") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            OutlinedTextField(
                value = recommandations,
                onValueChange = { recommandations = it },
                label = { Text("Recommandations au Client") },
                placeholder = { Text("Précautions, fréquence d'entretien...") },
                modifier = Modifier.fillMaxWidth()
            )

            // Coûts et Rentabilité
            Text(
                text = "1. Facturation Client (Chiffre d'Affaires)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = prixVentePiecesStr,
                    onValueChange = {
                        prixVentePiecesStr = it
                        val newVente = it.toDoubleOrNull() ?: 0.0
                        val newComputed = newVente + (mainOeuvreFactureeStr.toDoubleOrNull() ?: 0.0) + (deplacementFactureStr.toDoubleOrNull() ?: 0.0) + (fraisFacturesStr.toDoubleOrNull() ?: 0.0)
                        prixFactureStr = newComputed.toLong().toString()
                    },
                    label = { Text("Vente Pièces (DZD)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = mainOeuvreFactureeStr,
                    onValueChange = {
                        mainOeuvreFactureeStr = it
                        val newMo = it.toDoubleOrNull() ?: 0.0
                        val newComputed = (prixVentePiecesStr.toDoubleOrNull() ?: 0.0) + newMo + (deplacementFactureStr.toDoubleOrNull() ?: 0.0) + (fraisFacturesStr.toDoubleOrNull() ?: 0.0)
                        prixFactureStr = newComputed.toLong().toString()
                    },
                    label = { Text("Main-d'œuvre facturée (DZD)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = deplacementFactureStr,
                    onValueChange = {
                        deplacementFactureStr = it
                        val newDep = it.toDoubleOrNull() ?: 0.0
                        val newComputed = (prixVentePiecesStr.toDoubleOrNull() ?: 0.0) + (mainOeuvreFactureeStr.toDoubleOrNull() ?: 0.0) + newDep + (fraisFacturesStr.toDoubleOrNull() ?: 0.0)
                        prixFactureStr = newComputed.toLong().toString()
                    },
                    label = { Text("Déplacement facturé (DZD)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = fraisFacturesStr,
                    onValueChange = {
                        fraisFacturesStr = it
                        val newFrais = it.toDoubleOrNull() ?: 0.0
                        val newComputed = (prixVentePiecesStr.toDoubleOrNull() ?: 0.0) + (mainOeuvreFactureeStr.toDoubleOrNull() ?: 0.0) + (deplacementFactureStr.toDoubleOrNull() ?: 0.0) + newFrais
                        prixFactureStr = newComputed.toLong().toString()
                    },
                    label = { Text("Frais facturés (DZD)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = prixFactureStr,
                onValueChange = { prixFactureStr = it },
                label = { Text("Total Facturé Client / CA (DZD) *") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "2. Charges Réelles Déboursées (Données Internes AER)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = coutPiecesStr,
                onValueChange = { coutPiecesStr = it },
                label = { Text("Prix d'achat réel pièces (DZD)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = coutDeplacementStr,
                    onValueChange = { coutDeplacementStr = it },
                    label = { Text("Coût réel déplacement (DZD)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = autresFraisStr,
                    onValueChange = { autresFraisStr = it },
                    label = { Text("Dépenses réelles annexes (DZD)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            // Synthèse Rentabilité
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Bénéfice Net Réel (CA - Charges)", fontWeight = FontWeight.Bold)
                        Text(
                            "%.0f DZD".format(benefice),
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = if (benefice >= 0) Color(0xFF059669) else MaterialTheme.colorScheme.error
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("• Marge commerciale pièces :", style = MaterialTheme.typography.bodySmall)
                        Text("%.0f DZD".format(margePieces), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("• Revenu propre main-d'œuvre :", style = MaterialTheme.typography.bodySmall)
                        Text("%.0f DZD".format(mainOeuvreFacturee), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("• Total charges réelles déboursées :", style = MaterialTheme.typography.bodySmall)
                        Text("%.0f DZD".format(chargesReelles), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (selectedClientId > 0 && selectedMachineId > 0 && problemeSignale.isNotBlank()) {
                        val newIntervention = InterventionEntity(
                            id = interventionId ?: 0L,
                            numeroIntervention = numeroIntervention.trim(),
                            clientId = selectedClientId,
                            machineId = selectedMachineId,
                            technicien = technicien.trim(),
                            date = date.trim(),
                            statut = statut,
                            priorite = priorite,
                            problemeSignale = problemeSignale.trim(),
                            diagnostic = solution.ifBlank { causeProbable },
                            travailEffectue = travailEffectue.trim(),
                            recommandations = recommandations.trim(),
                            prixVentePieces = prixVentePieces,
                            mainOeuvreFacturee = mainOeuvreFacturee,
                            deplacementFacture = deplacementFacture,
                            fraisFactures = fraisFactures,
                            prixFacture = if (prixFacture > 0) prixFacture else computedRevenue,
                            coutPieces = coutPieces,
                            coutDeplacement = coutDeplacement,
                            autresFrais = autresFrais,
                            coutTotal = chargesReelles,
                            benefice = benefice,
                            margePieces = margePieces,
                            coutMainOeuvre = mainOeuvreFacturee
                        )

                        val diagnosticEntity = if (symptome.isNotBlank() || causeProbable.isNotBlank()) {
                            DiagnosticEntity(
                                interventionId = interventionId ?: 0L,
                                symptome = symptome.trim(),
                                causeProbable = causeProbable.trim(),
                                testsEffectues = testsEffectues.trim(),
                                mesures = mesures.trim(),
                                resultat = resultat.trim(),
                                solution = solution.trim()
                            )
                        } else null

                        viewModel.saveIntervention(newIntervention, diagnosticEntity) { id ->
                            onSaved(id)
                        }
                    }
                },
                enabled = selectedClientId > 0 && selectedMachineId > 0 && problemeSignale.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_intervention_button")
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isEditing) "Mettre à jour l'Intervention" else "Enregistrer l'Intervention")
            }
        }
    }
}
