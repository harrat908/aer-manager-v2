package com.example.ui.screens.interventions

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import android.widget.Toast
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.ClientEntity
import com.example.data.model.DiagnosticEntity
import com.example.data.model.InterventionPhotoEntity
import com.example.data.model.MachineEntity
import com.example.ui.components.ActionIntents
import com.example.ui.components.MachineTypeBadge
import com.example.ui.components.PriorityBadge
import com.example.ui.components.StatusBadge
import com.example.util.PdfReportGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InterventionDetailScreen(
    interventionId: Long,
    viewModel: InterventionsViewModel,
    onBack: () -> Unit,
    onClientClick: (Long) -> Unit,
    onMachineClick: (Long) -> Unit,
    onEditIntervention: (Long) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val intervention by remember(interventionId) { viewModel.getIntervention(interventionId) }.collectAsStateWithLifecycle()
    val clientId = intervention?.clientId ?: 0L
    val machineId = intervention?.machineId ?: 0L
    val client by remember(clientId) {
        if (clientId > 0L) viewModel.getClient(clientId) else MutableStateFlow<ClientEntity?>(null)
    }.collectAsStateWithLifecycle()
    val machine by remember(machineId) {
        if (machineId > 0L) viewModel.getMachine(machineId) else MutableStateFlow<MachineEntity?>(null)
    }.collectAsStateWithLifecycle()
    val diagnostics by remember(interventionId) { viewModel.getDiagnostics(interventionId) }.collectAsStateWithLifecycle()
    val photos by remember(interventionId) { viewModel.getPhotos(interventionId) }.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showDeleteDialog by remember { mutableStateOf(false) }
    var showAddPhotoDialog by remember { mutableStateOf(false) }
    var pendingPhotoUri by remember { mutableStateOf<String?>(null) }
    var selectedPhotoCategory by remember { mutableStateOf("AVANT") }
    var photoDescription by remember { mutableStateOf("") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pendingPhotoUri = uri.toString()
            showAddPhotoDialog = true
        }
    }

    if (showDeleteDialog && intervention != null) {
        val target = intervention!!
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Supprimer l'intervention ?") },
            text = { Text("Êtes-vous sûr de vouloir supprimer définitivement l'intervention « ${target.numeroIntervention} » ?") },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        viewModel.deleteIntervention(target) {
                            Toast.makeText(context, "Intervention supprimée", Toast.LENGTH_SHORT).show()
                            showDeleteDialog = false
                            onBack()
                        }
                    },
                    colors = androidx.compose.material3.ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Supprimer", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(intervention?.numeroIntervention ?: "Détail Intervention") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    if (intervention != null) {
                        // Modifier
                        IconButton(onClick = { onEditIntervention(interventionId) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Modifier", tint = MaterialTheme.colorScheme.primary)
                        }

                        // Dupliquer
                        IconButton(
                            onClick = {
                                viewModel.duplicateIntervention(intervention!!) {
                                    Toast.makeText(context, "Intervention dupliquée avec succès !", Toast.LENGTH_SHORT).show()
                                    onBack()
                                }
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Dupliquer", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        // Supprimer
                        IconButton(onClick = { showDeleteDialog = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = MaterialTheme.colorScheme.error)
                        }

                        // Partager PDF
                        IconButton(
                            onClick = {
                                PdfReportGenerator.generateAndShareReport(
                                    context = context,
                                    intervention = intervention!!,
                                    client = client,
                                    machine = machine,
                                    diagnostics = diagnostics
                                )
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Partager Rapport PDF", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        if (intervention == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val item = intervention!!
            LazyColumn(
                contentPadding = PaddingValues(
                    top = innerPadding.calculateTopPadding() + 8.dp,
                    bottom = innerPadding.calculateBottomPadding() + 80.dp,
                    start = 16.dp,
                    end = 16.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Header Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.numeroIntervention,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    PriorityBadge(priority = item.priorite)
                                    StatusBadge(status = item.statut)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Problème signalé :",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = item.problemeSignale,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Date : ${item.date}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Technicien : ${item.technicien}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Quick change status buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (item.statut != "En cours") {
                                    OutlinedButton(
                                        onClick = { viewModel.updateStatus(item, "En cours") },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("En cours", fontSize = 12.sp)
                                    }
                                }
                                if (item.statut != "Terminé") {
                                    Button(
                                        onClick = { viewModel.updateStatus(item, "Terminé") },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Terminé", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Client & Machine links
                if (client != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Business, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = client!!.nomClinique,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "${client!!.nom} • ${client!!.ville}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row {
                                    IconButton(onClick = { ActionIntents.callPhone(context, client!!.telephone) }) {
                                        Icon(Icons.Default.Call, contentDescription = "Appeler", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { ActionIntents.openWhatsApp(context, client!!.whatsapp.ifBlank { client!!.telephone }) }) {
                                        Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = Color(0xFF25D366))
                                    }
                                }
                            }
                        }
                    }
                }

                if (machine != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onMachineClick(machine!!.id) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Devices, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        MachineTypeBadge(type = machine!!.type)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${machine!!.marque} ${machine!!.modele}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Text(
                                        text = "S/N: ${machine!!.numeroSerie} • ${machine!!.localisationSalle}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                StatusBadge(status = machine!!.etat)
                            }
                        }
                    }
                }

                // Diagnostic Technique Structuré
                item {
                    Text(
                        text = "Diagnostic Technique Structuré",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                if (diagnostics.isNotEmpty()) {
                    items(diagnostics) { diag ->
                        StructuredDiagnosticCard(diag = diag)
                    }
                } else if (item.diagnostic.isNotBlank()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "Diagnostic :",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = item.diagnostic,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                // Travaux réalisés & Recommandations
                if (item.travailEffectue.isNotBlank() || item.recommandations.isNotBlank()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (item.travailEffectue.isNotBlank()) {
                                    Text(
                                        text = "Travaux Réalisés :",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = item.travailEffectue,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                if (item.recommandations.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Recommandations au Client :",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = item.recommandations,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                }

                // Coûts et Rentabilité
                item {
                    Text(
                        text = "Bilan Financier & Rentabilité SAV (Interne)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Section 1: Facturation Client
                            Text(
                                text = "1. Facturation Client (Chiffre d'Affaires)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            if (item.effectivePrixVentePieces > 0) {
                                FinancialRow(label = "• Vente pièces de rechange", amount = item.effectivePrixVentePieces)
                            }
                            FinancialRow(label = "• Main-d'œuvre facturée (Revenu direct)", amount = item.effectiveMainOeuvreFacturee)
                            if (item.effectiveDeplacementFacture > 0) {
                                FinancialRow(label = "• Déplacement facturé", amount = item.effectiveDeplacementFacture)
                            }
                            if (item.effectiveFraisFactures > 0) {
                                FinancialRow(label = "• Frais supplémentaires facturés", amount = item.effectiveFraisFactures)
                            }
                            FinancialRow(label = "Total Facturé Client (CA)", amount = item.effectiveRevenue, isBold = true)

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                            Spacer(modifier = Modifier.height(10.dp))

                            // Section 2: Charges Réelles Déboursées
                            Text(
                                text = "2. Charges Réelles Déboursées (Coûts Internes)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            FinancialRow(label = "• Achat réel pièces détachées", amount = item.coutPieces)
                            FinancialRow(label = "• Déplacement réel / carburant", amount = item.coutDeplacement)
                            if (item.autresFrais > 0) {
                                FinancialRow(label = "• Dépenses réelles annexes", amount = item.autresFrais)
                            }
                            FinancialRow(label = "Total Charges Réelles", amount = item.effectiveChargesReelles, isBold = true)

                            Spacer(modifier = Modifier.height(12.dp))

                            // Section 3: Synthèse Rentabilité
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Bénéfice Net Réel (CA - Charges)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = "%.0f DZD".format(item.effectiveBenefice),
                                            fontWeight = FontWeight.Black,
                                            fontSize = 18.sp,
                                            color = if (item.effectiveBenefice >= 0) Color(0xFF059669) else MaterialTheme.colorScheme.error
                                        )
                                    }

                                    HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f))

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("• Marge commerciale pièces (Vente - Achat) :", style = MaterialTheme.typography.bodySmall)
                                        Text("%.0f DZD".format(item.effectiveMargePieces), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("• Revenu propre main-d'œuvre :", style = MaterialTheme.typography.bodySmall)
                                        Text("%.0f DZD".format(item.effectiveMainOeuvreFacturee), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // 6. Photos Techniques
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Photos Techniques (${photos.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Avant, après, carte électronique, mesures...",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ajouter", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (photos.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(24.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Aucune photo technique enregistrée",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Prenez ou sélectionnez une photo (avant / après / carte)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                } else {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            photos.forEach { photo ->
                                TechnicalPhotoCard(
                                    photo = photo,
                                    onDelete = { viewModel.deletePhoto(photo) }
                                )
                            }
                        }
                    }
                }

                // 7. Actions Rapport Technique & WhatsApp
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Rapport d'Intervention AER",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Génération PDF & partage WhatsApp avec signatures",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        PdfReportGenerator.generateAndShareReport(
                                            context = context,
                                            intervention = item,
                                            client = client,
                                            machine = machine,
                                            diagnostics = diagnostics
                                        )
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Générer & Partager PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (client != null && client!!.whatsapp.isNotBlank()) {
                                    Button(
                                        onClick = {
                                            ActionIntents.openWhatsApp(
                                                context = context,
                                                rawNumber = client!!.whatsapp,
                                                message = "Bonjour Dr. ${client!!.nom}, voici le compte-rendu de l'intervention ${item.numeroIntervention} sur votre équipement ${machine?.marque ?: ""} ${machine?.modele ?: ""}."
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = "WhatsApp", modifier = Modifier.size(16.dp), tint = Color.White)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("WhatsApp", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddPhotoDialog && pendingPhotoUri != null) {
        val categories = listOf("AVANT", "APRÈS", "CARTE ÉLECTRONIQUE", "PLAQUE SIGNALÉTIQUE", "MESURES", "AUTRE")
        AlertDialog(
            onDismissRequest = {
                showAddPhotoDialog = false
                pendingPhotoUri = null
            },
            title = { Text("Détail Photo Technique") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Catégorie de la photo :", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.forEach { cat ->
                            FilterChip(
                                selected = selectedPhotoCategory == cat,
                                onClick = { selectedPhotoCategory = cat },
                                label = { Text(cat, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = photoDescription,
                        onValueChange = { photoDescription = it },
                        label = { Text("Note / Description (optionnel)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addPhoto(
                            InterventionPhotoEntity(
                                interventionId = interventionId,
                                photoUri = pendingPhotoUri!!,
                                categorie = selectedPhotoCategory,
                                description = photoDescription,
                                datePrise = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                            )
                        )
                        showAddPhotoDialog = false
                        pendingPhotoUri = null
                        photoDescription = ""
                    }
                ) {
                    Text("Enregistrer")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showAddPhotoDialog = false
                        pendingPhotoUri = null
                        photoDescription = ""
                    }
                ) {
                    Text("Annuler")
                }
            }
        )
    }
}

@Composable
private fun TechnicalPhotoCard(
    photo: InterventionPhotoEntity,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.width(180.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                AsyncImage(
                    model = photo.photoUri,
                    contentDescription = photo.categorie,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(topStart = 8.dp, bottomEnd = 8.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = photo.categorie,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 10.sp
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(30.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Supprimer",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Column(modifier = Modifier.padding(8.dp)) {
                if (photo.description.isNotBlank()) {
                    Text(
                        text = photo.description,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        fontWeight = FontWeight.Medium
                    )
                }
                Text(
                    text = photo.datePrise,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun StructuredDiagnosticCard(diag: DiagnosticEntity) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Science, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Protocole de Diagnostic",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            DiagField(title = "Symptôme", value = diag.symptome)
            DiagField(title = "Cause Probable", value = diag.causeProbable)
            DiagField(title = "Tests Effectués", value = diag.testsEffectues)
            DiagField(title = "Mesures Réalisées", value = diag.mesures)
            DiagField(title = "Résultat", value = diag.resultat)
            DiagField(title = "Solution Appliquée", value = diag.solution)
        }
    }
}

@Composable
private fun DiagField(title: String, value: String) {
    if (value.isBlank()) return
    Column {
        Text(
            text = "$title :",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun FinancialRow(label: String, amount: Double, isBold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (isBold) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "%.0f DZD".format(amount),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
