package com.example.ui.screens.interventions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ClientEntity
import com.example.data.model.DiagnosticEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.InterventionPhotoEntity
import com.example.data.model.MachineEntity
import com.example.data.repository.AerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

@Suppress("OPT_IN_USAGE")
class InterventionsViewModel(private val repository: AerRepository) : ViewModel() {

    private val _statusFilter = MutableStateFlow("Tous")
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    private val _priorityFilter = MutableStateFlow("Tous")
    val priorityFilter: StateFlow<String> = _priorityFilter.asStateFlow()

    fun setStatusFilter(filter: String) { _statusFilter.value = filter }
    fun setPriorityFilter(filter: String) { _priorityFilter.value = filter }

    val interventions: StateFlow<List<InterventionEntity>> = combine(
        repository.getAllInterventions(),
        _statusFilter,
        _priorityFilter
    ) { list, status, priority ->
        list.filter { item ->
            val matchStatus = if (status == "Tous") true else item.statut.equals(status, ignoreCase = true)
            val matchPriority = if (priority == "Tous") true else item.priorite.equals(priority, ignoreCase = true)
            matchStatus && matchPriority
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allClients: StateFlow<List<ClientEntity>> = repository.getAllClients()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allMachines: StateFlow<List<MachineEntity>> = repository.getAllMachines()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val interventionFlows = ConcurrentHashMap<Long, StateFlow<InterventionEntity?>>()
    private val clientFlows = ConcurrentHashMap<Long, StateFlow<ClientEntity?>>()
    private val machineFlows = ConcurrentHashMap<Long, StateFlow<MachineEntity?>>()
    private val diagnosticsFlows = ConcurrentHashMap<Long, StateFlow<List<DiagnosticEntity>>>()
    private val photosFlows = ConcurrentHashMap<Long, StateFlow<List<InterventionPhotoEntity>>>()

    fun getIntervention(id: Long): StateFlow<InterventionEntity?> {
        return interventionFlows.getOrPut(id) {
            repository.getInterventionById(id)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = null
                )
        }
    }

    fun getClient(clientId: Long): StateFlow<ClientEntity?> {
        return clientFlows.getOrPut(clientId) {
            repository.getClientById(clientId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = null
                )
        }
    }

    fun getMachine(machineId: Long): StateFlow<MachineEntity?> {
        return machineFlows.getOrPut(machineId) {
            repository.getMachineById(machineId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = null
                )
        }
    }

    fun getDiagnostics(interventionId: Long): StateFlow<List<DiagnosticEntity>> {
        return diagnosticsFlows.getOrPut(interventionId) {
            repository.getDiagnosticsForIntervention(interventionId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = emptyList()
                )
        }
    }

    fun getPhotos(interventionId: Long): StateFlow<List<InterventionPhotoEntity>> {
        return photosFlows.getOrPut(interventionId) {
            repository.getPhotosForIntervention(interventionId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = emptyList()
                )
        }
    }

    fun addPhoto(photo: InterventionPhotoEntity) {
        viewModelScope.launch {
            repository.insertInterventionPhoto(photo)
        }
    }

    fun deletePhoto(photo: InterventionPhotoEntity) {
        viewModelScope.launch {
            repository.deleteInterventionPhoto(photo)
        }
    }

    fun saveIntervention(
        intervention: InterventionEntity,
        diagnostic: DiagnosticEntity? = null,
        onComplete: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val id = if (intervention.id == 0L) {
                repository.insertIntervention(intervention)
            } else {
                repository.updateIntervention(intervention)
                intervention.id
            }

            if (diagnostic != null) {
                repository.insertDiagnostic(diagnostic.copy(interventionId = id))
            }
            onComplete(id)
        }
    }

    fun updateStatus(intervention: InterventionEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateIntervention(intervention.copy(statut = newStatus))
        }
    }

    fun deleteIntervention(intervention: InterventionEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.deleteIntervention(intervention)
            onComplete()
        }
    }

    fun duplicateIntervention(intervention: InterventionEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val today = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
            val year = java.text.SimpleDateFormat("yyyy", java.util.Locale.getDefault()).format(java.util.Date())
            val newNum = "INT-$year-${(System.currentTimeMillis() % 9000 + 1000)}"
            val duplicated = intervention.copy(
                id = 0L,
                numeroIntervention = newNum,
                date = today,
                statut = "Planifié",
                problemeSignale = "${intervention.problemeSignale} (Copie)",
                diagnostic = "",
                travailEffectue = "",
                recommandations = ""
            )
            val newId = repository.insertIntervention(duplicated)
            onComplete(newId)
        }
    }

    class Factory(private val repository: AerRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return InterventionsViewModel(repository) as T
        }
    }
}
