package com.example.ui.screens.machines

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ClientEntity
import com.example.data.model.MachineEntity
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMachineScreen(
    initialClientId: Long?,
    machineId: Long?,
    viewModel: MachinesViewModel,
    onBack: () -> Unit,
    onSaved: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val allClients by viewModel.allClients.collectAsStateWithLifecycle()
    val existingMachine by remember(machineId) {
        if (machineId != null && machineId > 0) viewModel.getMachine(machineId)
        else MutableStateFlow(null)
    }.collectAsStateWithLifecycle()

    var selectedClientId by remember { mutableLongStateOf(initialClientId ?: 0L) }
    var marque by remember { mutableStateOf("") }
    var modele by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("CO₂") }
    var numeroSerie by remember { mutableStateOf("") }
    var dateAchat by remember { mutableStateOf("") }
    var fournisseur by remember { mutableStateOf("") }
    var dateInstallation by remember { mutableStateOf("") }
    var dureeGarantieMois by remember { mutableIntStateOf(12) }
    var dateFinGarantie by remember { mutableStateOf("") }
    var etat by remember { mutableStateOf("En service") }
    var localisationSalle by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    // Auto-calculate guarantee end date
    fun updateGuaranteeEnd(installDate: String, months: Int) {
        try {
            val d = if (installDate.isNotBlank()) dateFormat.parse(installDate) else Date()
            val cal = Calendar.getInstance().apply {
                time = d ?: Date()
                add(Calendar.MONTH, months)
            }
            dateFinGarantie = dateFormat.format(cal.time)
        } catch (_: Exception) {
            dateFinGarantie = installDate
        }
    }

    LaunchedEffect(existingMachine) {
        existingMachine?.let {
            selectedClientId = it.clientId
            marque = it.marque
            modele = it.modele
            selectedType = it.type
            numeroSerie = it.numeroSerie
            dateAchat = it.dateAchat
            fournisseur = it.fournisseur
            dateInstallation = it.dateInstallation
            dureeGarantieMois = it.dureeGarantieMois
            dateFinGarantie = it.dateFinGarantie
            etat = it.etat
            localisationSalle = it.localisationSalle
            notes = it.notes
        } ?: run {
            if (dateInstallation.isBlank()) {
                val today = dateFormat.format(Date())
                dateAchat = today
                dateInstallation = today
                updateGuaranteeEnd(today, 12)
            }
        }
    }

    // Dropdown states
    var clientExpanded by remember { mutableStateOf(false) }
    var typeExpanded by remember { mutableStateOf(false) }
    var etatExpanded by remember { mutableStateOf(false) }

    val isEditing = machineId != null && machineId > 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Modifier Machine" else "Nouvelle Machine") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Client Propriétaire",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Client Dropdown
            ExposedDropdownMenuBox(
                expanded = clientExpanded,
                onExpandedChange = { clientExpanded = !clientExpanded }
            ) {
                val selectedClientName = allClients.find { it.id == selectedClientId }?.nomClinique ?: "Sélectionner un client *"
                OutlinedTextField(
                    value = selectedClientName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Client / Clinique *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = clientExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                )
                ExposedDropdownMenu(
                    expanded = clientExpanded,
                    onDismissRequest = { clientExpanded = false }
                ) {
                    allClients.forEach { c ->
                        DropdownMenuItem(
                            text = { Text("${c.nomClinique} (${c.nom})") },
                            onClick = {
                                selectedClientId = c.id
                                clientExpanded = false
                            }
                        )
                    }
                }
            }

            Text(
                text = "Informations Machine",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Type Dropdown
            ExposedDropdownMenuBox(
                expanded = typeExpanded,
                onExpandedChange = { typeExpanded = !typeExpanded }
            ) {
                OutlinedTextField(
                    value = selectedType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Type d'équipement *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                )
                ExposedDropdownMenu(
                    expanded = typeExpanded,
                    onDismissRequest = { typeExpanded = false }
                ) {
                    listOf("CO₂", "Diode laser", "Nd:YAG", "IPL", "HIFU", "Hydrafacial", "Cryolipolyse", "RF", "Cavitation", "Physiothérapie", "Autre").forEach { t ->
                        DropdownMenuItem(
                            text = { Text(t) },
                            onClick = {
                                selectedType = t
                                typeExpanded = false
                            }
                        )
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = marque,
                    onValueChange = { marque = it },
                    label = { Text("Marque *") },
                    placeholder = { Text("ex: Deka, Lumenis") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("machine_marque_input"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = modele,
                    onValueChange = { modele = it },
                    label = { Text("Modèle *") },
                    placeholder = { Text("ex: SmartXide DOT") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("machine_modele_input"),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = numeroSerie,
                onValueChange = { numeroSerie = it },
                label = { Text("Numéro de Série (S/N) *") },
                placeholder = { Text("ex: DK-CO2-2024-8841") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("machine_serial_input"),
                singleLine = true
            )

            OutlinedTextField(
                value = localisationSalle,
                onValueChange = { localisationSalle = it },
                label = { Text("Localisation / Salle") },
                placeholder = { Text("ex: Salle Laser 1, Bloc Soins") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // État Dropdown
            ExposedDropdownMenuBox(
                expanded = etatExpanded,
                onExpandedChange = { etatExpanded = !etatExpanded }
            ) {
                OutlinedTextField(
                    value = etat,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("État de fonctionnement") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = etatExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                )
                ExposedDropdownMenu(
                    expanded = etatExpanded,
                    onDismissRequest = { etatExpanded = false }
                ) {
                    listOf("En service", "En panne", "En maintenance", "Réformé").forEach { e ->
                        DropdownMenuItem(
                            text = { Text(e) },
                            onClick = {
                                etat = e
                                etatExpanded = false
                            }
                        )
                    }
                }
            }

            Text(
                text = "Fournisseur & Garantie",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = fournisseur,
                onValueChange = { fournisseur = it },
                label = { Text("Fournisseur / Distributeur") },
                placeholder = { Text("ex: EuroMed Tech, Shenzhen MediParts") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = dateInstallation,
                    onValueChange = {
                        dateInstallation = it
                        updateGuaranteeEnd(it, dureeGarantieMois)
                    },
                    label = { Text("Date Installation") },
                    placeholder = { Text("YYYY-MM-DD") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = "$dureeGarantieMois",
                    onValueChange = {
                        val m = it.toIntOrNull() ?: 12
                        dureeGarantieMois = m
                        updateGuaranteeEnd(dateInstallation, m)
                    },
                    label = { Text("Garantie (mois)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = dateFinGarantie,
                onValueChange = { dateFinGarantie = it },
                label = { Text("Date Expiration Garantie") },
                placeholder = { Text("YYYY-MM-DD") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes Techniques / Spécifications") },
                placeholder = { Text("Puissance, longueur d'onde, révisions précédentes...") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (selectedClientId > 0 && marque.isNotBlank() && modele.isNotBlank() && numeroSerie.isNotBlank()) {
                        val machineToSave = MachineEntity(
                            id = machineId ?: 0L,
                            clientId = selectedClientId,
                            marque = marque.trim(),
                            modele = modele.trim(),
                            type = selectedType,
                            numeroSerie = numeroSerie.trim(),
                            dateAchat = dateAchat.ifBlank { dateInstallation },
                            fournisseur = fournisseur.trim(),
                            dateInstallation = dateInstallation,
                            dureeGarantieMois = dureeGarantieMois,
                            dateFinGarantie = dateFinGarantie,
                            etat = etat,
                            localisationSalle = localisationSalle.trim(),
                            notes = notes.trim()
                        )
                        viewModel.saveMachine(machineToSave) { id ->
                            onSaved(id)
                        }
                    }
                },
                enabled = selectedClientId > 0 && marque.isNotBlank() && modele.isNotBlank() && numeroSerie.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_machine_button")
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isEditing) "Enregistrer les modifications" else "Créer la machine")
            }
        }
    }
}
