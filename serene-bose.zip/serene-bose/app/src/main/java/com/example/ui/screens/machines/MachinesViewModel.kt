package com.example.ui.screens.machines

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ClientEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.MachineEntity
import com.example.data.repository.AerRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

val MACHINE_TYPES = listOf(
    "Tous",
    "CO₂",
    "Diode laser",
    "Nd:YAG",
    "IPL",
    "HIFU",
    "Hydrafacial",
    "Cryolipolyse",
    "RF",
    "Cavitation",
    "Physiothérapie",
    "Autre"
)

@OptIn(ExperimentalCoroutinesApi::class)
class MachinesViewModel(private val repository: AerRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedType = MutableStateFlow("Tous")
    val selectedType: StateFlow<String> = _selectedType.asStateFlow()

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onTypeSelected(type: String) {
        _selectedType.value = type
    }

    val machines: StateFlow<List<MachineEntity>> = combine(_searchQuery, _selectedType) { query, type ->
        Pair(query, type)
    }.flatMapLatest { (query, type) ->
        val baseFlow = if (query.isBlank()) repository.getAllMachines() else repository.searchMachines(query)
        baseFlow
    }.combine(_selectedType) { list, type ->
        if (type == "Tous") list else list.filter { it.type.equals(type, ignoreCase = true) }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val machineFlows = ConcurrentHashMap<Long, StateFlow<MachineEntity?>>()
    private val clientFlows = ConcurrentHashMap<Long, StateFlow<ClientEntity?>>()
    private val machineInterventionsFlows = ConcurrentHashMap<Long, StateFlow<List<InterventionEntity>>>()

    fun getMachine(machineId: Long): StateFlow<MachineEntity?> {
        return machineFlows.getOrPut(machineId) {
            repository.getMachineById(machineId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = null
                )
        }
    }

    fun getClient(clientId: Long): StateFlow<ClientEntity?> {
        return clientFlows.getOrPut(clientId) {
            repository.getClientById(clientId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = null
                )
        }
    }

    fun getInterventionsForMachine(machineId: Long): StateFlow<List<InterventionEntity>> {
        return machineInterventionsFlows.getOrPut(machineId) {
            repository.getInterventionsByMachineId(machineId)
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5000),
                    initialValue = emptyList()
                )
        }
    }

    val allClients: StateFlow<List<ClientEntity>> = repository.getAllClients()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun saveMachine(machine: MachineEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val id = if (machine.id == 0L) {
                repository.insertMachine(machine)
            } else {
                repository.updateMachine(machine)
                machine.id
            }
            onComplete(id)
        }
    }

    fun deleteMachine(machine: MachineEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.deleteMachine(machine)
            onComplete()
        }
    }

    fun duplicateMachine(machine: MachineEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val duplicated = machine.copy(
                id = 0L,
                modele = "${machine.modele} (Copie)",
                numeroSerie = if (machine.numeroSerie.isNotBlank()) "${machine.numeroSerie}-COPY" else "SN-${System.currentTimeMillis() % 100000}"
            )
            val newId = repository.insertMachine(duplicated)
            onComplete(newId)
        }
    }

    class Factory(private val repository: AerRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MachinesViewModel(repository) as T
        }
    }
}
