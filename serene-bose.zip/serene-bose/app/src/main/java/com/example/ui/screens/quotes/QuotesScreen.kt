package com.example.ui.screens.quotes

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ClientEntity
import com.example.data.model.MachineEntity
import com.example.data.model.PaymentEntity
import com.example.data.model.QuoteEntity
import com.example.data.repository.AerRepository
import com.example.ui.components.ActionIntents
import com.example.ui.components.StatusBadge
import com.example.util.PdfReportGenerator
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuotesScreen(
    repository: AerRepository,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val quotes by remember { repository.getAllQuotes() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val payments by remember { repository.getAllPayments() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val clients by remember { repository.getAllClients() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val machines by remember { repository.getAllMachines() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showAddQuoteDialog by remember { mutableStateOf(false) }
    var showAddPaymentDialog by remember { mutableStateOf(false) }

    val totalQuotesAmount = remember(quotes) { quotes.sumOf { it.totalTtc } }
    val totalPaymentsAmount = remember(payments) { payments.sumOf { it.montant } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Devis & Paiements", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape) {
                            Text(
                                text = if (selectedTabIndex == 0) "${quotes.size}" else "${payments.size}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedTabIndex == 0) {
                        showAddQuoteDialog = true
                    } else {
                        showAddPaymentDialog = true
                    }
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = innerPadding.calculateTopPadding(),
                    bottom = innerPadding.calculateBottomPadding() + 80.dp
                )
        ) {
            SecondaryTabRow(selectedTabIndex = selectedTabIndex) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Devis (${quotes.size})", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("Paiements Encaissés (${payments.size})", fontWeight = FontWeight.SemiBold) }
                )
            }

            if (selectedTabIndex == 0) {
                // Tab 0: Quotes List
                if (quotes.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Receipt, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Aucun devis enregistré pour l'instant", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Total des devis émis", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("%.0f DZD".format(totalQuotesAmount), fontWeight = FontWeight.Black, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Text("${quotes.count { it.statut == "Accepté" }} accepté(s)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                }
                            }
                        }

                        items(quotes, key = { it.id }) { quote ->
                            val client = clients.firstOrNull { it.id == quote.clientId }
                            val machine = machines.firstOrNull { it.id == quote.machineId }
                            QuoteItemCard(
                                quote = quote,
                                client = client,
                                machine = machine,
                                onGeneratePdf = {
                                    PdfReportGenerator.generateAndShareQuote(
                                        context = context,
                                        quote = quote,
                                        client = client,
                                        machine = machine
                                    )
                                }
                            )
                        }
                    }
                }
            } else {
                // Tab 1: Payments List
                if (payments.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Payments, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Aucun paiement enregistré pour l'instant", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Surface(
                                color = Color(0xFF10B981).copy(alpha = 0.15f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Total Encaissé", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("%.0f DZD".format(totalPaymentsAmount), fontWeight = FontWeight.Black, fontSize = 20.sp, color = Color(0xFF059669))
                                    }
                                    Surface(color = Color(0xFF10B981), shape = CircleShape) {
                                        Icon(Icons.Default.Payments, contentDescription = null, tint = Color.White, modifier = Modifier.padding(8.dp).size(20.dp))
                                    }
                                }
                            }
                        }

                        items(payments, key = { it.id }) { payment ->
                            val client = clients.firstOrNull { it.id == payment.clientId }
                            PaymentItemCard(payment = payment, clientName = client?.nomClinique ?: client?.nom ?: "Client")
                        }
                    }
                }
            }
        }
    }

    // Dialog: Add Quote
    if (showAddQuoteDialog) {
        AddQuoteDialog(
            clients = clients,
            machines = machines,
            currentQuoteCount = quotes.size,
            onDismiss = { showAddQuoteDialog = false },
            onConfirm = { newQuote ->
                scope.launch {
                    repository.insertQuote(newQuote)
                    showAddQuoteDialog = false
                }
            }
        )
    }

    // Dialog: Add Payment
    if (showAddPaymentDialog) {
        AddPaymentDialog(
            clients = clients,
            quotes = quotes,
            onDismiss = { showAddPaymentDialog = false },
            onConfirm = { newPayment ->
                scope.launch {
                    repository.insertPayment(newPayment)
                    showAddPaymentDialog = false
                }
            }
        )
    }
}

@Composable
private fun QuoteItemCard(
    quote: QuoteEntity,
    client: ClientEntity?,
    machine: MachineEntity?,
    onGeneratePdf: () -> Unit
) {
    val context = LocalContext.current
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = quote.numeroDevis,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                    if (client != null) {
                        Text(
                            text = "${client.nomClinique} (${client.nom})",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                StatusBadge(status = quote.statut)
            }

            if (machine != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Équipement : ${machine.marque} ${machine.modele} (${machine.type})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            if (quote.notes.isNotBlank()) {
                Text(
                    text = quote.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Date : ${quote.date}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Validité : ${quote.dateValidite}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Prestations: %.0f | Pièces: %.0f".format(quote.prestations, quote.pieces), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (quote.remise > 0) {
                            Text("Remise accordée : -%.0f DZD".format(quote.remise), style = MaterialTheme.typography.labelSmall, color = Color(0xFFDC2626))
                        }
                    }
                    Text("%.0f DZD".format(quote.totalTtc), fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Export Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onGeneratePdf,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Générer PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                if (client != null && client.whatsapp.isNotBlank()) {
                    Button(
                        onClick = {
                            ActionIntents.openWhatsApp(
                                context = context,
                                rawNumber = client.whatsapp,
                                message = "Bonjour Dr. ${client.nom}, voici le devis ${quote.numeroDevis} d'un montant de %.0f DZD pour votre équipement.".format(quote.totalTtc)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "WhatsApp", modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("WhatsApp", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentItemCard(payment: PaymentEntity, clientName: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = clientName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = payment.modePaiement,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = payment.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (payment.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = payment.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(
                text = "+%.0f DZD".format(payment.montant),
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = Color(0xFF059669)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddQuoteDialog(
    clients: List<ClientEntity>,
    machines: List<MachineEntity>,
    currentQuoteCount: Int,
    onDismiss: () -> Unit,
    onConfirm: (QuoteEntity) -> Unit
) {
    var selectedClient by remember { mutableStateOf(clients.firstOrNull()) }
    var selectedMachine by remember { mutableStateOf<MachineEntity?>(null) }
    var clientDropdownExpanded by remember { mutableStateOf(false) }

    var prestations by remember { mutableStateOf("25000") }
    var pieces by remember { mutableStateOf("0") }
    var deplacement by remember { mutableStateOf("3000") }
    var remise by remember { mutableStateOf("0") }
    var notes by remember { mutableStateOf("") }
    var statut by remember { mutableStateOf("Envoyé") }

    val totalCalculated = remember(prestations, pieces, deplacement, remise) {
        val p = prestations.toDoubleOrNull() ?: 0.0
        val pc = pieces.toDoubleOrNull() ?: 0.0
        val d = deplacement.toDoubleOrNull() ?: 0.0
        val r = remise.toDoubleOrNull() ?: 0.0
        (p + pc + d - r).coerceAtLeast(0.0)
    }

    val autoNumber = remember(currentQuoteCount) {
        val nextNum = currentQuoteCount + 19
        "DEV-2026-%03d".format(nextNum)
    }

    val clientMachines = remember(selectedClient, machines) {
        if (selectedClient == null) emptyList()
        else machines.filter { it.clientId == selectedClient!!.id }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau Devis Commercial") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Numéro généré : $autoNumber",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Client Dropdown
                ExposedDropdownMenuBox(
                    expanded = clientDropdownExpanded,
                    onExpandedChange = { clientDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedClient?.nomClinique ?: "Sélectionner un client *",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = clientDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        label = { Text("Client Destinataire") }
                    )
                    ExposedDropdownMenu(
                        expanded = clientDropdownExpanded,
                        onDismissRequest = { clientDropdownExpanded = false }
                    ) {
                        clients.forEach { c ->
                            DropdownMenuItem(
                                text = { Text("${c.nomClinique} (${c.nom})") },
                                onClick = {
                                    selectedClient = c
                                    clientDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                if (clientMachines.isNotEmpty()) {
                    Text("Machine concernée :", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        clientMachines.forEach { m ->
                            FilterChip(
                                selected = selectedMachine?.id == m.id,
                                onClick = { selectedMachine = if (selectedMachine?.id == m.id) null else m },
                                label = { Text("${m.marque} ${m.modele}", fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = prestations,
                        onValueChange = { prestations = it },
                        label = { Text("Prestations (DZD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = pieces,
                        onValueChange = { pieces = it },
                        label = { Text("Pièces (DZD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = deplacement,
                        onValueChange = { deplacement = it },
                        label = { Text("Déplacement (DZD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = remise,
                        onValueChange = { remise = it },
                        label = { Text("Remise (DZD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Détails prestations") },
                    modifier = Modifier.fillMaxWidth()
                )

                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Calculé :", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("%.0f DZD".format(totalCalculated), fontWeight = FontWeight.Black, fontSize = 16.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedClient != null) {
                        val cal = Calendar.getInstance()
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                        val todayStr = sdf.format(cal.time)
                        cal.add(Calendar.DAY_OF_YEAR, 30)
                        val validiteStr = sdf.format(cal.time)

                        onConfirm(
                            QuoteEntity(
                                numeroDevis = autoNumber,
                                clientId = selectedClient!!.id,
                                machineId = selectedMachine?.id,
                                date = todayStr,
                                dateValidite = validiteStr,
                                statut = statut,
                                prestations = prestations.toDoubleOrNull() ?: 0.0,
                                pieces = pieces.toDoubleOrNull() ?: 0.0,
                                deplacement = deplacement.toDoubleOrNull() ?: 0.0,
                                remise = remise.toDoubleOrNull() ?: 0.0,
                                totalTtc = totalCalculated,
                                notes = notes.trim()
                            )
                        )
                    }
                },
                enabled = selectedClient != null
            ) {
                Text("Créer le devis")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddPaymentDialog(
    clients: List<ClientEntity>,
    quotes: List<QuoteEntity>,
    onDismiss: () -> Unit,
    onConfirm: (PaymentEntity) -> Unit
) {
    var selectedClient by remember { mutableStateOf(clients.firstOrNull()) }
    var clientDropdownExpanded by remember { mutableStateOf(false) }
    var montant by remember { mutableStateOf("25000") }
    var modePaiement by remember { mutableStateOf("BaridiMob") }
    var notes by remember { mutableStateOf("") }

    val modes = listOf("Espèces", "Virement", "CCP", "BaridiMob", "Autre")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enregistrer un Règlement") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Client Dropdown
                ExposedDropdownMenuBox(
                    expanded = clientDropdownExpanded,
                    onExpandedChange = { clientDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedClient?.nomClinique ?: "Sélectionner un client *",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = clientDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        label = { Text("Client qui effectue le paiement") }
                    )
                    ExposedDropdownMenu(
                        expanded = clientDropdownExpanded,
                        onDismissRequest = { clientDropdownExpanded = false }
                    ) {
                        clients.forEach { c ->
                            DropdownMenuItem(
                                text = { Text("${c.nomClinique} (${c.nom})") },
                                onClick = {
                                    selectedClient = c
                                    clientDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = montant,
                    onValueChange = { montant = it },
                    label = { Text("Montant Encaissé (DZD) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Mode de règlement :", style = MaterialTheme.typography.labelSmall)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    modes.forEach { m ->
                        FilterChip(
                            selected = modePaiement == m,
                            onClick = { modePaiement = m },
                            label = { Text(m, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Référence virement / N° reçu / Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedClient != null && montant.isNotBlank()) {
                        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        onConfirm(
                            PaymentEntity(
                                clientId = selectedClient!!.id,
                                montant = montant.toDoubleOrNull() ?: 0.0,
                                date = todayStr,
                                modePaiement = modePaiement,
                                notes = notes.trim()
                            )
                        )
                    }
                },
                enabled = selectedClient != null && montant.isNotBlank()
            ) {
                Text("Encaisser")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}
