package com.example.ui.screens.stock

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PartEntity
import com.example.ui.components.QuickFilterChipsRow
import com.example.ui.components.SearchBarField
import com.example.ui.theme.PriorityUrgent

val STOCK_CATEGORIES = listOf("Toutes", "⚠️ Stock Bas", "Lasers", "Optique", "Électronique", "Hydraulique", "Consommables")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockScreen(
    viewModel: StockViewModel,
    modifier: Modifier = Modifier
) {
    val parts by viewModel.parts.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedCategory by remember { mutableStateOf("Toutes") }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingPart by remember { mutableStateOf<PartEntity?>(null) }
    var partToDelete by remember { mutableStateOf<PartEntity?>(null) }

    val filteredParts = remember(parts, selectedCategory) {
        when (selectedCategory) {
            "Toutes" -> parts
            "⚠️ Stock Bas" -> parts.filter { it.stock <= it.stockMinimum }
            else -> parts.filter { it.categorie.equals(selectedCategory, ignoreCase = true) }
        }
    }

    // Delete Confirmation Dialog
    if (partToDelete != null) {
        val target = partToDelete!!
        AlertDialog(
            onDismissRequest = { partToDelete = null },
            title = { Text("Supprimer la pièce ?") },
            text = {
                Text("Êtes-vous sûr de vouloir supprimer définitivement la pièce « ${target.nom} » (Réf: ${target.reference}) ?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deletePart(target)
                        Toast.makeText(context, "Pièce « ${target.nom} » supprimée", Toast.LENGTH_SHORT).show()
                        partToDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Supprimer", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { partToDelete = null }) { Text("Annuler") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Stock & Pièces Détachées", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape) {
                            Text(
                                text = "${parts.size}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_part_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter une pièce")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = innerPadding.calculateTopPadding(),
                    bottom = innerPadding.calculateBottomPadding() + 80.dp
                )
        ) {
            SearchBarField(
                query = searchQuery,
                onQueryChange = viewModel::onSearchQueryChanged,
                placeholder = "Rechercher par nom, référence, catégorie...",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            // Category filter chips
            val counts = remember(parts) {
                mapOf(
                    "Toutes" to parts.size,
                    "⚠️ Stock Bas" to parts.count { it.stock <= it.stockMinimum }
                )
            }
            QuickFilterChipsRow(
                filters = STOCK_CATEGORIES,
                selectedFilter = selectedCategory,
                onFilterSelected = { selectedCategory = it },
                countsMap = counts
            )

            if (filteredParts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Inventory,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "Aucune pièce trouvée pour « $searchQuery »" else "Aucune pièce dans cette catégorie",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredParts, key = { it.id }) { part ->
                        PartItemCard(
                            part = part,
                            onIncrement = { viewModel.adjustStock(part, 1) },
                            onDecrement = { viewModel.adjustStock(part, -1) },
                            onEdit = { editingPart = part },
                            onDelete = { partToDelete = part }
                        )
                    }
                }
            }
        }
    }

    // Dialog: Add Part
    if (showAddDialog) {
        AddEditPartDialog(
            part = null,
            onDismiss = { showAddDialog = false },
            onConfirm = { newPart ->
                viewModel.savePart(newPart)
                Toast.makeText(context, "Pièce ajoutée au stock", Toast.LENGTH_SHORT).show()
                showAddDialog = false
            }
        )
    }

    // Dialog: Edit Part
    if (editingPart != null) {
        AddEditPartDialog(
            part = editingPart,
            onDismiss = { editingPart = null },
            onConfirm = { updatedPart ->
                viewModel.savePart(updatedPart)
                Toast.makeText(context, "Pièce mise à jour", Toast.LENGTH_SHORT).show()
                editingPart = null
            }
        )
    }
}

@Composable
fun PartItemCard(
    part: PartEntity,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isLowStock = part.stock <= part.stockMinimum

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("part_card_${part.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Réf: ${part.reference}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                if (isLowStock) {
                    Surface(
                        color = PriorityUrgent.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = PriorityUrgent, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Alerte Stock Bas",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = PriorityUrgent
                            )
                        }
                    }
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = part.categorie,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = part.nom,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "Achat: %.0f DZD • Vente: %.0f DZD".format(part.prixAchat, part.prixVente),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Empl: ${part.emplacement}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Stock quantity and quick +/- controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Stock : ${part.stock} pcs",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isLowStock) PriorityUrgent else MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = onDecrement,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Diminuer stock", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                    }
                    IconButton(
                        onClick = onIncrement,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Augmenter stock", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }
                }

                // Action buttons: Modifier & Supprimer
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = onEdit,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("edit_part_${part.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Modifier", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("delete_part_${part.id}")
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Supprimer pièce",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddEditPartDialog(
    part: PartEntity?,
    onDismiss: () -> Unit,
    onConfirm: (PartEntity) -> Unit
) {
    val isEditing = part != null
    var reference by remember { mutableStateOf(part?.reference ?: "") }
    var nom by remember { mutableStateOf(part?.nom ?: "") }
    var categorie by remember { mutableStateOf(part?.categorie ?: "Optique") }
    var stockStr by remember { mutableStateOf(part?.stock?.toString() ?: "5") }
    var stockMinStr by remember { mutableStateOf(part?.stockMinimum?.toString() ?: "2") }
    var prixAchatStr by remember { mutableStateOf(if (part != null) part.prixAchat.toLong().toString() else "10000") }
    var prixVenteStr by remember { mutableStateOf(if (part != null) part.prixVente.toLong().toString() else "20000") }
    var fournisseur by remember { mutableStateOf(part?.fournisseur ?: "") }
    var emplacement by remember { mutableStateOf(part?.emplacement ?: "Tiroir A-01") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isEditing) "Modifier la Pièce Détachée" else "Nouvelle Pièce Détachée") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = reference,
                    onValueChange = { reference = it },
                    label = { Text("Référence *") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nom,
                    onValueChange = { nom = it },
                    label = { Text("Désignation de la pièce *") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("Stock initial") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = stockMinStr,
                        onValueChange = { stockMinStr = it },
                        label = { Text("Stock minimum") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = prixAchatStr,
                        onValueChange = { prixAchatStr = it },
                        label = { Text("Prix Achat (DZD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = prixVenteStr,
                        onValueChange = { prixVenteStr = it },
                        label = { Text("Prix Vente (DZD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = emplacement,
                    onValueChange = { emplacement = it },
                    label = { Text("Emplacement atelier") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = fournisseur,
                    onValueChange = { fournisseur = it },
                    label = { Text("Fournisseur habituel") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (reference.isNotBlank() && nom.isNotBlank()) {
                        onConfirm(
                            PartEntity(
                                id = part?.id ?: 0L,
                                reference = reference.trim(),
                                nom = nom.trim(),
                                categorie = categorie.trim(),
                                stock = stockStr.toIntOrNull() ?: 0,
                                stockMinimum = stockMinStr.toIntOrNull() ?: 1,
                                prixAchat = prixAchatStr.toDoubleOrNull() ?: 0.0,
                                prixVente = prixVenteStr.toDoubleOrNull() ?: 0.0,
                                fournisseur = fournisseur.trim(),
                                emplacement = emplacement.trim()
                            )
                        )
                    }
                },
                enabled = reference.isNotBlank() && nom.isNotBlank()
            ) {
                Text(if (isEditing) "Mettre à jour" else "Ajouter")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}
