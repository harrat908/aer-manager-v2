package com.example.ui.screens.stock

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.PartEntity
import com.example.data.repository.AerRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class StockViewModel(private val repository: AerRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun onSearchQueryChanged(query: String) { _searchQuery.value = query }

    val parts: StateFlow<List<PartEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.getAllParts() else repository.searchParts(query)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun savePart(part: PartEntity) {
        viewModelScope.launch {
            if (part.id == 0L) repository.insertPart(part) else repository.updatePart(part)
        }
    }

    fun adjustStock(part: PartEntity, delta: Int) {
        viewModelScope.launch {
            val newStock = (part.stock + delta).coerceAtLeast(0)
            repository.updatePart(part.copy(stock = newStock))
        }
    }

    fun deletePart(part: PartEntity) {
        viewModelScope.launch {
            repository.deletePart(part)
        }
    }

    class Factory(private val repository: AerRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return StockViewModel(repository) as T
        }
    }
}
