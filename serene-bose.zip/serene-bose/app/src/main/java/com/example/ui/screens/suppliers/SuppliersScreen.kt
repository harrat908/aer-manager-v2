package com.example.ui.screens.suppliers

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SupplierEntity
import com.example.data.model.SupplierOrderEntity
import com.example.data.repository.AerRepository
import com.example.ui.components.ActionIntents
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuppliersScreen(
    repository: AerRepository,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val suppliers by remember { repository.getAllSuppliers() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val allOrders by remember { repository.getAllSupplierOrders() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    var showAddSupplierDialog by remember { mutableStateOf(false) }
    var editingSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var supplierToDelete by remember { mutableStateOf<SupplierEntity?>(null) }

    var showAddOrderDialogForSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var editingOrder by remember { mutableStateOf<SupplierOrderEntity?>(null) }
    var orderToDelete by remember { mutableStateOf<SupplierOrderEntity?>(null) }

    val filteredSuppliers = remember(suppliers, searchQuery) {
        if (searchQuery.isBlank()) suppliers
        else suppliers.filter {
            it.nom.contains(searchQuery, ignoreCase = true) ||
            it.pays.contains(searchQuery, ignoreCase = true) ||
            it.contact.contains(searchQuery, ignoreCase = true) ||
            it.notes.contains(searchQuery, ignoreCase = true)
        }
    }

    // Confirmation Dialog: Delete Supplier
    if (supplierToDelete != null) {
        val target = supplierToDelete!!
        AlertDialog(
            onDismissRequest = { supplierToDelete = null },
            title = { Text("Supprimer le Fournisseur ?") },
            text = {
                Text("Êtes-vous sûr de vouloir supprimer définitivement le fournisseur « ${target.nom} » (${target.pays}) ? Toutes les commandes associées seront également supprimées.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            repository.deleteSupplier(target)
                            Toast.makeText(context, "Fournisseur « ${target.nom} » supprimé", Toast.LENGTH_SHORT).show()
                            supplierToDelete = null
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Supprimer", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { supplierToDelete = null }) {
                    Text("Annuler")
                }
            }
        )
    }

    // Confirmation Dialog: Delete Order
    if (orderToDelete != null) {
        val target = orderToDelete!!
        AlertDialog(
            onDismissRequest = { orderToDelete = null },
            title = { Text("Supprimer la Commande ?") },
            text = {
                Text("Êtes-vous sûr de vouloir supprimer définitivement la commande « ${target.produit} » (Qté : ${target.quantite}) ?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            repository.deleteSupplierOrder(target)
                            Toast.makeText(context, "Commande supprimée", Toast.LENGTH_SHORT).show()
                            orderToDelete = null
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Supprimer", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToDelete = null }) {
                    Text("Annuler")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Fournisseurs & Import", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape) {
                            Text(
                                text = "${suppliers.size}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedTabIndex == 0) {
                        showAddSupplierDialog = true
                    } else {
                        if (suppliers.isNotEmpty()) {
                            showAddOrderDialogForSupplier = suppliers.first()
                        } else {
                            showAddSupplierDialog = true
                        }
                    }
                },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("add_supplier_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding(), bottom = innerPadding.calculateBottomPadding() + 80.dp)
        ) {
            SecondaryTabRow(selectedTabIndex = selectedTabIndex) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Fournisseurs (${suppliers.size})", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("Commandes & Transit (${allOrders.size})", fontWeight = FontWeight.SemiBold) }
                )
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Rechercher (Shenzhen, Diode, Kevin, Chine...)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )

            if (selectedTabIndex == 0) {
                // Tab 0: Suppliers List
                if (filteredSuppliers.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Aucun fournisseur trouvé", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredSuppliers, key = { it.id }) { supplier ->
                            val supplierOrders = allOrders.filter { it.supplierId == supplier.id }
                            SupplierCard(
                                supplier = supplier,
                                orders = supplierOrders,
                                onAddOrder = { showAddOrderDialogForSupplier = supplier },
                                onEditSupplier = { editingSupplier = supplier },
                                onDeleteSupplier = { supplierToDelete = supplier },
                                onEditOrder = { order -> editingOrder = order },
                                onDeleteOrder = { order -> orderToDelete = order }
                            )
                        }
                    }
                }
            } else {
                // Tab 1: All Orders / Import Transit
                if (allOrders.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Aucune commande enregistrée", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(allOrders, key = { it.id }) { order ->
                            val supplier = suppliers.firstOrNull { it.id == order.supplierId }
                            SupplierOrderCard(
                                order = order,
                                supplierName = supplier?.nom ?: "Fournisseur",
                                onEdit = { editingOrder = order },
                                onDelete = { orderToDelete = order }
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialog: Add Supplier
    if (showAddSupplierDialog) {
        AddEditSupplierDialog(
            supplier = null,
            onDismiss = { showAddSupplierDialog = false },
            onConfirm = { newSupplier ->
                scope.launch {
                    repository.insertSupplier(newSupplier)
                    Toast.makeText(context, "Fournisseur ajouté avec succès", Toast.LENGTH_SHORT).show()
                    showAddSupplierDialog = false
                }
            }
        )
    }

    // Dialog: Edit Supplier
    if (editingSupplier != null) {
        AddEditSupplierDialog(
            supplier = editingSupplier,
            onDismiss = { editingSupplier = null },
            onConfirm = { updatedSupplier ->
                scope.launch {
                    repository.updateSupplier(updatedSupplier)
                    Toast.makeText(context, "Fournisseur mis à jour", Toast.LENGTH_SHORT).show()
                    editingSupplier = null
                }
            }
        )
    }

    // Dialog: Add Order for a Supplier
    if (showAddOrderDialogForSupplier != null) {
        val targetSupplier = showAddOrderDialogForSupplier!!
        AddEditSupplierOrderDialog(
            supplier = targetSupplier,
            order = null,
            onDismiss = { showAddOrderDialogForSupplier = null },
            onConfirm = { newOrder ->
                scope.launch {
                    repository.insertSupplierOrder(newOrder)
                    Toast.makeText(context, "Commande enregistrée", Toast.LENGTH_SHORT).show()
                    showAddOrderDialogForSupplier = null
                }
            }
        )
    }

    // Dialog: Edit Order
    if (editingOrder != null) {
        val currentOrder = editingOrder!!
        val supplier = suppliers.firstOrNull { it.id == currentOrder.supplierId }
            ?: SupplierEntity(id = currentOrder.supplierId, nom = "Fournisseur", pays = "", contact = "", whatsapp = "", email = "")
        AddEditSupplierOrderDialog(
            supplier = supplier,
            order = currentOrder,
            onDismiss = { editingOrder = null },
            onConfirm = { updatedOrder ->
                scope.launch {
                    repository.updateSupplierOrder(updatedOrder)
                    Toast.makeText(context, "Commande mise à jour", Toast.LENGTH_SHORT).show()
                    editingOrder = null
                }
            }
        )
    }
}

@Composable
private fun SupplierCard(
    supplier: SupplierEntity,
    orders: List<SupplierOrderEntity>,
    onAddOrder: () -> Unit,
    onEditSupplier: () -> Unit,
    onDeleteSupplier: () -> Unit,
    onEditOrder: (SupplierOrderEntity) -> Unit,
    onDeleteOrder: (SupplierOrderEntity) -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("supplier_card_${supplier.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = supplier.nom,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${supplier.pays} • Contact : ${supplier.contact}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${orders.size} cmd",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action buttons row (Call, WhatsApp, Email, Alibaba)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (supplier.whatsapp.isNotBlank()) {
                    Button(
                        onClick = {
                            ActionIntents.openWhatsApp(
                                context = context,
                                rawNumber = supplier.whatsapp,
                                message = "Hello ${supplier.contact}, request for price inquiry and stock availability from AER Manager."
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "WhatsApp", modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("WhatsApp", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                if (supplier.email.isNotBlank()) {
                    Button(
                        onClick = { ActionIntents.sendEmail(context, supplier.email, "Demande de cotation pièces AER") },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Email, contentDescription = "Email", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Email", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                if (supplier.alibaba.isNotBlank()) {
                    Button(
                        onClick = { ActionIntents.openWebUrl(context, supplier.alibaba) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6A00)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.OpenInBrowser, contentDescription = "Alibaba", modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Alibaba", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (supplier.wechat.isNotBlank() || supplier.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (supplier.wechat.isNotBlank()) {
                        Text(
                            text = "WeChat ID : ${supplier.wechat}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (supplier.notes.isNotBlank()) {
                        Text(
                            text = supplier.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))

            // Action row for Supplier: Modifier, + Commande, Supprimer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Expand Orders toggle
                Row(
                    modifier = Modifier
                        .clickable { isExpanded = !isExpanded }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Commandes (${orders.size})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = onEditSupplier,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("edit_supplier_${supplier.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Modifier", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    FilledTonalButton(
                        onClick = onAddOrder,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("add_order_supplier_${supplier.id}")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Cmd", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onDeleteSupplier,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("delete_supplier_${supplier.id}")
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Supprimer",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (orders.isEmpty()) {
                        Text(
                            text = "Aucune commande passée chez ce fournisseur",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        orders.forEach { order ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(10.dp)
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = order.produit, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text(
                                            text = "Qté: ${order.quantite} • Total: %.0f $ • ${order.transport}".format(order.prix),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Date: ${order.date} • ${order.modePaiement}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        OrderStatusBadge(order.statut)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        IconButton(
                                            onClick = { onEditOrder(order) },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Edit,
                                                contentDescription = "Modifier",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteOrder(order) },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Supprimer",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SupplierOrderCard(
    order: SupplierOrderEntity,
    supplierName: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("supplier_order_card_${order.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = order.produit,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                OrderStatusBadge(order.statut)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Fournisseur : $supplierName",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Quantité : ${order.quantite} pcs",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Prix : %.0f USD".format(order.prix),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Transport : ${order.transport}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Paiement : ${order.modePaiement}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Date commande : ${order.date}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))

            // Action row for Order: Modifier & Supprimer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("edit_order_${order.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Modifier", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("delete_order_${order.id}")
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Supprimer",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun OrderStatusBadge(status: String) {
    val (bg, fg) = when (status) {
        "Reçu" -> Color(0xFF10B981).copy(alpha = 0.15f) to Color(0xFF059669)
        "Expédié", "En transit" -> Color(0xFF0284C7).copy(alpha = 0.15f) to Color(0xFF0284C7)
        "En douane" -> Color(0xFFF59E0B).copy(alpha = 0.15f) to Color(0xFFD97706)
        "Annulé" -> Color(0xFFEF4444).copy(alpha = 0.15f) to Color(0xFFDC2626)
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(color = bg, shape = RoundedCornerShape(6.dp)) {
        Text(
            text = status,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun AddEditSupplierDialog(
    supplier: SupplierEntity?,
    onDismiss: () -> Unit,
    onConfirm: (SupplierEntity) -> Unit
) {
    val isEditing = supplier != null
    var nom by remember { mutableStateOf(supplier?.nom ?: "") }
    var pays by remember { mutableStateOf(supplier?.pays ?: "Chine") }
    var contact by remember { mutableStateOf(supplier?.contact ?: "") }
    var whatsapp by remember { mutableStateOf(supplier?.whatsapp ?: "") }
    var wechat by remember { mutableStateOf(supplier?.wechat ?: "") }
    var alibaba by remember { mutableStateOf(supplier?.alibaba ?: "") }
    var email by remember { mutableStateOf(supplier?.email ?: "") }
    var notes by remember { mutableStateOf(supplier?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isEditing) "Modifier Fournisseur" else "Nouveau Fournisseur") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = nom,
                    onValueChange = { nom = it },
                    label = { Text("Nom de l'entreprise *") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pays,
                        onValueChange = { pays = it },
                        label = { Text("Pays") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = contact,
                        onValueChange = { contact = it },
                        label = { Text("Nom du contact") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("WhatsApp (ex: +86...)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = wechat,
                        onValueChange = { wechat = it },
                        label = { Text("WeChat ID") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = alibaba,
                    onValueChange = { alibaba = it },
                    label = { Text("Lien Alibaba / 1688") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Spécialités / Pièces fournies") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (nom.isNotBlank()) {
                        onConfirm(
                            SupplierEntity(
                                id = supplier?.id ?: 0L,
                                nom = nom.trim(),
                                pays = pays.trim(),
                                contact = contact.trim(),
                                whatsapp = whatsapp.trim(),
                                wechat = wechat.trim(),
                                alibaba = alibaba.trim(),
                                email = email.trim(),
                                notes = notes.trim()
                            )
                        )
                    }
                },
                enabled = nom.isNotBlank()
            ) {
                Text(if (isEditing) "Mettre à jour" else "Ajouter")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}

@Composable
private fun AddEditSupplierOrderDialog(
    supplier: SupplierEntity,
    order: SupplierOrderEntity?,
    onDismiss: () -> Unit,
    onConfirm: (SupplierOrderEntity) -> Unit
) {
    val isEditing = order != null
    var produit by remember { mutableStateOf(order?.produit ?: "") }
    var quantite by remember { mutableStateOf(order?.quantite?.toString() ?: "1") }
    var prix by remember { mutableStateOf(if (order != null && order.prix > 0) order.prix.toLong().toString() else "") }
    var transport by remember { mutableStateOf(order?.transport ?: "DHL Express") }
    var modePaiement by remember { mutableStateOf(order?.modePaiement ?: "Alibaba Trade Assurance") }
    var statut by remember { mutableStateOf(order?.statut ?: "Commandé") }
    var date by remember { mutableStateOf(order?.date ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }

    val transports = listOf("DHL Express", "FedEx Priority", "Air Cargo", "Maritime")
    val payments = listOf("Alibaba Trade Assurance", "Virement (T/T)", "Western Union", "PayPal")
    val statuses = listOf("Commandé", "Expédié", "En transit", "En douane", "Reçu", "Annulé")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isEditing) "Modifier la Commande" else "Nouvelle Commande : ${supplier.nom}") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = produit,
                    onValueChange = { produit = it },
                    label = { Text("Désignation Produit / Pièce *") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantite,
                        onValueChange = { quantite = it },
                        label = { Text("Quantité") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = prix,
                        onValueChange = { prix = it },
                        label = { Text("Prix Total (USD/EUR)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Statut commande / transit :", style = MaterialTheme.typography.labelSmall)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    statuses.forEach { s ->
                        FilterChip(
                            selected = statut == s,
                            onClick = { statut = s },
                            label = { Text(s, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Mode de transport :", style = MaterialTheme.typography.labelSmall)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    transports.forEach { t ->
                        FilterChip(
                            selected = transport == t,
                            onClick = { transport = t },
                            label = { Text(t, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Paiement :", style = MaterialTheme.typography.labelSmall)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    payments.forEach { p ->
                        FilterChip(
                            selected = modePaiement == p,
                            onClick = { modePaiement = p },
                            label = { Text(p, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date (AAAA-MM-JJ)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (produit.isNotBlank()) {
                        onConfirm(
                            SupplierOrderEntity(
                                id = order?.id ?: 0L,
                                supplierId = supplier.id,
                                produit = produit.trim(),
                                quantite = quantite.toIntOrNull() ?: 1,
                                prix = prix.toDoubleOrNull() ?: 0.0,
                                transport = transport,
                                modePaiement = modePaiement,
                                statut = statut,
                                date = date.trim()
                            )
                        )
                    }
                },
                enabled = produit.isNotBlank()
            ) {
                Text(if (isEditing) "Mettre à jour" else "Enregistrer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}
