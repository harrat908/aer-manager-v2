package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand colors: Aesthetic Equipment Repair (Laser / High-Tech Medical)
val AerTealDark = Color(0xFF0F766E)
val AerTealPrimary = Color(0xFF0D9488)
val AerTealLight = Color(0xFF2DD4BF)
val AerCyan = Color(0xFF06B6D4)
val AerCyanLight = Color(0xFF67E8F9)

// Surface & Background
val AerNavyDark = Color(0xFF090D16)
val AerNavySurface = Color(0xFF111827)
val AerNavyCard = Color(0xFF1E293B)
val AerNavyBorder = Color(0xFF334155)

val AerLightBg = Color(0xFFF8FAFC)
val AerLightSurface = Color(0xFFFFFFFF)
val AerLightCard = Color(0xFFF1F5F9)
val AerLightBorder = Color(0xFFE2E8F0)

// Status & Priorities
val PriorityUrgent = Color(0xFFEF4444)
val PriorityHigh = Color(0xFFF97316)
val PriorityNormal = Color(0xFFEAB308)
val PriorityLow = Color(0xFF10B981)

val StatusService = Color(0xFF10B981)
val StatusBroken = Color(0xFFEF4444)
val StatusMaintenance = Color(0xFFF59E0B)
val AerBlueAccent = Color(0xFF3B82F6)

// Gradients
val AerHeroGradient = androidx.compose.ui.graphics.Brush.horizontalGradient(
    colors = listOf(AerTealDark, AerCyan)
)

val AerCardGradientDark = androidx.compose.ui.graphics.Brush.verticalGradient(
    colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
)

