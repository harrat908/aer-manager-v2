package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AerTealLight,
    onPrimary = AerNavyDark,
    primaryContainer = AerTealDark,
    onPrimaryContainer = Color.White,
    secondary = AerCyan,
    onSecondary = AerNavyDark,
    secondaryContainer = Color(0xFF0E7490),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFF818CF8),
    background = AerNavyDark,
    onBackground = Color(0xFFF1F5F9),
    surface = AerNavySurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = AerNavyCard,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = AerNavyBorder,
    error = PriorityUrgent
)

private val LightColorScheme = lightColorScheme(
    primary = AerTealPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Color(0xFF115E59),
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = Color(0xFF6366F1),
    background = AerLightBg,
    onBackground = Color(0xFF0F172A),
    surface = AerLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = AerLightCard,
    onSurfaceVariant = Color(0xFF64748B),
    outline = AerLightBorder,
    error = PriorityUrgent
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our crisp medical brand palette by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
