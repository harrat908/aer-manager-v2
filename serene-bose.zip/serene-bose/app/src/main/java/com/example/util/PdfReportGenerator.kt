package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.ClientEntity
import com.example.data.model.DiagnosticEntity
import com.example.data.model.InterventionEntity
import com.example.data.model.MachineEntity
import com.example.data.model.QuoteEntity
import com.example.data.preferences.TechnicianProfileManager
import java.io.File
import java.io.FileOutputStream

object PdfReportGenerator {

    fun generateAndShareReport(
        context: Context,
        intervention: InterventionEntity,
        client: ClientEntity?,
        machine: MachineEntity?,
        diagnostics: List<DiagnosticEntity>
    ) {
        try {
            val file = generatePdfFile(context, intervention, client, machine, diagnostics)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Rapport Technique ${intervention.numeroIntervention} - ${machine?.marque ?: "Machine"} ${machine?.modele ?: ""}"
                )
                putExtra(
                    Intent.EXTRA_TEXT,
                    "Veuillez trouver ci-joint le rapport d'intervention technique SAV AER (${intervention.numeroIntervention}) pour ${client?.nomClinique ?: "le client"}."
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "Partager le rapport technique"))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Erreur génération PDF : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun generateAndShareQuote(
        context: Context,
        quote: QuoteEntity,
        client: ClientEntity?,
        machine: MachineEntity?
    ) {
        try {
            val file = generateQuotePdfFile(context, quote, client, machine)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Devis AER ${quote.numeroDevis} - ${client?.nomClinique ?: "Client"}"
                )
                putExtra(
                    Intent.EXTRA_TEXT,
                    "Veuillez trouver ci-joint notre devis de maintenance/réparation ${quote.numeroDevis} pour votre équipement ${machine?.marque ?: ""} ${machine?.modele ?: ""}."
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "Partager le devis par WhatsApp / Email"))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Erreur génération Devis PDF : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun generateQuotePdfFile(
        context: Context,
        quote: QuoteEntity,
        client: ClientEntity?,
        machine: MachineEntity?
    ): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()

        val margin = 36f
        var y = 46f

        val profile = TechnicianProfileManager(context).getProfile()

        // Top banner
        paint.color = Color.rgb(13, 148, 136)
        paint.style = Paint.Style.FILL
        canvas.drawRect(0f, 0f, 595f, 95f, paint)

        paint.color = Color.WHITE
        paint.textSize = 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(profile.entreprise, margin, 38f, paint)

        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(profile.titre, margin, 56f, paint)

        paint.textSize = 9.5f
        canvas.drawText("Ingénieur Référent : ${profile.nom}  •  Tél : ${profile.telephone}  •  ${profile.email}", margin, 74f, paint)

        // Title box
        y = 120f
        paint.color = Color.rgb(15, 23, 42)
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("DEVIS COMMERCIAL / PROFORMA", margin, y, paint)

        paint.textSize = 12f
        paint.color = Color.rgb(13, 148, 136)
        canvas.drawText("N° ${quote.numeroDevis}", 420f, y, paint)

        y += 24f
        paint.color = Color.rgb(100, 116, 139)
        paint.textSize = 10f
        canvas.drawText("Date d'émission : ${quote.date}   •   Validité jusqu'au : ${quote.dateValidite}", margin, y, paint)

        y += 20f
        paint.color = Color.rgb(226, 232, 240)
        paint.strokeWidth = 1f
        canvas.drawLine(margin, y, 595f - margin, y, paint)

        // Client and Equipment info
        y += 20f
        paint.color = Color.rgb(15, 23, 42)
        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("CLIENT / CLINIQUE :", margin, y, paint)
        canvas.drawText("ÉQUIPEMENT CONCERNÉ :", 300f, y, paint)

        y += 16f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        paint.color = Color.rgb(51, 65, 85)
        canvas.drawText(client?.nomClinique ?: "Non spécifié", margin, y, paint)
        canvas.drawText("Marque / Modèle : ${machine?.marque ?: "Général"} ${machine?.modele ?: ""}", 300f, y, paint)

        y += 14f
        canvas.drawText("Contact : ${client?.nom ?: ""}", margin, y, paint)
        canvas.drawText("Technologie : ${machine?.type ?: "Médical / Esthétique"}", 300f, y, paint)

        y += 14f
        canvas.drawText("Tél / WhatsApp : ${client?.telephone ?: ""}", margin, y, paint)
        canvas.drawText("N° Série : ${machine?.numeroSerie ?: "-"}", 300f, y, paint)

        y += 14f
        canvas.drawText("Adresse : ${client?.adresse ?: ""} - ${client?.ville ?: ""}", margin, y, paint)

        y += 30f
        // Line items table
        paint.color = Color.rgb(241, 245, 249)
        canvas.drawRoundRect(margin, y, 595f - margin, y + 26f, 6f, 6f, paint)

        paint.color = Color.rgb(15, 23, 42)
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("DÉSIGNATION DES PRESTATIONS & FOURNITURES", margin + 12f, y + 17f, paint)
        canvas.drawText("MONTANT DZD", 460f, y + 17f, paint)

        y += 38f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.rgb(30, 41, 59)

        fun drawLineItem(desc: String, amount: Double) {
            canvas.drawText(desc, margin + 12f, y, paint)
            canvas.drawText("%.0f DZD".format(amount), 460f, y, paint)
            y += 20f
        }

        if (quote.prestations > 0) drawLineItem("Main d'œuvre technique et tests de diagnostic", quote.prestations)
        if (quote.pieces > 0) drawLineItem("Fourniture de pièces détachées & consommables", quote.pieces)
        if (quote.deplacement > 0) drawLineItem("Frais de déplacement et prise en charge site", quote.deplacement)
        if (quote.remise > 0) {
            paint.color = Color.rgb(220, 38, 38)
            drawLineItem("Remise commerciale accordée", -quote.remise)
            paint.color = Color.rgb(30, 41, 59)
        }

        y += 15f
        paint.color = Color.rgb(226, 232, 240)
        canvas.drawLine(margin, y, 595f - margin, y, paint)

        // Total
        y += 24f
        paint.color = Color.rgb(13, 148, 136)
        paint.textSize = 14f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("TOTAL NET À PAYER :", 300f, y, paint)
        canvas.drawText("%.0f DZD".format(quote.totalTtc), 460f, y, paint)

        y += 30f
        if (quote.notes.isNotBlank()) {
            paint.color = Color.rgb(100, 116, 139)
            paint.textSize = 9f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            val noteParagraphs = quote.notes.split(Regex("\r?\n"))
            var isFirstLine = true
            for (p in noteParagraphs) {
                val words = p.trim().split(Regex("\\s+"))
                var currentLine = if (isFirstLine) "Notes & Conditions : " else ""
                isFirstLine = false
                for (w in words) {
                    val testLine = if (currentLine.isEmpty()) w else "$currentLine $w"
                    if (paint.measureText(testLine) < (595f - 2 * margin - 24f)) {
                        currentLine = testLine
                    } else {
                        if (currentLine.isNotEmpty()) {
                            canvas.drawText(currentLine, margin + 12f, y, paint)
                            y += 13f
                        }
                        currentLine = w
                    }
                }
                if (currentLine.isNotEmpty()) {
                    canvas.drawText(currentLine, margin + 12f, y, paint)
                    y += 13f
                }
            }
        }

        y += 60f
        paint.color = Color.rgb(15, 23, 42)
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Bon pour accord et commande :", margin + 12f, y, paint)
        canvas.drawText("Cachet & Signature (${profile.nom}) :", 360f, y, paint)

        y += 50f
        paint.strokeWidth = 0.8f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(margin + 12f, y, margin + 200f, y, paint)
        canvas.drawLine(360f, y, 360f + 180f, y, paint)

        pdfDocument.finishPage(page)

        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outputFile = File(reportsDir, "Devis_${quote.numeroDevis}.pdf")
        val outputStream = FileOutputStream(outputFile)
        pdfDocument.writeTo(outputStream)
        outputStream.close()
        pdfDocument.close()

        return outputFile
    }

    private fun generatePdfFile(
        context: Context,
        intervention: InterventionEntity,
        client: ClientEntity?,
        machine: MachineEntity?,
        diagnostics: List<DiagnosticEntity>
    ): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 (72 dpi approx)
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint()
        var y = 45f
        val margin = 40f
        val rightMargin = 555f
        val contentWidth = rightMargin - margin

        val profile = TechnicianProfileManager(context).getProfile()

        // --- Header Background Accent ---
        paint.color = Color.rgb(15, 118, 110) // Aer Teal Dark
        canvas.drawRect(margin, y, rightMargin, y + 68f, paint)

        // --- Header Title ---
        paint.color = Color.WHITE
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(profile.entreprise, margin + 14f, y + 24f, paint)

        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(profile.titre, margin + 14f, y + 40f, paint)

        paint.textSize = 9f
        canvas.drawText("Ingénieur Référent : ${profile.nom}  •  Tél : ${profile.telephone}  •  ${profile.email}", margin + 14f, y + 54f, paint)

        y += 82f

        // --- Document Title Banner ---
        paint.color = Color.rgb(241, 245, 249)
        canvas.drawRoundRect(margin, y, rightMargin, y + 26f, 6f, 6f, paint)

        paint.color = Color.rgb(17, 24, 39)
        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("RAPPORT D'INTERVENTION SAV TECHNIQUE : ${intervention.numeroIntervention}", margin + 10f, y + 18f, paint)

        y += 38f

        // --- Client & Machine Box ---
        paint.color = Color.rgb(248, 250, 252)
        canvas.drawRoundRect(margin, y, rightMargin, y + 90f, 6f, 6f, paint)
        paint.color = Color.rgb(226, 232, 240)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(margin, y, rightMargin, y + 90f, 6f, 6f, paint)
        paint.style = Paint.Style.FILL

        // Left: Client
        paint.color = Color.rgb(15, 118, 110)
        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("CLIENT / CLINIQUE", margin + 12f, y + 18f, paint)

        paint.color = Color.BLACK
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(client?.nomClinique ?: "Non spécifié", margin + 12f, y + 34f, paint)

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Médecin : ${client?.nom ?: "-"}", margin + 12f, y + 48f, paint)
        canvas.drawText("Tél : ${client?.telephone ?: "-"}", margin + 12f, y + 62f, paint)
        canvas.drawText("Ville : ${client?.ville ?: "-"}", margin + 12f, y + 76f, paint)

        // Right: Machine
        val col2 = margin + 260f
        paint.color = Color.rgb(15, 118, 110)
        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("ÉQUIPEMENT MÉDICAL", col2, y + 18f, paint)

        paint.color = Color.BLACK
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("${machine?.marque ?: ""} ${machine?.modele ?: ""}", col2, y + 34f, paint)

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Type : ${machine?.type ?: "-"}", col2, y + 48f, paint)
        canvas.drawText("N° Série (S/N) : ${machine?.numeroSerie ?: "-"}", col2, y + 62f, paint)
        canvas.drawText("Date intervention : ${intervention.date}", col2, y + 76f, paint)

        y += 105f

        // Helper section drawer
        fun drawSection(title: String, content: String, isImportant: Boolean = false) {
            paint.color = if (isImportant) Color.rgb(15, 118, 110) else Color.rgb(51, 65, 85)
            paint.textSize = 11f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText(title.uppercase(), margin, y, paint)
            y += 14f

            paint.color = Color.rgb(30, 41, 59)
            paint.textSize = 10f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)

            // Split into paragraphs by newline first, then wrap words
            val paragraphs = content.split(Regex("\r?\n"))
            for (paragraph in paragraphs) {
                val trimmedPara = paragraph.trim()
                if (trimmedPara.isEmpty()) {
                    y += 6f
                    continue
                }
                val words = trimmedPara.split(Regex("\\s+"))
                var currentLine = ""
                for (word in words) {
                    val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                    if (paint.measureText(testLine) < contentWidth) {
                        currentLine = testLine
                    } else {
                        if (currentLine.isNotEmpty()) {
                            canvas.drawText(currentLine, margin, y, paint)
                            y += 14f
                        }
                        currentLine = word
                    }
                }
                if (currentLine.isNotEmpty()) {
                    canvas.drawText(currentLine, margin, y, paint)
                    y += 14f
                }
            }
            y += 6f
        }

        drawSection("1. Problème Signalé", intervention.problemeSignale)

        // Diagnostic
        val diagText = if (diagnostics.isNotEmpty()) {
            val d = diagnostics.first()
            "Symptôme : ${d.symptome}\nCause : ${d.causeProbable}\nMesures : ${d.mesures}\nSolution : ${d.solution}"
        } else {
            intervention.diagnostic.ifBlank { "Diagnostic nominal effectué." }
        }
        drawSection("2. Diagnostic Technique & Mesures", diagText)

        drawSection("3. Travaux Réalisés", intervention.travailEffectue.ifBlank { "Maintenance et révision effectuées." })

        if (intervention.recommandations.isNotBlank()) {
            drawSection("4. Recommandations au Praticien", intervention.recommandations)
        }

        // --- Financial & Warranty Summary ---
        paint.color = Color.rgb(241, 245, 249)
        canvas.drawRoundRect(margin, y, rightMargin, y + 50f, 6f, 6f, paint)
        paint.color = Color.rgb(15, 118, 110)
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("PRIX FACTURÉ TTC", margin + 14f, y + 20f, paint)
        paint.textSize = 14f
        canvas.drawText("%.0f DZD".format(intervention.prixFacture), margin + 14f, y + 38f, paint)

        val statCol = margin + 260f
        paint.textSize = 10f
        paint.color = Color.rgb(51, 65, 85)
        val techDisplayName = if (intervention.technicien.isNotBlank()) intervention.technicien else profile.nom
        canvas.drawText("STATUT : ${intervention.statut.uppercase()}", statCol, y + 20f, paint)
        canvas.drawText("TECHNICIEN : ${techDisplayName.uppercase()}", statCol, y + 36f, paint)

        y += 75f

        // --- Signatures Area ---
        paint.color = Color.rgb(100, 116, 139)
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

        canvas.drawText("Visa & Signature Technicien (${techDisplayName}) :", margin + 14f, y, paint)
        canvas.drawText("Signature & Cachet Client :", col2, y, paint)

        y += 45f
        paint.strokeWidth = 0.8f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(margin + 14f, y, margin + 180f, y, paint)
        canvas.drawLine(col2, y, col2 + 180f, y, paint)

        pdfDocument.finishPage(page)

        // Write to cache directory
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outputFile = File(reportsDir, "Rapport_${intervention.numeroIntervention}.pdf")
        val outputStream = FileOutputStream(outputFile)
        pdfDocument.writeTo(outputStream)
        outputStream.close()
        pdfDocument.close()

        return outputFile
    }
}
