package com.example

import com.example.data.model.ClientEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class ClientOperationsTest {

    @Test
    fun testClientCreationAndAttributes() {
        val client = ClientEntity(
            id = 1L,
            nom = "Dr. Amine Mansouri",
            nomClinique = "Clinique d'Esthétique Al-Azhar",
            telephone = "+213 555 11 22 33",
            email = "contact@alazhar-esthetique.dz",
            adresse = "12 Rue des Frères Bouadou, Bir Mourad Raïs",
            ville = "Alger",
            whatsapp = "+213 555 11 22 33",
            notes = "Cabinet dermatologique et lasers médicaux"
        )

        assertEquals("Dr. Amine Mansouri", client.nom)
        assertEquals("Clinique d'Esthétique Al-Azhar", client.nomClinique)
        assertEquals("+213 555 11 22 33", client.telephone)
        assertEquals("Alger", client.ville)
        assertEquals("12 Rue des Frères Bouadou, Bir Mourad Raïs", client.adresse)
        assertEquals(1L, client.id)
    }

    @Test
    fun testClientUpdatePreservesIdAndCascade() {
        val original = ClientEntity(
            id = 42L,
            nom = "Dr. Benali",
            nomClinique = "Centre Laser Esthétique",
            telephone = "0550123456",
            email = "dr.benali@gmail.com",
            adresse = "Boulevard Mohamed V",
            ville = "Oran",
            whatsapp = "0550123456"
        )

        val updated = original.copy(
            nomClinique = "Centre Laser Esthétique & Chirurgie",
            adresse = "Boulevard Mohamed V, Résidence El-Bahia"
        )

        assertEquals(42L, updated.id)
        assertEquals("Centre Laser Esthétique & Chirurgie", updated.nomClinique)
        assertEquals("Oran", updated.ville)
        assertEquals(original.nom, updated.nom)
        assertEquals(original.telephone, updated.telephone)
    }
}
