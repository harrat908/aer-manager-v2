package com.example

import com.example.data.model.InterventionEntity
import com.example.data.model.PartEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class FinanceCalculationTest {

    @Test
    fun testMandatoryValidationScenario() {
        // Scénario de validation obligatoire :
        // Prix achat pièce = 30 000 DA
        // Prix vente pièce = 50 000 DA
        // Main-d'œuvre = 15 000 DA
        // Déplacement facturé = 5 000 DA
        // Frais supplémentaires facturés = 3 000 DA
        // Coût réel déplacement = 2 000 DA
        // Coûts supplémentaires réels = 1 000 DA

        val intervention = InterventionEntity(
            id = 1L,
            numeroIntervention = "INT-TEST-001",
            clientId = 1L,
            machineId = 1L,
            date = "2026-10-04",
            problemeSignale = "Test validation financière",
            // Revenus facturés client
            prixVentePieces = 50000.0,
            mainOeuvreFacturee = 15000.0,
            deplacementFacture = 5000.0,
            fraisFactures = 3000.0,
            prixFacture = 73000.0,
            // Charges réelles déboursées (internes)
            coutPieces = 30000.0,
            coutDeplacement = 2000.0,
            autresFrais = 1000.0
        )

        // 1. Chiffre d'affaires attendu = 73 000 DA
        assertEquals(73000.0, intervention.effectiveRevenue, 0.001)

        // 2. Charges réelles attendues = 30 000 + 2 000 + 1 000 = 33 000 DA
        assertEquals(33000.0, intervention.effectiveChargesReelles, 0.001)

        // 3. Bénéfice réel attendu = 73 000 - 33 000 = 40 000 DA
        assertEquals(40000.0, intervention.effectiveBenefice, 0.001)

        // 4. Marge commerciale pièces attendue = 50 000 - 30 000 = 20 000 DA
        assertEquals(20000.0, intervention.effectiveMargePieces, 0.001)

        // 5. Revenu propre main-d'œuvre = 15 000 DA (pas une charge !)
        assertEquals(15000.0, intervention.effectiveMainOeuvreFacturee, 0.001)
    }

    @Test
    fun testPartMarginSeparation() {
        val part = PartEntity(
            id = 1L,
            reference = "LASER-FILTER-01",
            nom = "Filtre Déionisant Laser",
            categorie = "Optique",
            stock = 5,
            stockMinimum = 2,
            prixAchat = 30000.0,
            prixVente = 50000.0,
            fournisseur = "Fournisseur Médical",
            emplacement = "Tiroir A1"
        )

        assertEquals(20000.0, part.partMargin, 0.001)
    }
}
