package com.example

import com.example.data.model.MachineEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MachineOperationsTest {

    @Test
    fun testMachineCreationAndAttributes() {
        val machine = MachineEntity(
            id = 10L,
            clientId = 2L,
            marque = "Alma Lasers",
            modele = "Soprano Titanium",
            type = "Diode laser",
            numeroSerie = "ALMA-TI-2026-99",
            dateAchat = "2024-05-10",
            fournisseur = "Alma Distributeur",
            dateInstallation = "2024-05-15",
            dureeGarantieMois = 24,
            dateFinGarantie = "2026-05-15",
            etat = "En service",
            localisationSalle = "Cabine Laser 1",
            notes = "Contrôle annuel effectué"
        )

        assertEquals("Alma Lasers", machine.marque)
        assertEquals("Soprano Titanium", machine.modele)
        assertEquals("Diode laser", machine.type)
        assertEquals("ALMA-TI-2026-99", machine.numeroSerie)
        assertEquals("Cabine Laser 1", machine.localisationSalle)
        assertEquals("2026-05-15", machine.dateFinGarantie)
        assertEquals("En service", machine.etat)
        assertEquals(2L, machine.clientId)
    }

    @Test
    fun testMachineDuplicationLogic() {
        val original = MachineEntity(
            id = 5L,
            clientId = 1L,
            marque = "Lumenis",
            modele = "AcuPulse CO2",
            type = "CO₂",
            numeroSerie = "SN-LUM-4421",
            dateAchat = "2025-01-10",
            fournisseur = "Lumenis France",
            dateInstallation = "2025-01-20",
            dureeGarantieMois = 12,
            dateFinGarantie = "2026-01-20",
            etat = "En service",
            localisationSalle = "Bloc Esthétique"
        )

        val duplicated = original.copy(
            id = 0L,
            modele = "${original.modele} (Copie)",
            numeroSerie = "${original.numeroSerie}-COPY"
        )

        assertEquals(0L, duplicated.id)
        assertEquals("AcuPulse CO2 (Copie)", duplicated.modele)
        assertEquals("SN-LUM-4421-COPY", duplicated.numeroSerie)
        assertEquals(original.marque, duplicated.marque)
        assertEquals(original.type, duplicated.type)
        assertEquals(original.clientId, duplicated.clientId)
        assertEquals(original.localisationSalle, duplicated.localisationSalle)
    }
}
