package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.preferences.TechnicianProfile
import com.example.data.preferences.TechnicianProfileManager
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TechnicianProfileTest {

    @Test
    fun testDefaultProfile() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = TechnicianProfileManager(context)
        val profile = manager.getProfile()

        assertEquals("Jules AER", profile.nom)
        assertEquals("Ingénieur Biomédical & SAV Lasers", profile.titre)
    }

    @Test
    fun testSaveAndRetrieveRealProfile() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = TechnicianProfileManager(context)

        val realProfile = TechnicianProfile(
            nom = "Julien Harrat",
            titre = "Ingénieur Biomédical Spécialiste Lasers & Médical",
            telephone = "+213 555 98 76 54",
            email = "harrat.kerapro@gmail.com",
            entreprise = "KeraPro Biomedical SAV",
            adresse = "Alger, Algérie"
        )

        manager.saveProfile(realProfile)

        val retrieved = manager.getProfile()
        assertEquals("Julien Harrat", retrieved.nom)
        assertEquals("Ingénieur Biomédical Spécialiste Lasers & Médical", retrieved.titre)
        assertEquals("+213 555 98 76 54", retrieved.telephone)
        assertEquals("harrat.kerapro@gmail.com", retrieved.email)
        assertEquals("KeraPro Biomedical SAV", retrieved.entreprise)
        assertEquals("Alger, Algérie", retrieved.adresse)
    }
}
